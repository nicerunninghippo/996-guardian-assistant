$ErrorActionPreference='Stop'
$taskFramework=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319'
$taskMetadata=Join-Path $env:WINDIR 'System32/WinMetadata'
$taskRefs=@((Join-Path $env:WINDIR 'Microsoft.NET/assembly/GAC_MSIL/System.Runtime.WindowsRuntime/v4.0_4.0.0.0__b77a5c561934e089/System.Runtime.WindowsRuntime.dll'),'System.Drawing.dll','System.Windows.Forms.dll','System.Web.Extensions.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll',
 (Join-Path $env:WINDIR 'Microsoft.NET/assembly/GAC_MSIL/System.Runtime/v4.0_4.0.0.0__b03f5f7f11d50a3a/System.Runtime.dll'),
 (Join-Path $taskMetadata 'Windows.Foundation.winmd'),(Join-Path $taskMetadata 'Windows.Globalization.winmd'),(Join-Path $taskMetadata 'Windows.Graphics.winmd'),(Join-Path $taskMetadata 'Windows.Media.winmd'),(Join-Path $taskMetadata 'Windows.Storage.winmd'))
$taskArgs=@('/nologo','/utf8output','/optimize+','/target:winexe','/platform:x64',('/out:'+(Join-Path $PSScriptRoot '996守护助手.exe')))
$taskArgs+=$taskRefs | ForEach-Object { '/reference:'+$_ }
$taskArgs+=Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'source') -Filter '*.cs' | ForEach-Object FullName
& (Join-Path $taskFramework 'csc.exe') $taskArgs
if($LASTEXITCODE -ne 0){throw '编译未通过'}
Write-Output 'V4.20.10 build completed'









