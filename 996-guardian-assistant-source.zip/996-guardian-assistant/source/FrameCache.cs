using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

// One capture is immutable while it is being observed. Never retain this
// scope across a new capture, input action, or an in-place bitmap edit.
public static class FrameCache {
 sealed class Scope : IDisposable {
  internal readonly Bitmap Image;
  internal readonly Scope Previous;
  internal readonly Dictionary<object,Dictionary<string,object>> Values=new Dictionary<object,Dictionary<string,object>>();
  bool disposed;
  internal Scope(Bitmap image,Scope previous){Image=image;Previous=previous;}
  public void Dispose(){if(disposed)return;disposed=true;Values.Clear();if(object.ReferenceEquals(current,this))current=Previous;}
 }
 [ThreadStatic] static Scope current;
 public static IDisposable Begin(Bitmap image){if(image==null)throw new ArgumentNullException("image");Scope scope=new Scope(image,current);current=scope;return scope;}
 public static T Get<T>(Bitmap image,object owner,string key,Func<T> read){
  Scope scope=current;
  if(scope==null||!object.ReferenceEquals(scope.Image,image))return read();
  Dictionary<string,object> values;
  if(!scope.Values.TryGetValue(owner,out values)){values=new Dictionary<string,object>();scope.Values.Add(owner,values);}
  object value;if(values.TryGetValue(key,out value))return (T)value;
  T result=read();values.Add(key,result);return result;
 }
 // Request straight ARGB from GDI+ even for indexed, 24-bit, or premultiplied
 // sources. LockBits preserves pixel coordinates and ignores DPI metadata.
 internal static int[] Pixels(Bitmap image){return Get<int[]>(image,typeof(FrameCache),"argb",delegate{return ReadPixels(image);});}
 static int[] ReadPixels(Bitmap image){
  int width=image.Width,height=image.Height;int[] pixels=new int[width*height];
  BitmapData bits=image.LockBits(new Rectangle(0,0,width,height),ImageLockMode.ReadOnly,PixelFormat.Format32bppArgb);
  try{for(int y=0;y<height;y++)Marshal.Copy(IntPtr.Add(bits.Scan0,y*bits.Stride),pixels,y*width,width);}
  finally{image.UnlockBits(bits);}
  return pixels;
 }
}
