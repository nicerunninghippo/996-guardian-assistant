using System;
using System.Drawing;

public sealed class FarmPopupAction {
 public bool Handled,Recovered;
 public Point? Tap;
 public string Status="";
}

// Pure decisions: absence of a prompt button is not proof that its next page
// closed. Recovery requires two fresh, matching real map-title observations.
public sealed class FarmPopupFlow {
 bool active; string previous=""; int attempts,cleanFrames,lastMap=-1;
 double nextTap,lastFrame=-1;
 public bool Active {get{return active;}}
 public void Reset(){active=false;previous="";attempts=0;cleanFrames=0;lastMap=-1;nextTap=0;lastFrame=-1;}
 public FarmPopupAction See(FarmPopupReading seen,double now,bool running) {
  var action=new FarmPopupAction();
  if(!running){Reset();return action;}
  if(!seen.Panel)return action;
  action.Handled=true;active=true;cleanFrames=0;lastMap=-1;
  bool fresh=now>lastFrame;lastFrame=Math.Max(lastFrame,now);
  string key=seen.Name+":"+(seen.ClosePoint.X/12)+":"+(seen.ClosePoint.Y/12);
  if(key!=previous){previous=key;attempts=0;nextTap=0;}
  if(!seen.CanClose){action.Status="已识别"+seen.Name+"，关闭叉暂未确认；继续识别关闭位置";return action;}
  if(!fresh||now<nextTap){action.Status="等待"+seen.Name+"关闭反馈，继续扫描新截图";return action;}
  attempts++;nextTap=now+(attempts%3==0?10:2.5);
  action.Tap=seen.ClosePoint;
  action.Status="关闭"+seen.Name+"：已确认窗口和关闭叉，点="+seen.ClosePoint.X+","+seen.ClosePoint.Y+"；第"+attempts+"次，等待新截图验证";
  return action;
 }
 // Call only after all other modal handlers have declined the current frame.
 public FarmPopupAction Verify(double now,bool running,int strictMap) {
  var action=new FarmPopupAction();
  if(!running){Reset();return action;}
  if(!active)return action;
  action.Handled=true;
  if(now>lastFrame){
   lastFrame=now;
   cleanFrames=strictMap>=0?(strictMap==lastMap?cleanFrames+1:1):0;
   lastMap=strictMap;
  }
  action.Status="弹窗处理后继续确认地图标题；尚未恢复时继续查找窗口";
  if(cleanFrames>=2){Reset();action.Recovered=true;action.Status="弹窗已关闭，连续两帧地图标题恢复；下一帧继续守护";}
  return action;
 }
}
