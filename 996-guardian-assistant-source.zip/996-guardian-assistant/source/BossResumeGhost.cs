using System;using System.Drawing;
public sealed class BossResumeGhostFlow {
 public bool Active;public double Started,NextTap;public int Attempts,Frames;int previous=-9;
 public void Start(double now){Active=true;Started=now;NextTap=now+20;Attempts=Frames=0;previous=-9;}
 public void Reset(){Active=false;Frames=Attempts=0;previous=-9;}
 // 0=verified hall, 1=the natural BOSS map, 2=verified Ghost with AUTO, -1=unknown.
 public bool See(int scene,bool stone,bool fresh,double now){
  if(!Active)return false;if(fresh){Frames=scene==previous?Frames+1:1;previous=scene;}
  if(scene==2&&Frames>=2){Reset();return false;}
  if(now<NextTap||scene!=1||Frames<2||!stone)return false;
  if(now-Started>=80){Started=now+300;NextTap=Started;Attempts=0;return false;}
  return Attempts<3;
 }
 public void Sent(double now){Attempts++;NextTap=now+(Attempts>=3?300:8);if(Attempts>=3){Started=now+300;Attempts=0;}}
}
partial class Guardian {
 readonly BossResumeGhostFlow bossResumeFlow=new BossResumeGhostFlow();string bossResumeMap="";long bossResumeFrame=-1;double bossResumeLogAt=-100;
 string resumeAdmitTitle="";int resumeAdmitCount;long resumeAdmitFrame=-1;
 bool ResumeGhostAfterBoss(Bitmap frame){
  if(!bossResumeFlow.Active){if(!BossOwnsWindow&&maintenanceTask==null&&hellEnabled.Checked&&mapPriority.CurrentLevel>=80){string actual=BossTitle(frame);bool lower=false;for(int i=0;i<mapPriority.Names.Length;i++)if(actual==mapPriority.Names[i])lower=true;if(resumeAdmitFrame!=traceFrame){resumeAdmitFrame=traceFrame;resumeAdmitCount=lower&&actual==resumeAdmitTitle?resumeAdmitCount+1:lower?1:0;resumeAdmitTitle=actual;}if(resumeAdmitCount>=2&&!ReadBossCombat(frame).ChallengeMap){bossResumeMap=actual;bossResumeFlow.Start(BossNow);Log("已在普通刷怪地图且没有BOSS任务：锁定恢复冥界28:52 → 鬼门关；地图="+actual);}}if(!bossResumeFlow.Active)return false;}if(BossOwnsWindow)return false;if(!hellEnabled.Checked||mapPriority.CurrentLevel<80){bossResumeFlow.Reset();return false;}
  bool fresh=bossResumeFrame!=traceFrame;bossResumeFrame=traceFrame;int hell=ReadHellMap(frame);int hall=hell==5?5:CalibrationMap(frame);
  bool ghost=hell==4&&ReadAutoBattle(frame).State==AutoBattleState.On;
  string title=BossTitle(frame);bool natural=title==bossResumeMap&&bossResumeMap.Length>0;for(int i=0;i<mapPriority.Names.Length;i++)if(title==mapPriority.Names[i])natural=true;
  var combat=ReadBossCombat(frame);int scene=ghost?2:hall==0||hall==3||hall==5?0:natural?1:-1;
  bool tap=bossResumeFlow.See(scene,combat.ReturnStone.HasValue,fresh,BossNow);
  if(!bossResumeFlow.Active){Log("BOSS后恢复：两帧确认已回鬼门关且自动开启，结束恢复任务");return false;}
  if(combat.ChallengeMap){CheckAuto(frame,true);return true;}if(scene==0&&hall==3){HandleHellRoute(frame);return true;}if(scene==0||scene==2)return false; // Existing hall route owns travel and Ghost auto verification.
  if(tap){TraceBeforeAction(frame,"自然BOSS任务后返回：已确认盟重石头；等待盟重地图验证");if(Click(combat.ReturnStone.Value)){bossResumeFlow.Sent(BossNow);Log("BOSS后恢复：拾取缓冲已结束，点击已识别盟重石头；等待实际回城再走冥界28:52");TraceEvent("boss_resume_ghost","map",bossResumeMap,"stone",combat.ReturnStone.Value,"phase","return_submitted");}return true;}
  if(BossNow-bossResumeLogAt>=30){bossResumeLogAt=BossNow;Log("BOSS后恢复鬼门关：原地图="+bossResumeMap+"；当前="+title+"；场景="+scene+"；石头="+combat.ReturnStone.HasValue+"；等待剩余秒="+Math.Max(0,bossResumeFlow.NextTap-BossNow).ToString("0"));}
  if(scene==1){CheckAuto(frame,true);return true;}return false;
 }
}