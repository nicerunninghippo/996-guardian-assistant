using System;
using System.Drawing;
using System.IO;
using System.Text;

partial class Guardian {
 MinimapDetector minimapDetector;
 readonly MinimapRecoveryFlow minimapRecovery=new MinimapRecoveryFlow();
 string lastMinimapStatus="";
 DateTime lastMinimapLog=DateTime.MinValue;

 MinimapReading ReadMinimap(Bitmap image) {
  if(minimapDetector==null)minimapDetector=new MinimapDetector(Path.Combine(root,"templates"));
  return FrameCache.Get<MinimapReading>(image,minimapDetector,"minimap",delegate{return minimapDetector.Read(image);});
 }
 void ResetMinimapRecovery(){minimapRecovery.Reset();ResetWelcomePopup();ResetFarmPopup();lastMinimapStatus="";lastMinimapLog=DateTime.MinValue;}

 // Only actual title templates plus a complete coordinate count as recovery.
 // Scene colours and combat effects cannot complete this check.
 bool ReadRestoredMapData(Bitmap image,out string detail) {
  detail="地图名仍未读清";
  int map=CalibrationMap(image);
  string targetReason;
  if(map<0&&TryRecognizePriorityTarget(image,out targetReason))map=4;
  if(map<0&&!priorityTitleBlocksLegacy)using(Bitmap title=image.Clone(new Rectangle(1067,31,149,34),image.PixelFormat)){
   Mask frame=new Mask(title,false);Point p;
   foreach(Mask target in targetMaps)if(target.Find(frame,new Rectangle(0,0,title.Width,title.Height),out p)>=.76){map=4;break;}
  }
  if(map<0)return false;
  string name=new[]{"盟重省","次元大陆","蛟龙领地","神龙帝国","目标地图","冥界"}[map];
  int x,y;string coordinateDetail;
  bool valid=map<4?ReadCoordForCalibration(image,map,out x,out y,out coordinateDetail):TryReadCoordDigits(image,0,out x,out y,out coordinateDetail);
  detail=name+"；"+(valid?"坐标="+x+":"+y:coordinateDetail);
  return valid;
 }

 bool EnsureMinimapVisible(Bitmap image) {
  // Modal 温馨提示遮住地图时，先处理其完整“立即了解”按钮；否则
  // the minimap state machine would correctly wait forever behind the modal.
  if(HandleWelcomePopup(image))return true;
  if(!guardRequested||!engine.Running||Native.GetAsyncKeyState(0x77)!=0){ResetMinimapRecovery();return false;}
  MinimapReading reading=ReadMinimap(image);
  string detail="";
  bool ready=reading.State==MinimapState.Expanded&&minimapRecovery.Active&&ReadRestoredMapData(image,out detail);
  var action=minimapRecovery.Step(reading,ClockSeconds(),true,ready);
  if(!action.Handled&&!action.Recovered)return false;
  // No old position, pending click, low-health sample or recycle step may be
  // reused after the minimap has hidden the map identity.
  engine.ResetObservation();engine.ResetPending();ResetHealthEvidence();
  autoWaiting=false;mengWalk.Pending=false;shenWalk.Pending=false;
  mzCoordReadyUntil=DateTime.MinValue;lastCoord="";
  if(recycle.Stage!=0){recycle.Reset();nextRecycle=DateTime.Now.AddMinutes((double)recycleMinutes.Value);}
  engine.Status=action.Status+(detail.Length>0?"；"+detail:"");
  if(action.Tap.HasValue){
   if(!guardRequested||!engine.Running||Native.GetAsyncKeyState(0x77)!=0){ResetMinimapRecovery();return true;}
   if(!Click(action.Tap.Value))engine.Status="小地图展开点击未发出；等待下一帧重新确认";
  }
  if(action.Tap.HasValue||action.Recovered||engine.Status!=lastMinimapStatus||(DateTime.Now-lastMinimapLog).TotalSeconds>=10){
   Log(engine.Status);lastMinimapStatus=engine.Status;lastMinimapLog=DateTime.Now;
  }
  // Even the recovery-confirming frame is consumed. Routing resumes on a
  // fresh capture, with the normal consecutive-map observations.
  return true;
 }

 public void MinimapSmoke(){
  timer.Stop();WelcomePopupSmoke();var report=new StringBuilder();
  foreach(string file in new[]{"collapsed-popup.png","collapsed-evening.png"})using(Bitmap b=new Bitmap(Path.Combine(root,"tests","minimap-v49",file))){
   FocusAssert(ReadMinimap(b).State==MinimapState.Collapsed,"折叠按钮："+file);
   FocusAssert(Recognize(b)==-1,"折叠后不能使用背景或战斗特效判定地图："+file);
   report.AppendLine("通过："+file+" 识别为小地图收起，不误报目的地。");
  }
  for(int i=0;i<4;i++)using(Bitmap b=new Bitmap(Path.Combine(root,"tests","route"+i+".png"))){
   FocusAssert(Recognize(b)==i,"展开后原路线地图识别："+i);
   report.AppendLine("通过：原路线地图 "+i+" 识别未改变。");
  }
  using(Bitmap b=new Bitmap(Path.Combine(root,"tests","minimap-v49","expanded-current.png"))){
   string detail;
   FocusAssert(ReadMinimap(b).State==MinimapState.Expanded,"当前真实展开截图");
   FocusAssert(Recognize(b)==4&&ReadRestoredMapData(b,out detail),"当前真实截图标题和坐标恢复");
   report.AppendLine("通过：当前龙爪要塞真实截图的展开状态、地图名和坐标。");
  }
  using(Bitmap effects=new Bitmap(1216,684)){
   using(Graphics g=Graphics.FromImage(effects))g.FillRectangle(Brushes.Orange,610,455,250,80);
   FocusAssert(AutoFightScore(effects)>=.65&&Recognize(effects)==-1,"战斗橙色特效不能单独代表目标地图");
   report.AppendLine("通过：战斗特效分数高而地图名缺失时，不认作目标地图。");
  }
  File.WriteAllText(Path.Combine(root,"V4.9集成重点测试.txt"),report.ToString(),Encoding.UTF8);
 }
}

