using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;

public enum MinimapState { Unknown, Collapsed, Expanded }

public sealed class MinimapReading {
 public MinimapState State;
 public Point TogglePoint;
 public double ClosedScore,OpenScore;
}

// Recognize the actual 地图 tab, not the absence of map-name/OCR evidence.
// All inputs and returned points use Guardian's 1216 x 684 game coordinates.
public sealed class MinimapDetector {
 sealed class Pixels {
  public int Width,Height;public int[] Values;
  public Pixels(Bitmap source) {
   Width=source.Width;Height=source.Height;Values=new int[Width*Height];
   using(Bitmap copy=new Bitmap(Width,Height,PixelFormat.Format32bppArgb)) {
    // Explicit pixel rectangles avoid PNG DPI metadata changing the glyph
    // dimensions when a 192-DPI diagnostic is copied to a 96-DPI bitmap.
    using(Graphics g=Graphics.FromImage(copy))g.DrawImage(source,new Rectangle(0,0,Width,Height),new Rectangle(0,0,Width,Height),GraphicsUnit.Pixel);
    BitmapData bits=copy.LockBits(new Rectangle(0,0,Width,Height),ImageLockMode.ReadOnly,PixelFormat.Format32bppArgb);
    try {for(int y=0;y<Height;y++)Marshal.Copy(IntPtr.Add(bits.Scan0,y*bits.Stride),Values,y*Width,Width);}
    finally {copy.UnlockBits(bits);}
   }
  }
 }
 readonly Pixels tab;
 public bool Available {get{return tab!=null;}}
 public MinimapDetector(string templateDirectory) {
  try {using(Bitmap image=new Bitmap(Path.Combine(templateDirectory,"minimap-tab-v49.png")))tab=new Pixels(image);}
  catch(IOException){}catch(ArgumentException){}
 }
 static double Gray(int value) {return (((value>>16)&255)*.299+((value>>8)&255)*.587+(value&255)*.114);}
 double Score(Pixels image,int left,int top) {
  if(left<0||top<0||left+tab.Width>image.Width||top+tab.Height>image.Height)return 0;
  double sumA=0,sumB=0,sqA=0,sqB=0,ab=0,error=0;int count=0;
  for(int y=0;y<tab.Height;y++)for(int x=0;x<tab.Width;x++) {
   int a=tab.Values[y*tab.Width+x],b=image.Values[(top+y)*image.Width+left+x];
   double ga=Gray(a),gb=Gray(b);sumA+=ga;sumB+=gb;sqA+=ga*ga;sqB+=gb*gb;ab+=ga*gb;
   error+=Math.Abs(((a>>16)&255)-((b>>16)&255))+Math.Abs(((a>>8)&255)-((b>>8)&255))+Math.Abs((a&255)-(b&255));count++;
  }
  double varianceA=count*sqA-sumA*sumA,varianceB=count*sqB-sumB*sumB;
  if(varianceA<=0||varianceB<=0)return 0;
  double correlation=(count*ab-sumA*sumB)/Math.Sqrt(varianceA*varianceB);
  // Colour alone would mistake a plain beige patch for the tab; correlation
  // requires the actual two glyphs and surrounding texture to align too.
  return Math.Max(0,Math.Min(correlation,1-error/(765.0*count)));
 }
 double Find(Pixels image,int expectedX,out Point point) {
  double best=0;point=Point.Empty;
  for(int dy=-3;dy<=3;dy++)for(int dx=-3;dx<=3;dx++) {
   int left=expectedX+dx,top=35+dy;double score=Score(image,left,top);
   if(score>best){best=score;point=new Point(left+tab.Width/2,top+tab.Height/2);}
  }
  return best;
 }
 public MinimapReading Read(Bitmap image) {
  MinimapReading result=new MinimapReading();
  if(image==null||image.Width!=1216||image.Height!=684||tab==null)return result;
  Pixels frame=new Pixels(image);Point closed,open;
  result.ClosedScore=Find(frame,1175,out closed);
  result.OpenScore=Find(frame,1028,out open);
  if(result.ClosedScore>=.84&&result.ClosedScore-result.OpenScore>=.10){result.State=MinimapState.Collapsed;result.TogglePoint=closed;}
  else if(result.OpenScore>=.84&&result.OpenScore-result.ClosedScore>=.10){result.State=MinimapState.Expanded;result.TogglePoint=open;}
  return result;
 }
}

public sealed class MinimapRecoveryAction {
 public bool Handled,Recovered;
 public Point? Tap;
 public string Status="";
}

// Pure state machine. A successful ADB command is not recovery: fresh frames
// must show the expanded tab AND recovered map/coordinate observations.
public sealed class MinimapRecoveryFlow {
 bool recovering;int readyFrames,attempts;double lastFrame=-1,nextTap;
 public bool Active {get{return recovering;}}
 public void Reset(){recovering=false;readyFrames=0;attempts=0;lastFrame=-1;nextTap=0;}
 public MinimapRecoveryAction Step(MinimapReading seen,double now,bool running,bool mapDataReady) {
  MinimapRecoveryAction action=new MinimapRecoveryAction();
  if(!running){Reset();return action;}
  bool fresh=now>lastFrame;
  if(seen.State==MinimapState.Collapsed) {
   recovering=true;action.Handled=true;readyFrames=0;
   if(fresh)lastFrame=now;
   action.Status="小地图展开后等待画面验证；冷却期间不重复点击";
   if(!fresh||now<nextTap)return action;
   // A confidently recognized right-edge tab is sufficient: restore it on
   // this first fresh frame. Missing OCR or an unknown frame is never enough.
   action.Tap=seen.TogglePoint;attempts++;
   nextTap=now+(attempts<3?3:12);
   action.Status="确认小地图收起，点击地图标签展开；等待地图名和坐标恢复（本轮第"+attempts+"次）";
   if(attempts>=3)attempts=0;
   return action;
  }
  if(!recovering){if(fresh)lastFrame=now;return action;}
  action.Handled=true;
  if(seen.State==MinimapState.Expanded) {
   action.Status=mapDataReady?"小地图已展开，等待连续新截图确认地图名和坐标":"小地图已展开，继续读取地图名和坐标；保持展开不再点击";
   if(fresh){readyFrames=mapDataReady?readyFrames+1:0;lastFrame=now;}
   if(readyFrames>=2){Reset();action.Recovered=true;action.Status="小地图恢复完成：地图名和坐标已连续确认，下一帧继续下图";}
  } else {
   readyFrames=0;if(fresh)lastFrame=now;
   action.Status="等待小地图展开验证；标签暂不清晰，继续截图，不猜点击位置";
  }
  return action;
 }
}
