using System;using System.Drawing;using System.Windows.Forms;
partial class Guardian {
 readonly HellRoutePolicy hellRoute=new HellRoutePolicy();
 readonly CheckBox hellEnabled=new CheckBox{Text="80级优先：冥界 → 鬼门关",Checked=true,AutoSize=true};
 WalkProgress hellWalk=NewHellWalk();Mask hellTitle,hellNativeTitle,ghostNativeTitle,hellPortal,hellTransfer;
 RouteTextLocator hellText,hellTitleText;int hellScene=-9,hellSceneCount,hellWordCount;long hellSceneFrame=-1,hellWordFrame=-1;
 string hellWord="",hellLastLog="";Point hellWordPoint;double hellLogAt=-100;
 int knownMenuFrames,knownMenuTaps;long knownMenuFrame=-1;Point knownMenuPoint;double knownMenuNext;
 bool CloseKnownWelfarePopup(Bitmap frame){
  if(!guardRequested||!engine.Running)return false;
  if(farmPopupDetector==null)farmPopupDetector=new FarmPopupDetector(System.IO.Path.Combine(root,"templates"));
  var seen=farmPopupDetector.Read(frame,false);
  if(!seen.Known||seen.Name!="佳人有约"){knownMenuFrames=knownMenuTaps=0;knownMenuFrame=-1;knownMenuNext=0;return false;}
  if(!seen.CanClose){HellLog("误开佳人菜单：完整关闭叉未确认，继续识别");return true;}
  if(knownMenuFrame!=traceFrame){knownMenuFrame=traceFrame;knownMenuFrames=knownMenuPoint==seen.ClosePoint?knownMenuFrames+1:1;knownMenuPoint=seen.ClosePoint;}
  if(knownMenuFrames<2){HellLog("误开佳人菜单：等待第二张新截图确认关闭叉");return true;}
  double now=ClockSeconds();if(now<knownMenuNext)return true;
  TraceBeforeAction(frame,"误开佳人菜单：主动关闭完整窗口，优先恢复原任务");
  if(Click(seen.ClosePoint)){knownMenuTaps++;knownMenuNext=now+(knownMenuTaps%3==0?30:2.5);Log("误开佳人菜单：已点击确认关闭叉；第"+knownMenuTaps+"次，等待新截图；"+seen.Detail);
   if(hellRoute.Stage==HellRouteStage.Portal||hellRoute.Stage==HellRouteStage.Detail){HellSet(HellRouteStage.Walk);hellWalk=NewHellWalk();}
  }else knownMenuNext=now+2.5;
  return true;
 }
 string hellSkipReason="";double hellSkipAt=-100;
 void HellSkip(string reason,int scene){double now=ClockSeconds();if(reason==hellSkipReason&&now-hellSkipAt<30)return;hellSkipReason=reason;hellSkipAt=now;Log("鬼门关调度跳过："+reason+"；地图="+scene+"；连续帧="+hellSceneCount+"；等级="+mapPriority.CurrentLevel+"；已提交="+hellRoute.EntryIssued+"；冷却剩余秒="+Math.Max(0,hellRoute.RetryAt-now).ToString("0"));TraceEvent("hell_dispatch_skip","reason",reason,"scene",scene,"entry_issued",hellRoute.EntryIssued,"level",mapPriority.CurrentLevel,"cooldown_seconds",Math.Max(0,hellRoute.RetryAt-now));}
 void InitHellRoute(Control top){top.Controls.Add(hellEnabled);hellEnabled.CheckedChanged+=(s,e)=>{if(!hellEnabled.Checked)StopAll("冥界路线已关闭，点击开始守护应用");};}
 static bool HellPortalPoint(Point label,bool toolbar,out Point point){point=new Point(label.X,label.Y-38);var menu=new Rectangle(415,30,600,175);if(toolbar&&menu.Contains(point)){point=new Point(label.X,label.Y+10);if(menu.Contains(point))return false;}return point.X>=100&&point.X<950&&point.Y>=40&&point.Y<500;}
 void LoadHellRoute(){if(hellText!=null)return;ghostNativeTitle=Load("ghost-title-native.png",false,false);hellTitle=Load("hell-title.png",false,false);hellNativeTitle=Load("hell-title-native.png",false,false);hellPortal=Load("hell-portal-label.png",true,false);hellTransfer=Load("hell-transfer-label.png",true,false);hellText=new RouteTextLocator(new Rectangle(110,45,900,575));hellTitleText=new RouteTextLocator(new Rectangle(1067,32,149,29));}
 static WalkProgress NewHellWalk(){return new WalkProgress{VisibilityOffsets=new[]{Point.Empty,new Point(0,-3),Point.Empty,new Point(-2,0),Point.Empty,new Point(2,0),Point.Empty,new Point(0,2)},VisibilityRadius=3};}
 void ResetHellRoute(bool connection){hellRoute.Reset(connection);hellWalk=NewHellWalk();hellScene=-9;hellSceneCount=hellWordCount=0;hellSceneFrame=hellWordFrame=-1;hellWord="";if(hellText!=null)hellText.Reset();if(hellTitleText!=null)hellTitleText.Reset();}
 void DisposeHellRoute(){if(hellText!=null)hellText.Dispose();if(hellTitleText!=null)hellTitleText.Dispose();}
 int ReadHellMap(Bitmap frame){
  LoadHellRoute();using(Bitmap title=frame.Clone(new Rectangle(1067,31,149,34),frame.PixelFormat)){
   Point p;Mask mask=new Mask(title,false);if(ghostNativeTitle!=null&&ghostNativeTitle.Find(mask,new Rectangle(0,0,149,34),out p)>=.94)return 4;if(hellTitle!=null&&hellTitle.Find(mask,new Rectangle(0,0,149,34),out p)>=.90)return 5;
   if(hellNativeTitle!=null&&hellNativeTitle.Find(mask,new Rectangle(0,0,149,34),out p)>=.90)return 5;
  }
  Point located;string text,detail;if(hellTitleText.TryFind(frame,new[]{"冥界","鬼门关"},out located,out text,out detail)){if(text=="冥界")return 5;if(text=="鬼门关")return 4;}return -1;
 }
 bool HellWordReady(Bitmap frame,string[] choices,out Point point,out string detail){
  point=Point.Empty;string text;Point seen;if(!hellText.TryFind(frame,choices,out seen,out text,out detail)){hellWordCount=0;return false;}
  point=seen;return HellPointReady(text,seen);
 }
 bool HellPointReady(string text,Point seen){
  if(hellWordFrame!=traceFrame){hellWordFrame=traceFrame;if(hellWord==text&&Math.Abs(seen.X-hellWordPoint.X)<=3&&Math.Abs(seen.Y-hellWordPoint.Y)<=3)hellWordCount++;else{hellWord=text;hellWordPoint=seen;hellWordCount=1;}}
  return hellWordCount>=2;
 }
 void HellSet(HellRouteStage stage){hellRoute.Set(stage,ClockSeconds());hellWord="";hellWordCount=0;hellText.Reset();TraceEvent("hell_stage","stage",stage,"coordinate",GoalText(navigationSettings.Mingjie));}
 void HellLog(string reason){engine.Status="冥界路线："+reason;double now=ClockSeconds();if(reason!=hellLastLog||now-hellLogAt>=10){hellLastLog=reason;hellLogAt=now;Log(engine.Status);}}
 bool HellTap(Bitmap frame,Point point,string reason,int maximum){double now=ClockSeconds();if(!hellRoute.CanTap(now,maximum))return false;TraceBeforeAction(frame,"冥界路线："+reason);if(!Click(point))return false;hellRoute.Tapped(now);TraceEvent("hell_action","stage",hellRoute.Stage,"reason",reason,"x",point.X,"y",point.Y,"attempt",hellRoute.Taps);HellLog(reason+"；等待新帧验证");return true;}
 bool FindHellNpc(Bitmap frame,out Point point){
  point=Point.Empty;Mask green=new Mask(frame,true);Point a=Point.Empty,b=Point.Empty;double first=npc==null?0:npc.Find(green,new Rectangle(120,80,880,420),out a);
  double second=hellTransfer==null?0:hellTransfer.Find(green,new Rectangle(120,80,880,420),out b);
  if(second>=.85){point=new Point(b.X,b.Y-28);return true;}if(first>=.85){point=a;return true;}return false;
 }
 bool FindHellPortal(Bitmap frame,out Point point,out string detail){
  point=Point.Empty;detail="鬼门关完整入口未确认";if(hellPortal==null)return false;Point label;
  double score=hellPortal.Find(new Mask(frame,true),new Rectangle(100,55,850,450),out label);
  if(score<.86)return false;if(!HellPortalPoint(label,ReadBoss(frame).Entry.HasValue,out point)){detail="鬼门关入口与顶部菜单重叠，先换位；禁止点击活动图标";return false;}
  int blue=0,total=0;var box=new Rectangle(point.X-40,point.Y-42,80,85).IntersectSafe(frame);int[] pixels=FrameCache.Pixels(frame);
  for(int y=box.Top;y<box.Bottom;y+=2)for(int x=box.Left;x<box.Right;x+=2){int c=pixels[y*1216+x],r=(c>>16)&255,g=(c>>8)&255,b=c&255;total++;if(b>140&&b>g*1.12)blue++;}
  detail="鬼门关完整三字="+score.ToString("0.00")+"；传送门颜色="+(total==0?0:(double)blue/total).ToString("0.00");
  return total>0&&blue>total*.08&&point.X>=100&&point.X<950&&point.Y>=40&&point.Y<500;
 }
 bool HellRedCondition(Bitmap frame){int count=0;int[] pixels=FrameCache.Pixels(frame);for(int y=380;y<535;y++)for(int x=650;x<960;x++){int c=pixels[y*1216+x],r=(c>>16)&255,g=(c>>8)&255,b=c&255;if(r>170&&r>g*2.5&&r>b*2.5)count++;}return count>90;}
 void FailHell(Bitmap frame,int scene,string reason){
  LoadMapPriority();var stuck=upgradeMapVision.ReadDialog(frame);
  if(stuck.Present&&stuck.Name=="鬼门关"&&stuck.Close.HasValue){TraceBeforeAction(frame,"冥界失败收尾：关闭已确认鬼门关详情");Click(stuck.Close.Value);}
  HellLog(reason+"；冷却5分钟；"+(scene==5?"有限尝试返回神龙帝国，再走原路线":"恢复原五图兜底"));TraceEvent("hell_failure","stage",hellRoute.Stage,"scene",scene,"reason",reason,"entry_issued",hellRoute.EntryIssued);SaveDiagnostic(frame,scene,"hell-route-failure");hellRoute.Fail(scene==5,ClockSeconds());hellWordCount=0;hellText.Reset();engine.ResetPending();engine.ResetObservation();
 }
 bool HandleHellRoute(Bitmap frame){
  if(!guardRequested||!engine.Running||coordCalibration.Active)return false;LoadHellRoute();
  // Do not preempt an already owned BOSS/maintenance window. Admission only
  // happens on a positively recognized hall, and this flow owns its dialogs.

  int scene=ReadHellMap(frame);if(scene<0)scene=CalibrationMap(frame);
  if(hellSceneFrame!=traceFrame){hellSceneFrame=traceFrame;if(scene==hellScene)hellSceneCount++;else{hellScene=scene;hellSceneCount=1;}}
  bool stable=hellSceneCount>=3;double now=ClockSeconds();
  LoadMapPriority();UpgradeMapReading gate=upgradeMapVision.ReadDialog(frame);
  bool actualGate=gate.Present&&gate.Name=="鬼门关";
  if(hellRoute.Stage==HellRouteStage.Idle&&stable&&!actualGate&&(scene==0||scene==3||scene==5)&&now>=hellRoute.RetryAt&&hellRoute.EntryIssued){
   hellRoute.EntryIssued=false;Log("鬼门关调度：实际大厅三帧确认，清除上次提交标记；大厅="+scene+"；重新允许优先下图");TraceEvent("hell_rearm","scene",scene,"entry_issued",false,"reason","verified_hall");
  }
  if(hellRoute.Stage==HellRouteStage.Idle&&(BossOwnsWindow||maintenanceTask!=null)){HellSkip("窗口由BOSS或维护任务处理",scene);return false;}
  if(hellRoute.Stage==HellRouteStage.Idle&&hellEnabled.Checked&&mapPriority.CurrentLevel>=80&&scene==3&&!stable&&now>=hellRoute.RetryAt){HellLog("神龙帝国已看到，先完成三帧确认；鬼门关优先，暂停普通地图入口");return true;}
  if(!actualGate&&!BossOwnsWindow&&maintenanceTask==null&&(hellRoute.Stage!=HellRouteStage.Idle||scene==5)){
   if(farmPopupDetector==null)farmPopupDetector=new FarmPopupDetector(System.IO.Path.Combine(root,"templates"));
   var blocking=farmPopupDetector.ReadRoute(frame);
   if(blocking.Panel&&blocking.CanClose&&!blocking.MapDetail){
    if(HellPointReady("冥界遮挡关闭",blocking.ClosePoint)&&HellTap(frame,blocking.ClosePoint,"关闭已确认遮挡窗口；重新观察鬼门关入口",4)){
     if(hellRoute.Stage==HellRouteStage.Portal||hellRoute.Stage==HellRouteStage.Detail){HellSet(HellRouteStage.Walk);hellWalk=NewHellWalk();}
    }
    else HellLog("冥界窗口遮挡，等待两帧完整关闭按钮；不点击奖励");return true;
   }
  }
  if(actualGate&&!hellRoute.EntryIssued&&hellRoute.Stage!=HellRouteStage.Detail&&hellRoute.Stage!=HellRouteStage.Arrival&&hellRoute.Stage<HellRouteStage.ReturnNpc&&(hellRoute.Stage!=HellRouteStage.Idle||hellEnabled.Checked&&now>=hellRoute.RetryAt)){
   if(hellRoute.Stage==HellRouteStage.Idle)hellRoute.Started=now;
   HellSet(HellRouteStage.Detail);HellLog("鬼门关实际详情已打开；核对80级、500碎片及进入按钮");
  }
  if(scene==4&&!stable){HellLog("鬼门关原生标题已看到，等待三张新截图确认；暂停其他点击");return true;}
  if(scene==4&&stable){
   bool ghost=ReadHellMap(frame)==4;
   if(ghost){
    if(hellRoute.Stage!=HellRouteStage.Idle){HellLog("实际鬼门关地图名已确认；检查右侧自动按钮");hellRoute.Reset(false);hellRoute.EntryIssued=false;hellRoute.RetryAt=0;TraceEvent("hell_arrival_confirmed","scene",4,"entry_issued",false);engine.ResetPending();engine.ResetObservation();ResetAutoBattle();}
    if(ReadAutoBattle(frame).State!=AutoBattleState.On){CheckAuto(frame,true);return true;}
    return false;
   }
  }
  if(hellRoute.Stage==HellRouteStage.Idle){
   if(scene==0&&stable){hellRoute.EntryIssued=false;return false;}
   if(!hellEnabled.Checked){HellSkip("80级鬼门关优先开关关闭",scene);return false;}
   if(scene==5&&stable&&!actualGate&&now>=hellRoute.RetryAt&&hellRoute.EntryIssued){hellRoute.EntryIssued=false;HellLog("三帧确认已返回冥界大厅，结束上次入图预算，开始新一轮下图");}
   if(stable&&(scene==3||scene==5)&&hellRoute.CanStart(mapPriority.CurrentLevel,now)){hellRoute.Begin(scene==5,now);hellWalk=NewHellWalk();hellText.Reset();engine.ResetPending();HellLog("80级已确认；优先进入鬼门关，先核对大陆和坐标");}
   else if(scene==5&&stable){hellRoute.Started=now;hellRoute.Set(now>=hellRoute.RetryAt?HellRouteStage.ReturnNpc:HellRouteStage.Hold,now);}
   else return false;
  }
  // NPC may teleport directly. Actual arrival wins over an expected menu.
  // Never re-enter from a submitted Ghost Gate or renew a failed walk budget.
  if(scene==5&&stable&&hellRoute.CanAcceptHellArrival(mapPriority.CurrentLevel)){
   HellSet(HellRouteStage.Walk);hellWalk=NewHellWalk();engine.ResetPending();
   HellLog("已确认实际到达冥界，跳过未出现的大陆菜单；开始走到"+GoalText(navigationSettings.Mingjie));
  }
  if(hellRoute.Stage==HellRouteStage.Hold){
   if(scene!=5&&stable){hellRoute.Reset(false);return false;}
   HellLog("冥界入图/返回未确认，暂停坐标点击；5分钟后复核，F8可停止");
   if(now>=hellRoute.RetryAt&&!actualGate&&stable&&mapPriority.CurrentLevel>=80){hellRoute.EntryIssued=false;hellRoute.Begin(true,now);hellWalk=NewHellWalk();hellText.Reset();HellLog("冷却结束且三帧确认仍在冥界，重新走鬼门关；不重复返回循环");}return true;
  }
  bool returning=hellRoute.Stage>=HellRouteStage.ReturnNpc;
  if(returning&&scene==3&&stable){HellLog("已回神龙帝国，恢复叛军基地等原路线；冥界仍在冷却");hellRoute.Reset(false);engine.ResetPending();engine.ResetObservation();return false;}
  if(hellRoute.Expired(now)){
   if(returning){hellRoute.RetryAt=now+300;HellSet(HellRouteStage.Hold);HellLog("返回神龙超时，释放所有点击；冷却后复核");SaveDiagnostic(frame,scene,"hell-return-timeout");}
   else FailHell(frame,scene,"步骤"+hellRoute.Stage+"超时（"+hellRoute.Limit+"秒）");return true;
  }
  // Recover a collapsed minimap without renewing this route's deadline.
  // Dialog ownership remains with this route; only recover on world stages.
  if((hellRoute.Stage==HellRouteStage.Walk||hellRoute.Stage==HellRouteStage.Npc||hellRoute.Stage==HellRouteStage.ReturnNpc)&&ReadMinimap(frame).State==MinimapState.Collapsed){EnsureMinimapVisible(frame);HellLog("小地图收起，有限展开后重新核对地图和坐标");return true;}
  Point p;string detail;
  switch(hellRoute.Stage){
   case HellRouteStage.Npc:case HellRouteStage.ReturnNpc:
    string shell;if(hellText.Contains(frame,"大陆传送",out shell)&&hellText.Contains(frame,hellRoute.Stage==HellRouteStage.Npc?"冥界":"神龙帝国",out shell)){HellSet(returning?HellRouteStage.ReturnMenu:HellRouteStage.Destination);return true;}
    if(!stable||(scene!=3&&scene!=5)){HellLog("等待实际大厅地图名，禁止猜点");return true;}
    if(FindHellNpc(frame,out p))HellTap(frame,p,"点击已识别大陆传送",3);
    else {if(scene==3)MoveByCoordinate(frame,3,navigationSettings.Shenlong.Point,shenWalk);HellLog("限时寻找大陆传送；未识别时不点击");}return true;
   case HellRouteStage.Destination:case HellRouteStage.ReturnMenu:
    string target=returning?"神龙帝国":"冥界";string menu;
    if(hellText.Contains(frame,"大陆传送",out menu)&&HellWordReady(frame,new[]{target,"进入"+target},out p,out detail)&&HellTap(frame,p,"选择大陆："+target,1))HellSet(returning?HellRouteStage.ReturnTravel:HellRouteStage.Travel);
    else HellLog("等待完整大陆名称和两帧按钮定位："+target);return true;
   case HellRouteStage.Travel:
    if(scene==5&&stable){HellSet(HellRouteStage.Walk);hellWalk=NewHellWalk();HellLog("实际冥界地图名已确认，走到"+GoalText(navigationSettings.Mingjie));return true;}
    string world;
    if(hellText.Contains(frame,"冥界",out world)&&!HellRedCondition(frame)&&HellWordReady(frame,new[]{"进入冥界","进入大陆","进入地图","确认传送"},out p,out detail))HellTap(frame,p,"确认进入冥界（仅一次）",1);
    else HellLog("等待进入冥界验证/明确确认按钮");return true;
   case HellRouteStage.Walk:
    if(scene!=5||!stable){HellLog("冥界标题不清晰，暂停走路并等待");return true;}
    int x,y;string coord;if(TryReadCoordDigits(frame,0,out x,out y,out coord)&&x<=99&&y<=99&&(navigationSettings.Mingjie.IsReady(new Point(x,y),hellWalk)||hellWalk.GoalSeen&&Math.Abs(x-navigationSettings.Mingjie.X)+Math.Abs(y-navigationSettings.Mingjie.Y)<=3)){
     if(FindHellPortal(frame,out p,out detail)){if(HellPointReady("鬼门关入口",p)&&HellTap(frame,p,"坐标到位后点击鬼门关；"+detail,2))HellSet(HellRouteStage.Portal);return true;}
    }
    if(hellWalk.GoalSeen)HellLog("已到冥界目标坐标，入口未确认；有限换位到上方3格避开顶部菜单遮挡");MoveByCoordinate(frame,5,navigationSettings.Mingjie.Point,hellWalk);return true;
   case HellRouteStage.Portal:case HellRouteStage.Detail:
    if(actualGate){
     if(gate.Requirements=="red"){FailHell(frame,scene,"鬼门关原生详情进入条件为红色，停止提交");return true;}
     if(gate.Requirements=="green"&&gate.Enter.HasValue&&!hellRoute.EntryIssued){
      if(HellPointReady("鬼门关原生进入地图",gate.Enter.Value)&&HellTap(frame,gate.Enter.Value,"鬼门关完整详情、80级和500碎片均绿色；单次进入",1)){hellRoute.EntryIssued=true;HellSet(HellRouteStage.Arrival);}
      else HellLog("鬼门关原生条件通过，等待第二张新截图确认进入按钮");
     }else{hellWordCount=0;HellLog("鬼门关详情条件/按钮尚未读清；"+gate.Detail);}
     return true;
    }
    string page;if(hellText.Contains(frame,"鬼门关",out page)&&hellText.Contains(frame,"地图传送",out page)){
     if(HellRedCondition(frame)){FailHell(frame,scene,"鬼门关详情出现红色进入条件，停止提交");return true;}
     if(HellWordReady(frame,new[]{"进入地图","进入鬼门关"},out p,out detail)&&!hellRoute.EntryIssued&&HellTap(frame,p,"确认鬼门关进入；本周期仅一次",1)){hellRoute.EntryIssued=true;HellSet(HellRouteStage.Arrival);}else HellLog("等待鬼门关完整详情及进入按钮");return true;
    }
    if(scene==5&&stable&&hellRoute.CanTap(now,2)&&FindHellPortal(frame,out p,out detail))HellTap(frame,p,"鬼门关入口未打开，有限重试；"+detail,2);
    else HellLog("等待鬼门关详情或实际地图切换");return true;
   case HellRouteStage.Arrival:HellLog("进入已提交，等待实际鬼门关地图名；不重复消耗");return true;
   case HellRouteStage.ReturnTravel:
    string returnPage;if(hellText.Contains(frame,"神龙帝国",out returnPage)&&!HellRedCondition(frame)&&HellWordReady(frame,new[]{"进入神龙帝国","进入大陆","进入地图","确认传送"},out p,out detail))HellTap(frame,p,"确认返回神龙帝国（仅一次）",1);
    else HellLog("等待返回神龙帝国；不点击其他入口");return true;
  }
  return true;
 }
}

