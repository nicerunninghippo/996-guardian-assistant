using System;

// A failed observation or a failed round delays actions; only Stop ends guarding.
class Engine {
 public int Stable=-9,Count,Pending=-1,Attempts,Returns,Failures;
 public bool Running,Returning;
 public double Since,UnknownSince=-1,RetryAt=-1;
 public string Status="待机";
 double invisibleSince=-1;
 int routeMap=-9;

 public void Start(){
  Running=true;Returning=false;RetryAt=-1;Since=0;
  ResetObservation();ResetPending();Status="等待连续三帧识别";
 }
 public void Stop(string reason){
  Running=false;RetryAt=-1;ResetObservation();ResetPending();Status=reason;
 }
 public void ResetObservation(){Stable=-9;Count=0;UnknownSince=-1;}
 public void ResetPending(){Pending=-1;Attempts=0;invisibleSince=-1;routeMap=-9;}
 public void Recover(string reason,double now,double delaySeconds){
  // The UI calls this only while guardRequested is true; Step never restarts itself.
  Running=true;
  ResetObservation();ResetPending();Since=now;
  RetryAt=now+Math.Max(.5,delaySeconds);
  Status=reason+"；"+Math.Max(.5,delaySeconds).ToString("0.#")+"秒后重新寻找（守护继续）";
 }
 public bool Step(int map,bool actionable,double now){
  if(!Running||now<RetryAt)return false;
  RetryAt=-1;
  if(map==Stable)Count++;else{Stable=map;Count=1;}
  if(map<0){
   if(UnknownSince<0)UnknownSince=now;
   Status="地图暂未识别，持续观察";
   if(now-UnknownSince>=45){Failures++;Recover("地图连续45秒未识别，开始新一轮扫描",now,3);}
   return false;
  }
  UnknownSince=-1;
  if(Count<3){Status="等待连续三帧识别";return false;}
  if(Pending>=0){
   if(map==4||map>Pending){ResetPending();}
   else if(map<Pending){
    Recover("检测到返回前面的地图，重新规划回图路线",now,1);return false;
   }else if(now-Since<(Pending==3?4:15)){
    Status="等待下一地图验证";return false;
   }else if(Attempts>=(Pending==3?8:(Pending==0?6:3))){
    Failures++;Recover("本轮传送"+Attempts+"次未确认，重新定位传送点",now,3);return false;
   }else{Pending=-1;}
  }
  if(map==4){
   if(Returning){Returns++;Returning=false;}
   ResetPending();Status="目标地图 · 守护中";return false;
  }
  if(routeMap!=map){ResetPending();routeMap=map;}
  Returning=true;
  if(!actionable){
   if(invisibleSince<0)invisibleSince=now;
   Status="持续寻找大陆传送/传送门";
   if(now-invisibleSince>=90){Failures++;Recover("传送目标90秒未出现，开始新一轮寻找",now,3);}
   return false;
  }
  invisibleSince=-1;Pending=map;Attempts++;Since=now;
  Status="点击后等待地图切换（本轮第"+Attempts+"次）";
  return true;
 }
}
