using System;

static class RouteEngineTests {
 static void Check(bool condition,string reason){if(!condition)throw new Exception("持续守护测试失败："+reason);}
 static void Confirm(Engine e,int map,bool action,double now){
  Check(!e.Step(map,action,now),"第一帧不能点击");
  Check(!e.Step(map,action,now+1),"第二帧不能点击");
  Check(e.Step(map,action,now+2)==action,"第三帧按可操作状态决定点击");
 }
 public static int Run(){
  // Route retries can span many rounds, with cooldown and fresh observations each round.
  foreach(int map in new[]{0,1,2,3}){
   var e=new Engine();e.Start();double t=0;int limit=map==0?6:(map==3?8:3),wait=map==3?4:15;
   for(int round=0;round<3;round++){
    Confirm(e,map,true,t);t+=2;
    for(int a=1;a<limit;a++){
     Check(!e.Step(map,true,t+wait-.1),"传送等待期不得重复点击");
     t+=wait;Check(e.Step(map,true,t),"轮内允许重试");
    }
    t+=wait;Check(!e.Step(map,true,t)&&e.Running&&e.Pending<0,"超限重新寻找，不结束守护");
    Check(!e.Step(map,true,t+1),"轮间冷却不能点击");
    t+=3;
   }
   Check(e.Failures==3,"每个失败轮次只计一次");
  }
  {
   var e=new Engine();e.Start();double t=0;
   for(int n=0;n<4;n++){
    e.Step(-1,false,t);e.Step(-1,false,t+45);
    Check(e.Running&&e.RetryAt==t+48,"未知地图持续扫描");t+=48;
   }
   for(int n=0;n<4;n++){
    Confirm(e,1,false,t);e.Step(1,false,t+92);
    Check(e.Running&&e.RetryAt==t+95,"不可见目标持续寻找");t+=95;
   }
  }
  {
   var e=new Engine();e.Start();Confirm(e,3,true,0);
   e.Step(0,true,3);e.Step(0,true,4);
   Check(!e.Step(0,true,5)&&e.Running&&e.Pending<0,"死亡回城重置旧传送等待");
   Confirm(e,0,true,6);Check(e.Pending==0&&e.Attempts==1,"回城从当前地图重新出发");
  }
  {
   var e=new Engine();e.Start();double t=0;
   for(int map=0;map<4;map++){Confirm(e,map,true,t);t+=3;}
   Confirm(e,4,false,t);e.Step(4,false,t+3);
   Check(e.Returns==1&&e.Running,"成功回图仅计一次");
  }
  {
   var e=new Engine();e.Start();e.Recover("临时读取失败",0,3);e.Stop("F8已停止");
   for(int t=20;t<100;t++)Check(!e.Step(0,true,t),"手动停止后绝不自动点击");
   Check(!e.Running&&e.Status=="F8已停止","Step不得覆盖手动停止");
  }
  return 5;
 }
}
