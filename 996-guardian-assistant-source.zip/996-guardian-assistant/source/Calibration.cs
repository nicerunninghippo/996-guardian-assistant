using System;
using System.Drawing;
using System.Linq;

// Calibration owns movement only while the normal guardian is stopped.
static class CalibrationInput {
 public static bool Send(bool active, bool running, bool connected, bool stop,
     Point from, Point to, int ms, Func<Point,Point,int,bool> send) {
  if (!active || running || !connected || stop) return false;
  return send(from,to,ms);
 }
}

class DirectionCalibration {
 public static readonly Point[] Offsets = {new Point(0,-62),new Point(44,-44),new Point(62,0),new Point(44,44),new Point(0,62),new Point(-44,44),new Point(-62,0),new Point(-44,-44)};
 public static readonly string[] Names = {"上","右上","右","右下","下","左下","左","左上"};
 public const int Duration = 550;
 public bool Active, Complete, Success;
 public int Map, Index, Sent;
 public Point Center;
 public readonly int[] Dx = new int[8], Dy = new int[8];
 public string Status="";
 public double NextAt;
 bool after;
 int samples, same, retry;
 Point? candidate;
 Point origin;

 public void Begin(int map, Point center) {
  Map=map;Center=center;Index=Sent=0;Active=true;Complete=Success=false;
  after=false;retry=0;NextAt=0;Array.Clear(Dx,0,8);Array.Clear(Dy,0,8);ResetSamples();
  Status="方向校准开始：等待两帧一致的起点坐标；F8或停止按钮可取消";
 }
 void ResetSamples(){candidate=null;same=samples=0;}
 public void Cancel(string reason){Active=false;Complete=true;Success=false;Status=reason;}
 public static bool ValidTable(int[] dx,int[] dy,out string reason) {
  reason="";
  if(dx==null||dy==null||dx.Length!=8||dy.Length!=8){reason="方向表必须包含8个方向";return false;}
  int valid=0;
  for(int i=0;i<8;i++) {
   int length=Math.Abs(dx[i])+Math.Abs(dy[i]);
   if(length>24){reason="短步坐标变化异常，拒绝保存";return false;}
   if(length>0)valid++;
  }
  if(valid<4 || !dx.Any(v=>v>0) || !dx.Any(v=>v<0) || !dy.Any(v=>v>0) || !dy.Any(v=>v<0)) {
   reason="有效方向不足：需要实测到X、Y各自增大和减小；请检查跑/走圆心是否框准、是否被挡住";return false;
  }
  bool spans=false;
  for(int i=0;i<8;i++)for(int j=i+1;j<8;j++)if(dx[i]*dy[j]-dy[i]*dx[j]!=0)spans=true;
  if(!spans){reason="仅测到一条直线，不能据此判断全部方向";return false;}
  return true;
 }
 // Called by the UI timer, never by the normal route/click pipeline.
 public void Step(Point? coord,int map,double now,Func<Point,Point,int,bool> send,Action<string> log) {
  if(!Active||now<NextAt)return;
  if(map>=0&&map!=Map){Cancel("校准中地图已变化，已中止；本次数据未保存");return;}
  if(map<0)coord=null;
  samples++;
  if(coord.HasValue&&candidate.HasValue&&coord.Value==candidate.Value)same++;
  else{candidate=coord;same=coord.HasValue?1:0;}
  if(same<2){
   Status="校准"+Names[Index]+"：等待"+(after?"移动后":"移动前")+"坐标稳定（"+samples+"/6）";
   if(samples>=6)Cancel("校准"+Names[Index]+"：连续6帧坐标未读稳，已中止；本次数据未保存");
   return;
  }
  Point current=coord.Value;ResetSamples();
  if(!after){
   origin=current;
   Point off=Offsets[Index], to=new Point(Center.X+off.X,Center.Y+off.Y);
   if(!send(Center,to,Duration)){Cancel("校准"+Names[Index]+"：移动指令未发出，检查连接或停止状态；本次数据未保存");return;}
   Sent++;after=true;NextAt=now+1.3;
   Status="校准"+Names[Index]+"：移动指令已发出，等待坐标变化";
   log("校准"+Names[Index]+" 指令已发出：摇杆("+Center.X+","+Center.Y+")→("+to.X+","+to.Y+")，"+Duration+"ms；起点"+origin.X+":"+origin.Y);
   return;
  }
  int dx=current.X-origin.X,dy=current.Y-origin.Y;
  log("校准"+Names[Index]+" 反馈："+origin.X+":"+origin.Y+" → "+current.X+":"+current.Y+"，变化X"+dx+" Y"+dy);
  if(Math.Abs(dx)+Math.Abs(dy)>24){Cancel("校准"+Names[Index]+"：短步坐标跳变过大，疑似读数错误或传送；本次数据未保存");return;}
  if(dx==0&&dy==0&&retry==0){
   retry++;after=false;Status="校准"+Names[Index]+"：指令已发出但坐标未变，将重新读取起点并重试一次";log(Status);return;
  }
  Dx[Index]=dx;Dy[Index]=dy;Index++;retry=0;after=false;NextAt=now;
  if(Index<8){Status="准备校准"+Names[Index];return;}
  string reason;Success=ValidTable(Dx,Dy,out reason);Active=false;Complete=true;
  Status=Success?"8方向采集完成，正在保存":"方向校准未通过："+reason+"；本次数据未保存";
 }
}
