﻿using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Collections.Generic;

// Only uses the emulator's ADB screenshot and Android input interfaces.
// No desktop capture, foreground activation or Windows mouse injection.
class BackgroundDevice {
 public string ConsolePath,AdbPath,Serial; public int Width,Height; public int Index;
 public Action<string> Report;
 static byte[] Run(string exe,string args,int timeout){
  var si=new ProcessStartInfo(exe,args){UseShellExecute=false,RedirectStandardOutput=true,RedirectStandardError=true,CreateNoWindow=true};
  using(var p=Process.Start(si))using(var bytes=new MemoryStream()){
   var read=Task.Factory.StartNew(()=>p.StandardOutput.BaseStream.CopyTo(bytes));var err=Task.Factory.StartNew(()=>p.StandardError.ReadToEnd());
   if(!p.WaitForExit(timeout)){try{p.Kill();}catch{}try{Task.WaitAll(new Task[]{read,err},2000);}catch{}throw new TimeoutException("雷电后台接口超时："+Path.GetFileName(exe)+" "+args+"；等待="+timeout+"ms");}
   if(!Task.WaitAll(new Task[]{read,err},2000))throw new TimeoutException("雷电后台输出读取超时："+Path.GetFileName(exe)+" "+args);
   if(p.ExitCode!=0)throw new Exception("后台接口失败："+Path.GetFileName(exe)+" "+args+"；"+err.Result.Trim());return bytes.ToArray();
  }
 }
 // Retry only explicit read-only operations. Android tap/swipe submissions
 // still use Run once: a timeout does not prove that an input was rejected.
 internal static byte[] ReadWithRetry(string exe,string args,int timeout,Action<string> report){
  try{return Run(exe,args,timeout);}catch(TimeoutException ex){
   if(report!=null)report(ex.Message+"；只读操作重试一次");
   return Run(exe,args,timeout+timeout/2);
  }
 }
 string ReadText(string exe,string args){var watch=Stopwatch.StartNew();string text=Encoding.Default.GetString(ReadWithRetry(exe,args,8000,Report)).Trim();if(Report!=null)Report("连接检查："+Path.GetFileName(exe)+" "+args+"；耗时="+watch.ElapsedMilliseconds+"ms；结果="+text);return text;}
 public static string Text(string exe,string args){return Encoding.Default.GetString(Run(exe,args,8000)).Trim();}
 public static string Discover(){
  foreach(var p in Process.GetProcessesByName("dnplayer")){try{string f=Path.Combine(Path.GetDirectoryName(p.MainModule.FileName),"ldconsole.exe");if(File.Exists(f))return f;}catch{}finally{p.Dispose();}}
  return null;
 }
 public void Connect(IntPtr window,string console){
  if(string.IsNullOrEmpty(console)||!File.Exists(console))throw new Exception("未找到雷电接口，请点击‘选择雷电目录’");
  ConsolePath=console;AdbPath=Path.Combine(Path.GetDirectoryName(console),"adb.exe");if(!File.Exists(AdbPath))throw new Exception("雷电目录中缺少adb.exe");
  bool matched=false;foreach(string line in ReadText(console,"list2").Split('\n')){string[] a=line.Trim().Split(',');long h;int idx;if(a.Length>=5&&int.TryParse(a[0],out idx)&&long.TryParse(a[2],out h)&&h==window.ToInt64()&&a[4]=="1"){Index=idx;matched=true;break;}}
  if(!matched)throw new Exception("所选雷电实例未启动或窗口已变化，请刷新后重连");
  Serial=ReadText(console,"adb --index "+Index+" --command \"get-serialno\"");
  if(!Regex.IsMatch(Serial,@"\A(?:emulator-\d+|127\.0\.0\.1:\d+)\z"))throw new Exception("雷电未提供可用的本地ADB连接："+Serial+"。请检查雷电ADB是否已开启；助手不会修改该设置。");
  if(ReadText(AdbPath,"-s "+Serial+" get-state")!="device")throw new Exception("指定雷电ADB未就绪："+Serial);
 }
 public Bitmap Capture(){if(string.IsNullOrEmpty(Serial))throw new Exception("请先连接雷电后台接口");byte[] png=ReadWithRetry(AdbPath,"-s "+Serial+" exec-out screencap -p",8000,Report);
  if(png.Length<8||png[0]!=137||png[1]!=80||png[2]!=78||png[3]!=71)throw new Exception("后台截图无效，已停止");
  using(var ms=new MemoryStream(png))using(var b=new Bitmap(ms)){Width=b.Width;Height=b.Height;if(Width<600||Height<300||Math.Abs((double)Width/Height-16.0/9)>.03)throw new Exception("当前游戏画面不是横屏16:9；请保持原有雷电分辨率");return new Bitmap(b);}
 }
 public bool Tap(Point p){if(Width<=0||Height<=0||p.X<0||p.Y<0||p.X>=1216||p.Y>=684)throw new Exception("后台点击坐标无效");
  int x=(int)Math.Round((double)p.X*Width/1216),y=(int)Math.Round((double)p.Y*Height/684);
  Text(AdbPath,"-s "+Serial+" shell input tap "+x+" "+y);return true;
 }
 public bool Swipe(Point from,Point to,int ms){if(Width<=0||Height<=0||from.X<0||from.Y<0||to.X<0||to.Y<0||from.X>=1216||from.Y>=684||to.X>=1216||to.Y>=684)throw new Exception("后台滑动坐标无效");
  int x1=(int)Math.Round((double)from.X*Width/1216),y1=(int)Math.Round((double)from.Y*Height/684),x2=(int)Math.Round((double)to.X*Width/1216),y2=(int)Math.Round((double)to.Y*Height/684);
  Text(AdbPath,"-s "+Serial+" shell input swipe "+x1+" "+y1+" "+x2+" "+y2+" "+Math.Max(100,ms));return true;
 }
}
