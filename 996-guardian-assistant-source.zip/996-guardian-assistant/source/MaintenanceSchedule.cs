using System;
using System.Collections.Generic;

// The guard remains alive. A failed bounded task is deferred, never reset
// immediately in the same tick. No task may monopolize input indefinitely.
public sealed class MaintenanceSchedule {
 readonly Queue<string> pending=new Queue<string>();
 readonly Dictionary<string,double> retryAt=new Dictionary<string,double>();
 readonly Dictionary<string,int> retries=new Dictionary<string,int>();
 public double NextCycle,NextMail;
 public string Active="";
 public double Started;
 public void Reset(){pending.Clear();retryAt.Clear();retries.Clear();Active="";NextCycle=NextMail=0;Started=0;}
 public void Start(double now){Reset();NextCycle=now;}
 public double RetryTime(string id){return id=="mail"?NextMail:retryAt.ContainsKey(id)?retryAt[id]:0;}
 // Cheap admission check before any image processing. It does not consume
 // queued work or advance a four-hour cycle.
 public bool HasDueWork(double now){
  if(Active.Length>0)return false;
  if(now>=NextCycle||pending.Count>0)return true;
  foreach(var p in retryAt)if(now>=p.Value)return true;
  return false;
 }
 public void Finish(string id,double now,bool success,bool moreItems){
  if(id!=Active||Active.Length==0)return;
  Active="";
  if(id=="mail"){NextMail=now+(success?60:300);return;}
  int count=retries.ContainsKey(id)?retries[id]:0;
  // Only verified item consumption can request a continuation. Each batch is
  // bounded by its own deadline and yields five minutes to the normal guard.
  if(id=="items"&&moreItems&&success){retryAt[id]=now+300;return;}
  if(!success&&count<1){retries[id]=count+1;retryAt[id]=now+300;}
 }
 public string Next(double now,bool ready,bool mailVisible,bool includeItems){
  if(Active.Length>0||!ready)return "";
  if(now>=NextCycle){
   NextCycle=now+4*3600;pending.Clear();retryAt.Clear();retries.Clear();
   pending.Enqueue("online");pending.Enqueue("daily");pending.Enqueue("merge");if(includeItems)pending.Enqueue("items");
  }
  string id="";
  if(mailVisible&&now>=NextMail)id="mail";
  else if(pending.Count>0)id=pending.Dequeue();
  else{foreach(var p in retryAt)if(now>=p.Value){id=p.Key;break;}if(id.Length>0)retryAt.Remove(id);}
  if(id.Length>0){Active=id;Started=now;}return id;
 }
 public bool Expired(double now){return Active.Length>0&&now-Started>210;}
}
