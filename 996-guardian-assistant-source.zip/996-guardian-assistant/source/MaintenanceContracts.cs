using System;
using System.Drawing;

// Every task consumes one fresh frame per Step and proposes at most one tap.
// The host is the only component allowed to send emulator input.
public sealed class MaintenanceDecision {
 public Point? Tap;
 public bool Done,Success;
 public string Status="";
}
public interface IMaintenanceTask {
 string Name {get;}
 bool Active {get;}
 void Begin(double now);
 MaintenanceDecision Step(Bitmap frame,double now);
 void Reset();
}
