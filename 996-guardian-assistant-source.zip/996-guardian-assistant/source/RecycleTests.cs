using System;
using System.Drawing;
using System.IO;
class RecycleTests {
 static void Check(bool ok,string name){if(!ok)throw new Exception("回收自检失败："+name);}
 public static string Run(string root){int n=0;var vision=new RecycleVision(root);
  using(var b=new Bitmap(Path.Combine(root,"tests","recycle5.png"))){var v=vision.Read(b);Check(v.Bag&&v.Entry&&!v.Page,"背包标题和回收入口识别");n++;}
  using(var b=new Bitmap(Path.Combine(root,"tests","recycle4.png"))){var v=vision.Read(b);Check(v.Page&&v.OneKey,"回收标题和一键回收识别");n++;}
  using(var b=new Bitmap(Path.Combine(root,"tests","route0.png"))){Check(vision.Read(b).Icon,"背包按钮识别");n++;}
  using(var b=new Bitmap(1216,684)){var v=vision.Read(b);Check(!v.Bag&&!v.Page&&!v.OneKey&&!v.Icon,"黑屏不点回收");n++;}
  var f=new RecycleFlow();f.Begin(0);var screen=new RecycleView{Icon=true,IconAt=new Point(1180,260)};int clicks=0;
  for(int t=0;t<80&&f.Completed==0&&!f.Failed;t++){int stage=f.Stage;Point? p=f.Step(screen,screen.Page?-1:4,t);if(!p.HasValue)continue;clicks++;
   if(stage==1)screen=new RecycleView{Bag=true,Entry=true,BagAt=new Point(400,95),EntryAt=new Point(445,485)};
   if(stage==2)screen=new RecycleView{Page=true,OneKey=true,PageAt=new Point(620,90),OneAt=new Point(730,560)};
   if(stage==5)screen=new RecycleView{Bag=true,BagAt=new Point(900,45)};
   if(stage==6)screen=new RecycleView{Icon=true};
  }Check(f.Completed==1&&f.Clicks==1&&clicks==5&&!f.Failed,"五步闭环和只提交一次");n++;
  f=new RecycleFlow();f.Begin(0);for(int t=0;t<24;t++)f.Step(new RecycleView(),4,t);Check(f.Failed&&f.Clicks==0,"未知页面超时停止");n++;
  f=new RecycleFlow();f.Begin(0);f.Step(new RecycleView(),0,1);Check(f.Failed,"离开地图中断回收");n++;
  f=new RecycleFlow();f.Begin(0);f.Reset();Check(!f.Step(new RecycleView{Icon=true},4,10).HasValue,"停止无操作");n++;
  f=new RecycleFlow();f.Begin(0);int opens=0;for(int t=0;t<24;t++)if(f.Step(new RecycleView{Icon=true},4,t).HasValue)opens++;Check(f.Failed&&opens==3,"打开失败最多三次");n++;
  f=new RecycleFlow();f.Begin(0);var page=new RecycleView{Page=true,OneKey=true};f.Step(page,4,0);f.Step(page,4,1);Check(f.Failed&&f.Clicks==0,"不接管预先打开的回收页");n++;
  using(var b=new Bitmap(Path.Combine(root,"tests","adb-bag.png"))){var v=vision.Read(b);Check(v.Bag&&v.Entry,"实机后台背包截图识别");n++;}
  using(var b=new Bitmap(Path.Combine(root,"tests","adb-page.png"))){var v=vision.Read(b);Check(v.Page&&v.OneKey,"实机后台回收页面识别");n++;}
  return "回收通过 "+n+" 项：历史及后台截图识别、五步闭环、一次提交、超时停止、回城中断、停止保护、三次重试、已有弹窗保护。";
 }
}

