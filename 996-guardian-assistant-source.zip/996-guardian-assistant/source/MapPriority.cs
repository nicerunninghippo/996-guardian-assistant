using System;
using System.Drawing;
using System.IO;
using System.Text;

public static class PriorityEntryGate {
 public static bool Allows(MapPriorityState state,UpgradeMapReading seen,out string reason){
  reason="没有本轮已确认的目标传送门";int active=state.Active;
  if(active<0||active>=state.Maps.Length||state.Failed[active])return false;
  RouteMapDefinition map=state.Maps[active];
  if(!seen.Present||seen.Name!=map.Name){reason="详情名称不一致：预期="+map.Name+"，实际="+seen.Name;return false;}
  if(!map.Enabled||map.MinLevel>0&&state.CurrentLevel<map.MinLevel){reason="主角色等级未满足或尚未确认：当前="+state.CurrentLevel+"，要求="+map.MinLevel;return false;}
  if(seen.Requirements!="green"){reason="进入条件尚未全部绿色："+seen.Requirements+"；"+seen.Detail;return false;}
  if(RouteMapCatalog.IsNewMap(map)&&state.EntryIssued[active]){reason="本周期已发出一次进入指令，禁止重复提交装备碎片条件的入图操作";return false;}
  if(!seen.Enter.HasValue){reason="进入地图按钮尚未确认";return false;}
  reason="完整详情名称、等级和绿色进入条件均通过；"+seen.Detail;return true;
 }
}
partial class Guardian {
 MapPriorityState mapPriority=new MapPriorityState();
 UpgradeMapVision upgradeMapVision;StrictMapTitleReader strictMapTitleReader;PlayerLevelReader playerLevelReader;
 Mask[] priorityTitles;double[] priorityPortalScores=new double[5];Point[] priorityPortalPoints=new Point[5];
 string prioritySelectedName="",priorityLevelReason="主角色等级尚未确认",priorityOcrReason="";
 DateTime priorityDialogAt=DateTime.MinValue,priorityEntryDeadline=DateTime.MinValue,priorityLevelAt=DateTime.MinValue,priorityDialogFirst=DateTime.MinValue;
 bool closeStaleDialog,priorityTitleBlocksLegacy;string priorityDetailName="",priorityOcrCandidate="";
 DateTime priorityCloseAt=DateTime.MinValue;int priorityCloseAttempts;
 int priorityLevelCandidate=-1,priorityLevelCount,priorityDetailCount,priorityOcrCount;
 int priorityLastKnownLevel=-1;
 DateTime priorityUnknownLevelSince=DateTime.MinValue;
 long priorityLevelFrame=-1,priorityDetailFrame=-1,priorityOcrFrame=-1;
 readonly System.Windows.Forms.Label priorityInfo=new System.Windows.Forms.Label();
 void InitPriorityCatalog(){
  string warning;mapPriority=new MapPriorityState(RouteMapCatalog.Load(root,out warning));
  priorityPortalScores=new double[mapPriority.Maps.Length];priorityPortalPoints=new Point[mapPriority.Maps.Length];
  priorityInfo.Text="下图优先："+mapPriority.NameList+"；主角色等级：待识别";
  if(warning.Length>0)Log(warning);TraceEvent("route_catalog","priority",mapPriority.NameList,"configuration",Path.Combine(root,"map-routes.json"));
 }
 void LoadMapPriority(){
  if(upgradeMapVision!=null)return;
  upgradeMapVision=new UpgradeMapVision(root);playerLevelReader=new PlayerLevelReader(Path.Combine(root,"templates"));strictMapTitleReader=new StrictMapTitleReader();priorityTitles=new Mask[mapPriority.Maps.Length];
  for(int i=0;i<priorityTitles.Length;i++){string id=mapPriority.Maps[i].Id;string file=id=="panjun-camp"?"map-panjun-v47.png":id=="battle-outpost"?"map4.png":id=="dragon-claw"?"map4-adb.png":null;if(file!=null)priorityTitles[i]=Load(file,false,false);}
 }
 void ResetPriorityConnection(){
  priorityLastKnownLevel=-1;
  priorityUnknownLevelSince=DateTime.MinValue;mapPriority=new MapPriorityState(mapPriority.Maps);
  mapPriority.CurrentLevel=-1;priorityLevelCandidate=-1;priorityLevelCount=priorityDetailCount=priorityOcrCount=0;priorityLevelFrame=priorityDetailFrame=priorityOcrFrame=-1;priorityLevelAt=DateTime.MinValue;
  priorityLevelReason="连接已切换，重新确认主角色等级";priorityOcrCandidate="";if(strictMapTitleReader!=null)strictMapTitleReader.Reset();
 }
 void ObservePlayerLevel(Bitmap frame){
  LoadMapPriority();if(priorityLevelFrame==traceFrame)return;priorityLevelFrame=traceFrame;
  int value;string detail;bool read=playerLevelReader.TryRead(frame,out value,out detail);priorityLevelReason=detail;
  if(read){if(value==priorityLevelCandidate)priorityLevelCount++;else{priorityLevelCandidate=value;priorityLevelCount=1;}
   if(priorityLevelCount>=2){priorityLastKnownLevel=value;if(mapPriority.CurrentLevel!=value){mapPriority.CurrentLevel=value;Log("主角色等级连续两帧确认："+value+"级；下次选图按等级和优先级筛选");TraceEvent("player_level","level",value,"evidence",detail);}priorityLevelAt=DateTime.Now;}
  }else{priorityLevelCandidate=-1;priorityLevelCount=0;}
  if((DateTime.Now-priorityLevelAt).TotalSeconds>120)mapPriority.CurrentLevel=-1;
  priorityInfo.Text="下图优先："+(hellEnabled.Checked&&mapPriority.CurrentLevel>=80?"冥界·鬼门关 > ":"")+(mapPriority.CurrentLevel<0?mapPriority.NameList:mapPriority.EligibleNameList)+"；主角色等级："+(mapPriority.CurrentLevel<0?"待确认（按等级门槛筛选）":mapPriority.CurrentLevel+"级");
 }
 void ResetMapPriorityCycle(){mapPriority.Reset();prioritySelectedName="";priorityDialogAt=priorityEntryDeadline=priorityDialogFirst=DateTime.MinValue;priorityDetailCount=0;priorityDetailName="";closeStaleDialog=false;lastTargetPortalClick=DateTime.MinValue;lastTargetPortalName="";}
 bool FindPriorityPortal(Bitmap b,out Point point,out string reason){
  LoadMapPriority();point=Point.Empty;reason="";
  if(priorityEntryDeadline>DateTime.Now){reason="进入指令已提交，等待右上完整地图名验证";return false;}
  DateTime now=DateTime.Now;
  if(mapPriority.CurrentLevel<0&&priorityLastKnownLevel>=79){
   if(priorityUnknownLevelSince==DateTime.MinValue)priorityUnknownLevelSince=now;
   if((now-priorityUnknownLevelSince).TotalSeconds<60){reason="本连接此前确认79级以上；等级待重新确认，最多等待60秒；暂不改选低级图";return false;}
  }else priorityUnknownLevelSince=DateTime.MinValue;
  string searchUpdate=mapPriority.AdvanceSearch(now);if(searchUpdate.Length>0){Log(searchUpdate);TraceEvent("route_fallback","reason",searchUpdate,"next_index",mapPriority.SearchIndex,"search_started",mapPriority.SearchSince.ToString("o"));if(searchUpdate.StartsWith("下图兜底："))SaveDiagnostic(b,3,"route-fallback");}
  int required=mapPriority.SearchTarget(now);
  prioritySelectedName="";var info=new StringBuilder("角色等级="+mapPriority.CurrentLevel+"；");
  lastPortalZhanScore=lastPortalLongScore=0;
  for(int i=0;i<mapPriority.Maps.Length;i++){
   RouteMapDefinition map=mapPriority.Maps[i];priorityPortalScores[i]=0;priorityPortalPoints[i]=Point.Empty;
   if(required>=0&&i!=required){info.Append(map.Name).Append("等待当前优先图限时寻找；");continue;}
   if(!map.Enabled||map.MinLevel>0&&mapPriority.CurrentLevel<map.MinLevel){info.Append(map.Name).Append("等级未满足/未确认；");continue;}
   if(mapPriority.Failed[i]||DateTime.Now<mapPriority.CooldownUntil[i]||RouteMapCatalog.IsNewMap(map)&&mapPriority.EntryIssued[i]){info.Append(map.Name).Append("本轮跳过；");continue;}
   Point p;string evidence;double score;
   if(upgradeMapVision.FindPortal(b,map.Name,out p,out evidence,out score)){
    string blocked;bool confirmed=RouteTapGuard.ConfirmTargetPortal(b,3,p,score);
    if(!IsRouteTapProtected(p,out blocked,false,confirmed)){priorityPortalScores[i]=score;priorityPortalPoints[i]=p;}else evidence+="；"+blocked;
   }
   info.Append(evidence).Append("；");
   if(map.Id=="battle-outpost")lastPortalZhanScore=priorityPortalScores[i];if(map.Id=="dragon-claw")lastPortalLongScore=priorityPortalScores[i];
  }
  int selected=mapPriority.Choose(priorityPortalScores);if(selected<0){reason=(required>=0?"限时优先寻找"+mapPriority.Names[required]+"；剩余"+Math.Max(0,60-(int)(now-mapPriority.SearchSince).TotalSeconds)+"秒；超时换其他图；":"没有满足条件的可靠入口，等待冷却或BOSS备用入口；")+info;return false;}
  point=priorityPortalPoints[selected];prioritySelectedName=mapPriority.Names[selected];reason="优先目标="+prioritySelectedName+"；完整入口名分="+priorityPortalScores[selected].ToString("0.00")+"；主角色等级="+mapPriority.CurrentLevel+"；门中心="+point.X+","+point.Y;return true;
 }
 void RecordPriorityPortalClick(){mapPriority.PortalClicked(DateTime.Now);closeStaleDialog=false;priorityCloseAttempts=0;priorityCloseAt=DateTime.MinValue;priorityDialogFirst=DateTime.Now;priorityDialogAt=DateTime.MinValue;priorityDetailCount=0;priorityDetailName="";lastTargetPortalClick=DateTime.Now;lastTargetPortalName=prioritySelectedName;}
 void ObservePriorityMap(int map,Bitmap frame){
  if(priorityEntryDeadline!=DateTime.MinValue&&DateTime.Now>=priorityEntryDeadline){priorityEntryDeadline=DateTime.MinValue;
   if(map==3&&mapPriority.Active>=0){Log(mapPriority.Fail("进入后仍在神龙帝国，未再次提交进入"));closeStaleDialog=true;}
   else if(map<0){
    TraceEvent("map_arrival_unconfirmed","expected",prioritySelectedName,"title_evidence",priorityOcrReason);
    // Release the expired expectation, not its consuming entry budget. A wrong
    // but reliable actual title can then be recognized on the next frame.
    if(mapPriority.Active>=0){Log(mapPriority.Fail("进入等待超时，未确认预期地图；"+priorityOcrReason));closeStaleDialog=true;}
    else Log("进入等待超时，未读到可靠地图名；继续核对实际标题");
   }
  }
  if(map==4)priorityEntryDeadline=DateTime.MinValue;
  if(priorityEntryDeadline>DateTime.Now)return;
  // Scene/NPC fallbacks must never renew a potentially consuming entry budget.
  int observedMap=map;if(map>=0&&map<3&&CalibrationMap(frame)!=map)observedMap=-1;
  string update=mapPriority.Observe(observedMap,DateTime.Now);if(update.Length==0)return;lastTargetPortalClick=DateTime.MinValue;lastTargetPortalName="";engine.ResetPending();engine.ResetObservation();Log(update);
 }
 bool TryRecognizePriorityTarget(Bitmap b,out string reason){
  LoadMapPriority();reason="";bool awaitingNewMap=mapPriority.Active>=0&&RouteMapCatalog.IsNewMap(mapPriority.Maps[mapPriority.Active]);priorityTitleBlocksLegacy=awaitingNewMap;
  string text,detail;bool read=strictMapTitleReader.TryRead(b,out text,out detail);priorityOcrReason=detail;
  if(read){
   // Only an exact catalog title is authoritative OCR. Unknown OCR may be a
   // glyph error; it can only fall back to the complete bundled legacy titles.
   priorityTitleBlocksLegacy=true;int found=Array.IndexOf(mapPriority.Names,text);
   if(found>=0){
    if(awaitingNewMap&&found!=mapPriority.Active){priorityOcrCandidate="";priorityOcrCount=0;reason="实际完整地图名="+text+"，与等待中的目标"+mapPriority.Names[mapPriority.Active]+"不一致";return false;}
    if(priorityOcrFrame!=traceFrame){priorityOcrFrame=traceFrame;if(priorityOcrCandidate==text)priorityOcrCount++;else{priorityOcrCandidate=text;priorityOcrCount=1;}}
    if(priorityOcrCount<2){reason="右上地图名首次读到"+text+"，等待下一帧完整名称确认";return false;}
    lastMap4Score=0;reason="目标地图："+text+"；本地OCR完整等值匹配，两帧确认；"+detail;return true;
   }
  }
  priorityOcrCandidate="";priorityOcrCount=0;
  using(Bitmap title=b.Clone(new Rectangle(1067,31,149,34).IntersectSafe(b),b.PixelFormat)){Mask frame=new Mask(title,false);Point p;
   // The two 叛军 names share most glyphs. A camp-like title waits for OCR
   // even when no entry is active (e.g. starting while already in 基地).
   bool campLike=false;
   for(int i=0;i<priorityTitles.Length;i++)if(priorityTitles[i]!=null&&mapPriority.Maps[i].Id=="panjun-camp"&&priorityTitles[i].Find(frame,new Rectangle(0,0,title.Width,title.Height),out p)>=.65)campLike=true;
   if(campLike)priorityTitleBlocksLegacy=true;
   if(!awaitingNewMap&&!campLike)for(int i=0;i<priorityTitles.Length;i++){
    string id=mapPriority.Maps[i].Id;if(priorityTitles[i]==null||(id!="battle-outpost"&&id!="dragon-claw"))continue;
    double score=priorityTitles[i].Find(frame,new Rectangle(0,0,title.Width,title.Height),out p);
    if(score<.76)continue;
    // Do not let the generic legacy fallback accept a matching prefix if this
    // complete-title check fails. Unknown OCR requires stronger overall evidence.
    priorityTitleBlocksLegacy=true;
    if(score<(read?.90:.76)||!HasCompletePriorityTitle(priorityTitles[i],frame,p))continue;
    lastMap4Score=score;reason="目标地图："+mapPriority.Names[i]+"，右上完整四字模板分="+score.ToString("0.00")+(read?"；OCR未命中目录，以完整模板确认；"+detail:"");return true;
   }
  }
  return false;
 }
 // The two bundled legacy titles contain four equally spaced glyphs. Requiring
 // each glyph prevents three matching characters from hiding a missing suffix.
 static bool HasCompletePriorityTitle(Mask template,Mask frame,Point center){
  if(template.Pos.Count<15)return false;
  int left=template.W,right=-1,top=template.H,bottom=-1;
  foreach(Point p in template.Pos){left=Math.Min(left,p.X);right=Math.Max(right,p.X);top=Math.Min(top,p.Y);bottom=Math.Max(bottom,p.Y);}
  int offsetX=center.X-template.W/2,offsetY=center.Y-template.H/2;
  if(offsetX<0||offsetY<0||offsetX+template.W>frame.W||offsetY+template.H>frame.H)return false;
  for(int glyph=0;glyph<4;glyph++){
   int from=left+(right-left+1)*glyph/4,to=left+(right-left+1)*(glyph+1)/4,expected=0,observed=0,hit=0;
   for(int y=top;y<=bottom;y++)for(int x=from;x<to;x++){
    bool a=template.Bits[y*template.W+x],v=frame.Bits[(offsetY+y)*frame.W+offsetX+x];if(a)expected++;if(v)observed++;if(a&&v)hit++;
   }
   if(expected<5||hit<expected*.80||2.0*hit/(expected+observed)<.80)return false;
  }
  return true;
 }
 bool CanEnterPriorityMapDialog(Bitmap b,out string reason){LoadMapPriority();return PriorityEntryGate.Allows(mapPriority,upgradeMapVision.ReadDialog(b),out reason);}
 bool ClickPriorityMapDialog(Bitmap b){
  LoadMapPriority();UpgradeMapReading reading=upgradeMapVision.ReadDialog(b);DateTime now=DateTime.Now;
  if(!reading.Present){
   priorityDetailName="";priorityDetailCount=0;Point shellClose;bool shell=upgradeMapVision.FindDialogClose(b,out shellClose);
   if(!IsEntryDetailVisible(b)&&!shell){if(closeStaleDialog){closeStaleDialog=false;engine.ResetObservation();engine.ResetPending();}return false;}
   if(mapPriority.Active>=0&&priorityDialogFirst!=DateTime.MinValue&&(now-priorityDialogFirst).TotalSeconds>12){SaveDiagnostic(b,3,"priority-title-unreadable");Log(mapPriority.Fail("12秒未确认完整详情名称"));closeStaleDialog=true;}
   if(closeStaleDialog&&shell){TryClosePriorityDetail(shellClose);return true;}
   engine.Status="地图详情名称尚未确认，暂停点击";return true;
  }
  if(mapPriority.Active<0){if(closeStaleDialog&&reading.Close.HasValue){TryClosePriorityDetail(reading.Close.Value);return true;}engine.Status="地图详情由当前路线确认后处理";return true;}
  int active=mapPriority.Active;
  if(priorityEntryDeadline>now){engine.Status="已发出进入指令，等待实际地图名；不重复提交";return true;}
  if(priorityEntryDeadline!=DateTime.MinValue){priorityEntryDeadline=DateTime.MinValue;return FailPriorityDialog(b,reading,"进入等待超时，详情仍在；不重复提交");}
  string reason;bool allowed=PriorityEntryGate.Allows(mapPriority,reading,out reason);
  if(!allowed){priorityDetailName="";priorityDetailCount=0;bool definite=reading.Name!=mapPriority.Names[active]||reading.Requirements=="red"||(RouteMapCatalog.IsNewMap(mapPriority.Maps[active])&&mapPriority.EntryIssued[active]);if(definite||(now-priorityDialogFirst).TotalSeconds>=12)return FailPriorityDialog(b,reading,reason);engine.Status="等待详情进入条件确认："+reason;return true;}
  if(priorityDetailFrame!=traceFrame){priorityDetailFrame=traceFrame;if(priorityDetailName==reading.Name)priorityDetailCount++;else{priorityDetailName=reading.Name;priorityDetailCount=1;}}
  if(priorityDetailCount<2){engine.Status="已确认详情和绿色条件，等待第二帧再进入";return true;}
  // Reserve before dispatch: a timeout may happen after the game accepted input.
  mapPriority.EnterClicked(now);priorityDialogAt=now;priorityEntryDeadline=now.AddSeconds(20);
  TraceBeforeAction(b,"进入"+reading.Name+"；"+reason);TraceEvent("map_enter_attempt","target",reading.Name,"level",mapPriority.CurrentLevel,"condition",reading.Requirements);
  if(!Click(reading.Enter.Value)){Log("进入指令未确认发出；保留本轮进入预算，等待新截图");return true;}
  engine.ResetPending();engine.ResetObservation();Log("已核对"+reading.Name+"详情与条件，提交一次进入；等待右上实际地图名验证");return true;
 }
 bool FailPriorityDialog(Bitmap b,UpgradeMapReading reading,string reason){SaveDiagnostic(b,3,"priority-entry-blocked");bool unavailable=mapPriority.Active>=0&&reading.Name==mapPriority.Names[mapPriority.Active]&&reading.Requirements=="red";Log(mapPriority.Fail(reason,DateTime.Now,unavailable));priorityDetailCount=0;closeStaleDialog=true;if(reading.Close.HasValue){TraceBeforeAction(b,"关闭未通过的地图详情："+reason);TryClosePriorityDetail(reading.Close.Value);}engine.ResetPending();engine.ResetObservation();return true;}
 void TryClosePriorityDetail(Point close){
  DateTime now=DateTime.Now;if(now<priorityCloseAt){engine.Status="等待地图详情关闭验证";return;}
  if(priorityCloseAttempts>=3){priorityCloseAt=now.AddSeconds(30);priorityCloseAttempts=0;engine.Status="地图详情关闭3次未生效，冷却30秒后重新核对；守护继续";Log(engine.Status);return;}
  priorityCloseAttempts++;priorityCloseAt=now.AddSeconds(2);Click(close);engine.Status="关闭未通过的地图详情（"+priorityCloseAttempts+"/3），等待新截图验证";Log(engine.Status);
 }
 bool FindPriorityDialogClose(Bitmap b,out Point close){LoadMapPriority();UpgradeMapReading r=upgradeMapVision.ReadDialog(b);close=r.Close.GetValueOrDefault();return r.Present&&r.Close.HasValue;}
}
