using System;
using System.Globalization;
using System.IO;
using System.Text;

// One captured local timestamp and one formatted line serve the UI and both files.
sealed class DatedLogWriter
{
    internal const string Release = "V4.20.10 游荡鬼王调度版";
    string lastMessage;
    DateTime lastDate = DateTime.MinValue;

    internal static string Format(DateTime now, string message)
    {
        return now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture) + "  " + message;
    }

    internal bool Write(string directory, string message, DateTime now, Action<string> visible, string context = "")
    {
        if (message == lastMessage && now.Date == lastDate) return false;
        lastMessage = message;
        lastDate = now.Date;
        string line = Format(now, message + (context.Length > 0 ? " " + context.TrimEnd() : ""));
        visible(line);
        try
        {
            Append(directory, "guardian", 2000000, now, line);
            if (message.Contains("回收") || message.Contains("背包") || message.Contains("一键"))
                Append(directory, "recycle", 1000000, now, line);
        }
        catch { /* Preserve the existing behavior: disk errors must not stop guarding. */ }
        return true;
    }

    static void Append(string directory, string name, long limit, DateTime now, string line)
    {
        string path = Path.Combine(directory, name + ".log");
        if (File.Exists(path) && new FileInfo(path).Length > limit)
        {
            string stem = Path.Combine(directory, name + "-" + now.ToString("yyyyMMddHHmmss", CultureInfo.InvariantCulture));
            string archive = stem + ".log";
            int suffix = 1;
            while (File.Exists(archive)) archive = stem + "-" + (suffix++) + ".log";
            File.Move(path, archive);
        }
        File.AppendAllText(path, line + Environment.NewLine, Encoding.UTF8);
    }
}






