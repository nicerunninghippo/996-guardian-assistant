using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

partial class Guardian {
 static void FocusAssert(bool ok,string message){if(!ok)throw new Exception("重点测试失败："+message);}
 public void FocusSmoke(){
  // Focused checks only: real problem images, movement feedback, log copy.
  timer.Stop();Show();Application.DoEvents();
  var report=new StringBuilder();
  string fixtures=Path.Combine(root,"tests","coordinates-v44");
  foreach(string line in File.ReadAllLines(Path.Combine(fixtures,"expected.txt"),Encoding.UTF8)){
   if(string.IsNullOrWhiteSpace(line)||line.StartsWith("#"))continue;
   string[] parts=line.Split(',');int expectedX=int.Parse(parts[1]),expectedY=int.Parse(parts[2]),split=int.Parse(parts[3]);
   using(Bitmap b=new Bitmap(Path.Combine(fixtures,parts[0]))){
    int x,y;string detail;
    bool ok=TryReadCoordDigits(b,split,out x,out y,out detail);
    FocusAssert(ok&&x==expectedX&&y==expectedY,parts[0]+" 期望"+expectedX+":"+expectedY+"，实际"+x+":"+y+"；"+detail);
    report.AppendLine("截图读数通过："+parts[0]+" = "+x+":"+y);
   }
  }
  using(Bitmap blank=new Bitmap(1216,684)){
   int x,y;string detail;FocusAssert(!TryReadCoordDigits(blank,3,out x,out y,out detail),"空画面必须报告未识别");
  }
  // Replay the observed move with the newly read coordinates, not the erroneous old values.
  var flow=new DirectionCalibration();flow.Begin(0,new Point(219,470));int sends=0;
  Func<Point,Point,int,bool> send=(a,b,ms)=>{sends++;return true;};
  Action<string> discard=s=>{};
  flow.Step(new Point(330,333),0,0,send,discard);flow.Step(new Point(330,333),0,1,send,discard);
  flow.Step(new Point(330,331),0,3,send,discard);flow.Step(new Point(330,331),0,4,send,discard);
  FocusAssert(sends==1&&flow.Active&&flow.Index==1&&flow.Dx[0]==0&&flow.Dy[0]==-2,"两格真实移动不得触发202格跳变中止");
  flow.Cancel("停止");flow.Step(new Point(330,331),0,6,send,discard);FocusAssert(sends==1,"停止后不继续发动作");
  report.AppendLine("移动反馈通过：330:333 → 330:331，Y-2，校准继续；停止后无新增动作。");

  string original=logs.Text;string copied=null;Action<string> originalWriter=logClipboardWriter;
  try{
   logClipboardWriter=s=>copied=s;
   logs.Text="第一行\r\n给我这段\r\n第三行\r\n";logs.Select(logs.Text.IndexOf("给我这段"),4);
   AppendVisibleLog("新日志来了");FocusAssert(logs.SelectedText=="给我这段","日志刷新时应保留选区");
   coordCalibration.Begin(0,new Point(219,470));
   ((Button)Controls.Find("LogCopySelected",true)[0]).PerformClick();FocusAssert(copied=="给我这段","校准期间复制选中按钮");
   ((Button)Controls.Find("LogCopyAll",true)[0]).PerformClick();FocusAssert(copied==logs.Text,"复制全部按钮应复制界面全部文字");
   MethodInfo key=typeof(Control).GetMethod("OnKeyDown",BindingFlags.NonPublic|BindingFlags.Instance);
   key.Invoke(logs,new object[]{new KeyEventArgs(Keys.Control|Keys.A)});
   key.Invoke(logs,new object[]{new KeyEventArgs(Keys.Control|Keys.C)});
   FocusAssert(copied==logs.Text&&logs.SelectionLength==logs.TextLength,"Ctrl+A/C完整复制");
   report.AppendLine("日志复制通过：选区保持、复制选中、复制全部、Ctrl+A/C，校准期间可复制；使用注入接收器验证，未改变用户剪贴板。");
  }finally{coordCalibration.Cancel("测试完成");logClipboardWriter=originalWriter;logs.Text=original;}
  File.WriteAllText(Path.Combine(root,"重点测试.txt"),report.ToString(),Encoding.UTF8);
  using(Bitmap shot=new Bitmap(Width,Height)){DrawToBitmap(shot,new Rectangle(0,0,Width,Height));shot.Save(Path.Combine(root,"界面测试.png"));}
  Close();
 }
}
