using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;

// A reading authorizes only a close control. No reward, activation or entry
// button is ever returned. Caller must supply a current farming context for
// generic windows; known 日享福利 can be recognized after a restart as well.
public sealed class FarmPopupReading {
 public bool Panel,CanClose,Known,MapDetail;
 public string Name="",Detail="";
 public Point ClosePoint;
 public double Score;
}

public sealed class FarmPopupDetector {
 sealed class Pixels {
  public readonly int W,H; public readonly int[] Data;
  public Pixels(Bitmap image){
   W=image.Width;H=image.Height;Data=FrameCache.Pixels(image);
  }
  public int At(int x,int y){return x<0||y<0||x>=W||y>=H?0:Data[y*W+x];}
 }
 static bool Gold(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return r>135&&g>95&&b<165&&r>g*1.05&&g>b*1.20;}
 static bool Red(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return r>70&&r>g*1.65&&r>b*1.5;}
 static bool Metal(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return r>48&&r<215&&Math.Abs(r-g)<24&&Math.Abs(g-b)<24;}
 sealed class Patch {
  readonly Pixels pixels;readonly bool close;
  public int W{get{return pixels.W;}} public int H{get{return pixels.H;}}
  public Patch(string file,bool closeControl){using(Bitmap b=new Bitmap(file))pixels=new Pixels(b);close=closeControl;}
  public double Score(Pixels frame,int left,int top){
   if(left<0||top<0||left+W>frame.W||top+H>frame.H)return 0;
   int eg=0,ag=0,hg=0,er=0,ar=0,hr=0,n=0;long error=0;
   int step=close?1:2;
   for(int y=0;y<H;y+=step)for(int x=0;x<W;x+=step){
    int a=pixels.At(x,y),b=frame.At(left+x,top+y);bool ga=Gold(a),gb=Gold(b);
    if(ga)eg++;if(gb)ag++;if(ga&&gb)hg++;
    if(close){bool ra=Red(a),rb=Red(b);if(ra)er++;if(rb)ar++;if(ra&&rb)hr++;}
    error+=Math.Abs(((a>>16)&255)-((b>>16)&255))+Math.Abs(((a>>8)&255)-((b>>8)&255))+Math.Abs((a&255)-(b&255));n++;
   }
   if(eg<8)return 0;
   double score=Math.Min(1-error/(765.0*n),2.0*hg/(eg+ag));
   if(close)score=Math.Min(score,er<30?0:2.0*hr/(er+ar));
   return score;
  }
  public double Find(Pixels image,Rectangle area,out Point found){
   found=Point.Empty;double best=0;area=Rectangle.Intersect(area,new Rectangle(0,0,image.W,image.H));
   for(int y=area.Top;y<=area.Bottom-H;y+=2)for(int x=area.Left;x<=area.Right-W;x+=2){
    double s=Score(image,x,y);if(s>best){best=s;found=new Point(x,y);}
   }
   Point coarse=found;
   for(int y=coarse.Y-2;y<=coarse.Y+2;y++)for(int x=coarse.X-2;x<=coarse.X+2;x++){
    double s=Score(image,x,y);if(s>best){best=s;found=new Point(x,y);}
   }
   return best;
  }
 }
 readonly Patch dailyTitle,dailyClose,mapDialogTitle,jiaorenTitle;
 readonly List<Patch> closes=new List<Patch>();
 public FarmPopupDetector(string templates){
  jiaorenTitle=Load(templates,"jiaoren-title-native.png",false);dailyTitle=Load(templates,"farm-v412-daily-title.png",false);
  dailyClose=Load(templates,"farm-v412-daily-close.png",true);
  mapDialogTitle=Load(templates,"farm-v412-map-dialog-title.png",false);
  if(dailyClose!=null)closes.Add(dailyClose);
  Patch p=Load(templates,"welfare-close-v49.png",true);if(p!=null)closes.Add(p);
  p=Load(templates,"box-cross-v47.png",true);if(p!=null)closes.Add(p);
 }
 static Patch Load(string dir,string file,bool close){try{return new Patch(Path.Combine(dir,file),close);}catch(IOException){return null;}catch(ArgumentException){return null;}}

 // A complete X-in-red must adjoin both a wide horizontal metallic window
 // header and a long vertical frame. This rejects isolated HUD badges and
 // floating combat glyphs. Color/darkness of the panel contents is irrelevant.
 static double FrameEvidence(Pixels f,Point center){
  double horizontal=0,vertical=0;
  for(int y=center.Y-26;y<=center.Y+3;y++){
   int hit=0,count=0;for(int x=center.X-225;x<center.X-42;x+=3){if(Metal(f.At(x,y)))hit++;count++;}
   horizontal=Math.Max(horizontal,(double)hit/count);
  }
  for(int x=center.X-38;x<=center.X-10;x++){
   int hit=0,count=0;for(int y=center.Y+32;y<center.Y+212;y+=3){if(Metal(f.At(x,y)))hit++;count++;}
   vertical=Math.Max(vertical,(double)hit/count);
  }
  return Math.Min(horizontal,vertical);
 }

 public FarmPopupReading Read(Bitmap image,bool allowGeneric){return FrameCache.Get<FarmPopupReading>(image,this,allowGeneric?"farm-generic":"farm-known",delegate{return ReadFresh(image,allowGeneric);});}
 public FarmPopupReading ReadRoute(Bitmap image){return FrameCache.Get<FarmPopupReading>(image,this,"route-popup",delegate{return ReadFresh(image,true,true);});}
 FarmPopupReading ReadFresh(Bitmap image,bool allowGeneric,bool routeOnly=false){
  FarmPopupReading r=new FarmPopupReading();
  if(image==null||image.Width!=1216||image.Height!=684)return r;
  Pixels f=new Pixels(image);Point title;
  if(jiaorenTitle!=null&&jiaorenTitle.Find(f,new Rectangle(470,65,325,55),out title)>=.88){
   r.Panel=true;r.Known=true;r.Name="佳人有约";r.Detail="佳人完整原生标题已确认";
   foreach(Patch cross in closes){Point located;double score=cross.Find(f,new Rectangle(970,45,110,100),out located);Point center=new Point(located.X+cross.W/2,located.Y+cross.H/2);
    if(score>=.86&&FrameEvidence(f,center)>=.72&&score>r.Score){r.CanClose=true;r.ClosePoint=center;r.Score=score;r.Detail+="；完整关闭叉及横竖窗框="+score.ToString("0.00");}
   }return r;
  }
  if(dailyTitle!=null&&dailyClose!=null){
   double ts=dailyTitle.Find(f,new Rectangle(470,15,330,110),out title);
   r.Detail="日享福利标题候选="+ts.ToString("0.00")+" @"+title;
   if(ts>=.84){
    r.Panel=true;r.Known=true;r.Name="日享福利";r.Score=ts;
    int dx=title.X-580,dy=title.Y-39;Point cross;
    double cs=dailyClose.Find(f,new Rectangle(1003+dx,40+dy,40,55),out cross);
    r.CanClose=cs>=.86;r.Detail="日享福利标题="+ts.ToString("0.00")+"；完整红叉="+cs.ToString("0.00");
    if(r.CanClose)r.ClosePoint=new Point(cross.X+dailyClose.W/2,cross.Y+dailyClose.H/2);
    return r;
   }
  }
  if(!allowGeneric)return r;
  // Entry dialogs are owned by the map-route state machine even if the
  // previous frame happened to be a farming map.
  if(mapDialogTitle!=null&&mapDialogTitle.Find(f,new Rectangle(430,35,340,120),out title)>=.82){
   r.MapDetail=true;r.Detail="地图传送详情交给下图流程处理";return r;
  }
  foreach(Patch cross in closes){
   // Seed by a gold glyph surrounded on both sides by red. Full template
   // and frame checks below are mandatory; this color seed never authorizes input.
   for(int cy=38;cy<(routeOnly?180:365);cy+=2)for(int cx=routeOnly?970:450;cx<(routeOnly?1080:1165);cx+=2){
    if(!Gold(f.At(cx,cy)))continue;
    if(!Red(f.At(cx-6,cy))||!Red(f.At(cx+6,cy)))continue;
    int left=cx-cross.W/2,top=cy-cross.H/2;
    double best=0;Point pos=Point.Empty;
    for(int yy=-2;yy<=2;yy++)for(int xx=-2;xx<=2;xx++){
     double score=cross.Score(f,left+xx,top+yy);if(score>best){best=score;pos=new Point(left+xx+cross.W/2,top+yy+cross.H/2);}
    }
    if(best<.86||best<=r.Score)continue;
    double frame=FrameEvidence(f,pos);if(frame<.72)continue;
    r.Panel=true;r.CanClose=true;r.Name="刷怪中遮挡窗口";r.ClosePoint=pos;r.Score=best;
    r.Detail="完整红底金叉="+best.ToString("0.00")+"；横竖窗框="+frame.ToString("0.00");
   }
  }
  return r;
 }
}
