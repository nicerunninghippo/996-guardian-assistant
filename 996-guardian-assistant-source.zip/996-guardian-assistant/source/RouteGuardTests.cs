using System;
using System.Drawing;
using System.IO;
using System.Text;

partial class Guardian {
 public void RouteGuardSmoke(){
  timer.Stop();var report=new StringBuilder();string why;
  using(Bitmap frame=new Bitmap(Path.Combine(root,"tests","jiaolong-blocked-v46.png"))){
   int map=Recognize(frame);Point p;
   double score=npc.Find(new Mask(frame,true),new Rectangle(50,100,925,445),out p);
   report.AppendLine("用户截图：地图="+map+" NPC分="+score.ToString("0.00")+" 点="+p.X+","+p.Y);
   FocusAssert(map==2&&Math.Abs(p.X-402)<8&&Math.Abs(p.Y-350)<8,"截图应识别蛟龙左侧大陆传送");
   FocusAssert(IsRouteTapProtected(p,out why),"复现旧版在此位置拦截");
   bool verified=RouteTapGuard.ConfirmJiaolongNpc(frame,map,p,score);
   FocusAssert(verified&&!IsRouteTapProtected(p,out why,verified),"蛟龙可见NPC应允许中心点击");
   FocusAssert(!RouteTapGuard.ConfirmJiaolongNpc(frame,map,p,.70),"低分不得豁免");
   FocusAssert(!RouteTapGuard.ConfirmJiaolongNpc(frame,0,p,score),"盟重不走蛟龙例外");
   FocusAssert(!RouteTapGuard.ConfirmJiaolongNpc(frame,3,p,score),"神龙不走蛟龙例外");
   report.AppendLine("通过：复现旧保护区误拦，新规则允许该NPC；低分或其他地图不放行。");
   Engine flow=new Engine();flow.Start();
   FocusAssert(!flow.Step(2,verified,0)&&!flow.Step(2,verified,1)&&flow.Step(2,verified,2),"连续三帧后才允许传送");
   FocusAssert(!flow.Step(2,verified,3),"点击后等待切图，不连续点击");
   flow.Stop("F8");FocusAssert(!flow.Step(2,verified,30),"停止后不发起传送");
   report.AppendLine("通过：连续三帧确认、点击后等待地图切换、F8停止。");
  }
  using(Bitmap chat=new Bitmap(Path.Combine(root,"tests","chat-open-v46.png"))){
   FocusAssert(!RouteTapGuard.ConfirmJiaolongNpc(chat,2,new Point(402,350),.99),"展开聊天面板遮挡时不能豁免");
  }
  foreach(Point p in new[]{new Point(150,500),new Point(220,460),new Point(100,580),new Point(350,500),new Point(650,590)})
   FocusAssert(IsRouteTapProtected(p,out why,true),"聊天/跑走区不能豁免："+p);
  report.AppendLine("通过：展开聊天面板、跑/走按钮、左下聊天区及底部聊天文字区仍受保护。");
  report.AppendLine("只做截图与逻辑回放，未执行实机游戏动作。");
  File.WriteAllText(Path.Combine(root,"V4.6重点检查.txt"),report.ToString(),Encoding.UTF8);Close();
 }
}
