﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Windows.Forms;

partial class Guardian {
 DiagnosticJournal traceJournal;
 readonly Queue<string> traceRecent=new Queue<string>(),traceEvidence=new Queue<string>();
 readonly Dictionary<string,TraceTiming> traceTimings=new Dictionary<string,TraceTiming>();
 readonly Stopwatch traceClock=Stopwatch.StartNew();
 Process traceProcess;
 long traceFrame,traceAction,traceTaskSequence,traceLastMapFrame;
 string traceTask="",traceStage="idle",traceIntent="",traceGateLast="",traceLastError="",traceReportedError="",tracePerfText="尚未形成一分钟性能样本";
 int traceMap=-9,traceWidth,traceHeight,traceTicks,traceCaptures,traceInputs,traceFailures;
 double tracePerfAt,traceCpuAt,traceGateAt,traceMapAt,traceStatusAt,traceTaskStarted;
 bool traceWriting,traceClosed,traceExporting;
 sealed class TraceTiming {public double Total,Max;public int Count;}
 sealed class TraceSpan:IDisposable {
  readonly Guardian owner;readonly Stopwatch clock=Stopwatch.StartNew();
  public TraceSpan(Guardian value){owner=value;owner.traceStage="dispatch";owner.traceIntent="";owner.traceTicks++;}
  public void Dispose(){owner.TraceDuration("tick",clock.Elapsed.TotalMilliseconds);owner.TraceHeartbeat();owner.TracePerformance(false);}
 }
 void InitDiagnostics(Panel bottom){
  try{traceJournal=new DiagnosticJournal(data,DatedLogWriter.Release);traceProcess=Process.GetCurrentProcess();traceCpuAt=traceProcess.TotalProcessorTime.TotalMilliseconds;}
  catch(Exception ex){traceLastError="诊断日志初始化失败："+ex.Message;}
  bottom.Height=289;logs.Top=133;logs.Height=146;
  var bar=new FlowLayoutPanel{Left=12,Top=96,Height=32,Width=865,WrapContents=false,Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right};
  var copy=new Button{Text="复制诊断摘要",AutoSize=true,Height=29};copy.Click+=(s,e)=>{try{logClipboardWriter(DiagnosticSummary());logCopyHint.Text="诊断摘要已复制";}catch(Exception ex){logCopyHint.Text="复制失败："+ex.Message;}};
  var open=new Button{Text="打开本次日志",AutoSize=true,Height=29};open.Click+=(s,e)=>{try{if(traceJournal!=null&&Directory.Exists(traceJournal.DirectoryPath))Process.Start(new ProcessStartInfo(traceJournal.DirectoryPath){UseShellExecute=true});else logCopyHint.Text="本次诊断目录尚未创建";}catch(Exception ex){logCopyHint.Text="打开失败："+ex.Message;}};
  var export=new Button{Text="导出诊断包",AutoSize=true,Height=29};export.Click+=(s,e)=>ExportDiagnosticBundle();
  bar.Controls.AddRange(new Control[]{copy,open,export});bottom.Controls.Add(bar);
  TraceEvent("session_start","directory",root,"data_directory",data,"process_id",Process.GetCurrentProcess().Id,"logical_processors",Environment.ProcessorCount,"normalized_size","1216x684","time_zone",TimeZoneInfo.Local.Id);
 }
 string TraceContextText(){return "[会话="+(traceJournal==null?"未建":traceJournal.SessionId)+" 实例="+(backend.Serial??"未连接")+" 帧="+traceFrame+(traceTask.Length>0?" 任务="+traceTask:"")+"] ";}
 void TraceEvent(string kind,params object[] values){
  if(traceWriting||traceClosed||traceJournal==null)return;
  traceWriting=true;
  try{
   var fields=new Dictionary<string,object>();fields["serial"]=backend.Serial;fields["frame"]=traceFrame;fields["task_run"]=traceTask;fields["stage"]=traceStage;
   fields["last_observed_map"]=traceMap;fields["map_observed_frame"]=traceLastMapFrame;
   for(int i=0;i+1<values.Length;i+=2)fields[Convert.ToString(values[i])]=values[i+1];
   if(kind=="evidence")foreach(string key in new[]{"image","note","title"})if(fields.ContainsKey(key)&&fields[key]!=null){string p=Convert.ToString(fields[key]);if(!traceEvidence.Contains(p)){traceEvidence.Enqueue(p);while(traceEvidence.Count>40)traceEvidence.Dequeue();}}
   if(!traceJournal.Write(kind,fields)){
    traceLastError=traceJournal.LastError;
    if(traceReportedError!=traceLastError){traceReportedError=traceLastError;AppendVisibleLog(DatedLogWriter.Format(DateTime.Now,"诊断记录异常，守护继续："+traceLastError));}
   }
  }catch(Exception ex){traceLastError="诊断写入失败："+ex.Message;}
  finally{traceWriting=false;}
 }
 void TraceLog(string value){
  traceRecent.Enqueue(DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss.fff zzz")+" "+value+" "+TraceContextText());while(traceRecent.Count>80)traceRecent.Dequeue();
  TraceEvent("message","text",value,"engine_status",engine.Status);
 }
 void TraceGate(string reason){
  double now=traceClock.Elapsed.TotalSeconds;
  if(reason==traceGateLast&&now-traceGateAt<30)return;
  traceGateLast=reason;traceGateAt=now;TraceEvent("maintenance_wait","reason",reason,"next_cycle_seconds",Math.Max(0,maintenanceSchedule.NextCycle-ClockSeconds()),"next_mail_seconds",Math.Max(0,maintenanceSchedule.NextMail-ClockSeconds()));
 }
 void TraceTaskBegin(string id,string name){
  traceTaskStarted=traceClock.Elapsed.TotalSeconds;traceTask=id+"-"+(++traceTaskSequence).ToString("D4");TraceEvent("task_start","task",id,"name",name,"deadline_seconds",210);
 }
 void TraceTaskEnd(bool success,string reason){
  if(traceTask.Length==0)return;TraceEvent("task_end","success",success,"reason",reason,"elapsed_seconds",Math.Max(0,traceClock.Elapsed.TotalSeconds-traceTaskStarted));traceTask="";
 }
 void TraceBeforeAction(Bitmap frame,string reason){traceIntent=reason;}
 void TraceObservedMap(int map,string reason){
  double now=traceClock.Elapsed.TotalSeconds;bool report=map!=traceMap||now-traceMapAt>=30;
  traceMap=map;traceLastMapFrame=traceFrame;
  if(report){traceMapAt=now;TraceEvent("map_observation","map",map,"evidence",reason,"stable_map",engine.Stable,"stable_frames",engine.Count,"pending_map",engine.Pending);}
 }
 void TraceDuration(string name,double ms){TraceTiming t;if(!traceTimings.TryGetValue(name,out t)){t=new TraceTiming();traceTimings.Add(name,t);}t.Count++;t.Total+=ms;t.Max=Math.Max(t.Max,ms);}
 bool TraceStage(string name,Func<bool> action){string previous=traceStage;traceStage=name;var watch=Stopwatch.StartNew();try{return action();}finally{TraceDuration(name,watch.Elapsed.TotalMilliseconds);traceStage=previous;}}
 int TraceRecognize(Bitmap b){string previous=traceStage;traceStage="map_recognition";var watch=Stopwatch.StartNew();try{int map=Recognize(b);TraceObservedMap(map,lastRecognizeReason);return map;}finally{TraceDuration("map_recognition",watch.Elapsed.TotalMilliseconds);traceStage=previous;}}
 Bitmap TraceCapture(){
  traceFrame++;traceIntent="";var watch=Stopwatch.StartNew();
  try{Bitmap b=backend.Capture();traceCaptures++;
   if(backend.Width!=traceWidth||backend.Height!=traceHeight){TraceEvent("capture_geometry","previous_width",traceWidth,"previous_height",traceHeight,"width",backend.Width,"height",backend.Height,"normalized_width",1216,"normalized_height",684);traceWidth=backend.Width;traceHeight=backend.Height;}
   return b;
  }catch(Exception ex){traceFailures++;TraceEvent("capture_error","error",ex.ToString());throw;}
  finally{TraceDuration("capture",watch.Elapsed.TotalMilliseconds);}
 }
 bool TraceInput(string kind,Point from,Point to,int ms,bool allowed,Func<bool> send){
  long id=++traceAction;string intent=traceIntent.Length>0?traceIntent:engine.Status;traceIntent="";
  int width=backend.Width,height=backend.Height;
  TraceEvent("input_attempt","action_id",id,"input",kind,"intent",intent,"allowed",allowed,"x",from.X,"y",from.Y,"to_x",to.X,"to_y",to.Y,"duration_ms",ms,"native_x",(int)Math.Round(from.X*width/1216.0),"native_y",(int)Math.Round(from.Y*height/684.0),"native_to_x",(int)Math.Round(to.X*width/1216.0),"native_to_y",(int)Math.Round(to.Y*height/684.0),"native_width",width,"native_height",height);
  if(!allowed){TraceEvent("input_result","action_id",id,"submitted",false,"reason","守护未运行或F8停止条件，未调用输入接口");return false;}
  var watch=Stopwatch.StartNew();
  try{bool ok=send();if(ok)traceInputs++;TraceEvent("input_result","action_id",id,"submitted",ok,"elapsed_ms",watch.Elapsed.TotalMilliseconds,"verification","仅为输入接口结果，游戏结果待新截图确认");Log("操作#"+id+" "+kind+"："+from.X+","+from.Y+(kind=="tap"?"":" → "+to.X+","+to.Y+" "+ms+"ms")+"；"+(ok?"输入已发出，等待画面验证":"接口未确认发出")+"；"+intent);return ok;}
  catch(Exception ex){traceFailures++;TraceEvent("input_result","action_id",id,"submitted",false,"outcome_unknown",true,"elapsed_ms",watch.Elapsed.TotalMilliseconds,"error",ex.ToString());throw;}
  finally{TraceDuration("input",watch.Elapsed.TotalMilliseconds);}
 }
 void TraceHeartbeat(){
  double now=traceClock.Elapsed.TotalSeconds;
  if(now-traceStatusAt<30)return;traceStatusAt=now;
  TraceEvent("heartbeat","running",engine.Running,"guard_requested",guardRequested,"status",engine.Status,"minimap_recovery",minimapRecovery.Active,"popup_recovery",farmPopupFlow.Active,"recycle_stage",recycle.Stage,"maintenance",maintenanceSchedule.Active,"pending_map",engine.Pending,"frames_captured",traceCaptures,"last_log_error",traceLastError);
 }
 void TracePerformance(bool force){
  double now=traceClock.Elapsed.TotalSeconds,elapsed=now-tracePerfAt;if(elapsed<60&&!force)return;if(elapsed<=0||traceProcess==null)return;
  try{
   traceProcess.Refresh();double cpu=traceProcess.TotalProcessorTime.TotalMilliseconds;double percent=Math.Max(0,(cpu-traceCpuAt)/(elapsed*1000*Environment.ProcessorCount)*100);
   var stages=new Dictionary<string,object>();foreach(var entry in traceTimings){TraceTiming t=entry.Value;stages[entry.Key]=new Dictionary<string,object>{{"calls",t.Count},{"mean_ms",t.Total/t.Count},{"max_ms",t.Max},{"total_ms",t.Total}};}
   tracePerfText="最近"+elapsed.ToString("0")+"秒：助手进程CPU均值="+percent.ToString("0.00")+"%（按"+Environment.ProcessorCount+"个逻辑处理器折算），截图="+traceCaptures+"，输入已发出="+traceInputs+"，异常="+traceFailures;
   TraceTiming capture;if(traceTimings.TryGetValue("capture",out capture))tracePerfText+="；截图均值="+(capture.Total/capture.Count).ToString("0")+"ms";
   string heavy="";double heavyTotal=0;foreach(var entry in traceTimings)if(entry.Key!="capture"&&entry.Key!="input"&&entry.Key!="tick"&&entry.Value.Total>heavyTotal){heavy=entry.Key;heavyTotal=entry.Value.Total;}
   if(heavy.Length>0)tracePerfText+="；累计最耗时阶段="+heavy+"（均值"+(traceTimings[heavy].Total/traceTimings[heavy].Count).ToString("0")+"ms）";
   TraceEvent("performance","window_seconds",elapsed,"process_cpu_percent",percent,"logical_processors",Environment.ProcessorCount,"working_set_mb",traceProcess.WorkingSet64/1048576.0,"ticks",traceTicks,"captures",traceCaptures,"inputs",traceInputs,"errors",traceFailures,"stages",stages);
   Log("性能统计："+tracePerfText);
   traceCpuAt=cpu;tracePerfAt=now;traceTicks=traceCaptures=traceInputs=traceFailures=0;traceTimings.Clear();
  }catch(Exception ex){traceLastError="性能采样失败："+ex.Message;}
 }
 void TraceSettings(string reason){
  TraceEvent("route_coordinates","reason",reason,"serial",backend.Serial,"shenlong_x",navigationSettings.Shenlong.X,"shenlong_y",navigationSettings.Shenlong.Y,"shenlong_radius",navigationSettings.Shenlong.SearchRadius,"mengzhong_x",navigationSettings.Mengzhong.X,"mengzhong_y",navigationSettings.Mengzhong.Y,"mengzhong_radius",navigationSettings.Mengzhong.SearchRadius);
  TraceEvent("settings_snapshot","reason",reason,"window",windows.SelectedItem==null?null:windows.SelectedItem.ToString(),"window_handle",hwnd.ToInt64(),"serial",backend.Serial,"native_width",backend.Width,"native_height",backend.Height,"boss_enabled",bossEnabled.Checked,"boss_paid_enabled",bossPaidEnabled.Checked,"boss_paid_interval_minutes",bossPaidMinutes.Value,"maintenance_enabled",maintenanceEnabled.Checked,"recycle_enabled",recycleEnabled.Checked,"recycle_minutes",recycleMinutes.Value,"random_enabled",randomEnabled.Checked,"random_cooldown_seconds",randomCooldown.Value,"direction_ready",coordDirReady,"stick_set",mzStickSet,"direction_width",coordTableWidth,"direction_height",coordTableHeight,"priorities",mapPriority.NameList,"player_level",mapPriority.CurrentLevel);
  try{if(traceJournal!=null&&Directory.Exists(traceJournal.DirectoryPath))File.WriteAllText(Path.Combine(traceJournal.DirectoryPath,"session-info.txt"),DatedLogWriter.Release+Environment.NewLine+TraceContextText()+Environment.NewLine+"程序目录="+root+Environment.NewLine+"数据目录="+data+Environment.NewLine+"记录时刻="+DateTimeOffset.Now.ToString("o")+"；原因="+reason+Environment.NewLine+"截图="+backend.Width+"x"+backend.Height+"；方向表="+coordDirReady+" "+coordTableWidth+"x"+coordTableHeight+Environment.NewLine+"维护="+maintenanceEnabled.Checked+"；回收="+recycleEnabled.Checked+" 每"+recycleMinutes.Value+"分钟；随机石="+randomEnabled.Checked+" 冷却"+randomCooldown.Value+"秒"+Environment.NewLine+"下图优先="+mapPriority.NameList,Encoding.UTF8);}catch(Exception ex){traceLastError="会话信息保存失败："+ex.Message;}
 }
 string DiagnosticSummary(){
  var s=new StringBuilder();s.AppendLine("程序目录="+root+"；数据目录="+data);s.AppendLine(DatedLogWriter.Release+" | "+DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss.fff zzz"));
  s.AppendLine("会话："+(traceJournal==null?"未建立":traceJournal.SessionId));s.AppendLine("实例："+(backend.Serial??"未连接")+"；原生尺寸="+backend.Width+"x"+backend.Height+"；识别尺寸=1216x684");
  s.AppendLine("运行="+engine.Running+"；当前状态="+engine.Status);s.AppendLine("最近地图读数="+traceMap+"（帧"+traceLastMapFrame+"）；当前帧="+traceFrame+"；维护任务="+traceTask);
  s.AppendLine("主角色等级="+mapPriority.CurrentLevel+"；证据="+priorityLevelReason);s.AppendLine("预期地图="+prioritySelectedName+"；右上地图名="+priorityOcrReason);
  s.AppendLine("路线坐标：神龙="+GoalText(navigationSettings.Shenlong)+"；盟重="+GoalText(navigationSettings.Mengzhong)+"；配置="+RouteCoordinateSettings.FilePath(data,backgroundConnected?backend.Serial:""));
  s.AppendLine("入口占用="+mapPriority.Active+"；占用起点="+mapPriority.ActiveSince.ToString("o")+"；寻找目标="+mapPriority.SearchIndex+"；寻找起点="+mapPriority.SearchSince.ToString("o")+"；神龙起点="+mapPriority.HallSince.ToString("o"));
  s.AppendLine("右侧自动按钮="+lastAutoBattleDetail+"；等待反馈="+autoWaiting+"；本轮点击="+autoTries);
  s.AppendLine("BOSS阶段="+bossStage+"；目标="+bossActive+"；资源挑战="+bossPaid+"；进入已提交="+bossSubmitted+"；回城方式=等待游戏系统回城；盟重连续确认="+bossClearFrames);
  s.AppendLine(bossTimers.Text);if(bossSchedule!=null)s.AppendLine("BOSS下次检查="+bossSchedule.NextPollUtc.ToLocalTime().ToString("o")+"；计时保存异常="+bossSchedule.LastError);
  s.AppendLine(tracePerfText);s.AppendLine("最近等待原因："+traceGateLast);s.AppendLine("日志异常："+(traceLastError.Length==0?"无":traceLastError));
  if(traceJournal!=null){s.AppendLine("本次日志目录："+traceJournal.DirectoryPath);s.AppendLine(traceJournal.Summary());}
  s.AppendLine("--- 最近关键日志（最多80条）---");foreach(string line in traceRecent)s.AppendLine(line);return s.ToString();
 }
 void ExportDiagnosticBundle(){
  if(traceJournal==null){logCopyHint.Text="诊断日志未建立："+traceLastError;return;}
  if(traceExporting){logCopyHint.Text="诊断包正在后台导出";return;}
  using(var dialog=new SaveFileDialog{Title="导出本次诊断包",Filter="诊断压缩包|*.zip",FileName="996诊断-"+traceJournal.SessionId+".zip",InitialDirectory=data}){
   if(dialog.ShowDialog()!=DialogResult.OK)return;
   StartDiagnosticExport(dialog.FileName);
  }
 }
 void StartDiagnosticExport(string destination){
  if(traceExporting||traceJournal==null)return;
  traceExporting=true;TraceEvent("export_requested","destination",destination);
  string summary=DiagnosticSummary();string[] evidence=traceEvidence.ToArray();DiagnosticJournal journal=traceJournal;
  logCopyHint.Text="后台导出中，守护继续";
  System.Threading.ThreadPool.QueueUserWorkItem(delegate{
   string failure=null;string snapshot=Path.Combine(data,"temp","996-diagnostic-"+Guid.NewGuid().ToString("N"));
   try{
    if(!journal.CopySessionTo(snapshot))throw new IOException(journal.LastError);
    string info=Path.Combine(journal.DirectoryPath,"session-info.txt");if(File.Exists(info))File.Copy(info,Path.Combine(snapshot,"session-info.txt"));
    DiagnosticBundle.Write(destination,snapshot,summary,evidence);
   }catch(Exception ex){failure=ex.ToString();}
   finally{try{if(Directory.Exists(snapshot)){foreach(string file in Directory.GetFiles(snapshot))File.Delete(file);Directory.Delete(snapshot);}}catch{}}
   try{if(!IsDisposed&&IsHandleCreated)BeginInvoke((Action)delegate{
    traceExporting=false;if(traceClosed)return;
    if(failure==null){logCopyHint.Text="诊断包已导出";Log("诊断包已导出："+destination+"；包含本次事件、性能、摘要和最近证据，未上传");}
    else{traceLastError="导出失败："+failure;logCopyHint.Text="导出失败，详见日志";TraceEvent("export_error","error",failure);Log(traceLastError);}
   });}catch(InvalidOperationException){}
  });
 }
 void CloseDiagnostics(){if(traceClosed)return;try{TracePerformance(true);TraceEvent("session_end","status",engine.Status);if(traceJournal!=null)traceJournal.Dispose();if(traceProcess!=null)traceProcess.Dispose();}finally{traceClosed=true;}}
}

internal static class DiagnosticBundle {
 internal static void Write(string destination,string session,string summary,string[] evidence){
  // Export through a sibling temporary file so failures do not destroy an
  // existing user-selected archive. No network or broad directory collection.
  string temp=destination+"."+Guid.NewGuid().ToString("N")+".tmp";
  try{
   using(var stream=new FileStream(temp,FileMode.CreateNew,FileAccess.ReadWrite))using(var zip=new ZipArchive(stream,ZipArchiveMode.Create)){
    var text=zip.CreateEntry("诊断摘要.txt");using(var writer=new StreamWriter(text.Open(),Encoding.UTF8))writer.Write(summary);
    foreach(string file in Directory.GetFiles(session,"*.jsonl"))AddFile(zip,file,"events/"+Path.GetFileName(file));
    string info=Path.Combine(session,"session-info.txt");if(File.Exists(info))AddFile(zip,info,"session-info.txt");
    int start=Math.Max(0,evidence.Length-24),index=0;for(int i=start;i<evidence.Length;i++)if(File.Exists(evidence[i]))AddFile(zip,evidence[i],"evidence/"+(++index).ToString("D2")+"-"+Path.GetFileName(evidence[i]));
   }
   if(File.Exists(destination))File.Replace(temp,destination,null);else File.Move(temp,destination);
  }finally{if(File.Exists(temp))File.Delete(temp);}
 }
 static void AddFile(ZipArchive zip,string file,string name){
  var entry=zip.CreateEntry(name,CompressionLevel.Optimal);
  using(var input=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.ReadWrite))using(var output=entry.Open())input.CopyTo(output);
 }
}
