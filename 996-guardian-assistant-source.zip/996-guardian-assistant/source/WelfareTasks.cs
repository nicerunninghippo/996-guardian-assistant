﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;

// All coordinates are in the host's normalized 1216 x 684 game frame.
// Templates are real UI crops in pixel units; user annotation borders are excluded.
public sealed class WelfarePixels {
 public int W,H;public int[] Data;
 public WelfarePixels(Bitmap b){W=b.Width;H=b.Height;Data=FrameCache.Pixels(b);}
 public int At(int x,int y){return x<0||y<0||x>=W||y>=H?0:Data[y*W+x];}
 public static bool Bright(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return Math.Max(r,Math.Max(g,b))>150&&((r>100&&g>90)||g>145||(r>150&&g<100&&b<100));}
 public int[] Snapshot(Rectangle area){area=Rectangle.Intersect(area,new Rectangle(0,0,W,H));int[] a=new int[area.Width*area.Height];for(int y=0;y<area.Height;y++)Array.Copy(Data,(y+area.Y)*W+area.X,a,y*area.Width,area.Width);return a;}
 public static double Difference(int[] a,int[] b){if(a==null||b==null||a.Length!=b.Length||a.Length==0)return 0;int n=0;for(int i=0;i<a.Length;i++){int p=a[i],q=b[i];int d=Math.Abs(((p>>16)&255)-((q>>16)&255))+Math.Abs(((p>>8)&255)-((q>>8)&255))+Math.Abs((p&255)-(q&255));if(d>105)n++;}return (double)n/a.Length;}
 public int RedCount(Rectangle area){int n=0;area=Rectangle.Intersect(area,new Rectangle(0,0,W,H));for(int y=area.Top;y<area.Bottom;y++)for(int x=area.Left;x<area.Right;x++){int p=At(x,y),r=(p>>16)&255,g=(p>>8)&255,b=p&255;if(r>145&&r>g*1.7&&r>b*1.7)n++;}return n;}
}

public sealed class WelfarePatch {
 readonly WelfarePixels pixels;readonly bool dimText;public int W{get{return pixels.W;}}public int H{get{return pixels.H;}}
 public WelfarePatch(string path){dimText=path.Contains("inactive");using(Bitmap b=new Bitmap(path))pixels=new WelfarePixels(b);}
 bool Ink(int p){return WelfarePixels.Bright(p)||(dimText&&((p>>16)&255)>100&&((p>>8)&255)>100&&(p&255)>100);}
 public double Score(WelfarePixels f,int left,int top){if(left<0||top<0||left+W>f.W||top+H>f.H)return 0;int expected=0,actual=0,hit=0,n=0;long error=0;for(int y=0;y<H;y+=2)for(int x=0;x<W;x+=2){int a=pixels.At(x,y),b=f.At(left+x,top+y);bool aa=Ink(a),bb=Ink(b);if(aa)expected++;if(bb)actual++;if(aa&&bb)hit++;error+=Math.Abs(((a>>16)&255)-((b>>16)&255))+Math.Abs(((a>>8)&255)-((b>>8)&255))+Math.Abs((a&255)-(b&255));n++;}if(expected<8)return 0;return Math.Min(1-error/(765.0*n),2.0*hit/(expected+actual));}
 public double Find(WelfarePixels f,Rectangle area,out Point point){area=Rectangle.Intersect(area,new Rectangle(0,0,f.W,f.H));double best=0;Point found=Point.Empty;for(int y=area.Top;y<=area.Bottom-H;y++)for(int x=area.Left;x<=area.Right-W;x++){double s=Score(f,x,y);if(s>best){best=s;found=new Point(x,y);}}point=new Point(found.X+W/2,found.Y+H/2);return best;}
}

public sealed class WelfareClaim {
 public int Row;public Point Point;public Rectangle ChangeArea;
}
public sealed class WelfareReading {
 public bool Panel,PageReady,Complete,Unknown,Blocked,MainHud;public Point? Entry,Close,Tab;public string Detail="";public WelfarePixels Pixels;public List<WelfareClaim> Claims=new List<WelfareClaim>();
}
public sealed class WelfareDetector {
 readonly Dictionary<string,WelfarePatch> patches=new Dictionary<string,WelfarePatch>();
 readonly RecycleVision ownedPanels;
 public WelfareDetector(string root){ownedPanels=new RecycleVision(Directory.Exists(Path.Combine(root,"templates"))?root:Path.GetDirectoryName(root));string dir=Directory.Exists(Path.Combine(root,"templates"))?Path.Combine(root,"templates"):root;foreach(string name in new string[]{"title-center","close-center","tab-online","tab-demon","tab-demon-inactive","tab-online-active","demon-heading","online-heading","claim-reward","done-row","unmet-row","title-daily","free-heading","free-activate","free-done","close-daily","title-merge","tab-sign","tab-sign-inactive","tab-kill","tab-kill-active","sign-heading","kill-heading","sign-done","click-claim","kill-conditions"}){try{patches[name]=new WelfarePatch(Path.Combine(dir,"welfare-v413-"+name+".png"));}catch(IOException){}catch(ArgumentException){}}foreach(string kind in new[]{"online","daily","merge"})foreach(string part in new[]{"icon","label","frame"}){string name="entry-"+kind+"-"+part;try{patches[name]=new WelfarePatch(Path.Combine(dir,"welfare-v414-"+name+".png"));}catch(IOException){}catch(ArgumentException){}}}
 double Find(string name,WelfarePixels f,Rectangle r,out Point p){p=Point.Empty;WelfarePatch patch;return patches.TryGetValue(name,out patch)?patch.Find(f,r,out p):0;}
 bool Match(string name,WelfarePixels f,Rectangle area,double limit,out Point point){return Find(name,f,area,out point)>=limit;}
 static Rectangle Move(Rectangle r,int dx,int dy){r.Offset(dx,dy);return r;}
 static bool Metal(int p){int red=(p>>16)&255,g=(p>>8)&255,b=p&255;return red>48&&red<215&&Math.Abs(red-g)<24&&Math.Abs(g-b)<24;}
 static bool Red(int p){int red=(p>>16)&255,g=(p>>8)&255,b=p&255;return red>80&&red>g*1.65&&red>b*1.5;}
 static bool Gold(int p){int red=(p>>16)&255,g=(p>>8)&255,b=p&255;return red>135&&g>95&&b<165&&red>g*1.05&&g>b*1.2;}
 // This evidence vetoes HUD entry clicks. It never authorizes a close or
 // guesses the contents of an unrecognized window.
 bool HasModalFrame(WelfarePixels f){
  WelfarePatch cross;if(!patches.TryGetValue("close-center",out cross))return true;
  for(int cy=38;cy<365;cy+=2)for(int cx=450;cx<1165;cx+=2){
   if(!Gold(f.At(cx,cy))||!Red(f.At(cx-6,cy))||!Red(f.At(cx+6,cy)))continue;
   double cs=0;for(int yy=-3;yy<=3;yy++)for(int xx=-3;xx<=3;xx++)cs=Math.Max(cs,cross.Score(f,cx-cross.W/2+xx,cy-cross.H/2+yy));if(cs<.86)continue;
   double horizontal=0,vertical=0;
   for(int y=cy-26;y<=cy+3;y++){int n=0,total=0;for(int x=cx-225;x<cx-42;x+=3){if(Metal(f.At(x,y)))n++;total++;}horizontal=Math.Max(horizontal,(double)n/total);}
   if(horizontal<.72)continue;
   for(int x=cx-38;x<=cx-10;x++){int n=0,total=0;for(int y=cy+32;y<cy+212;y+=3){if(Metal(f.At(x,y)))n++;total++;}vertical=Math.Max(vertical,(double)n/total);}
   if(vertical>=.72)return true;
  }
  return false;
 }
 void FindEntry(WelfarePixels f,int kind,WelfareReading r){
  string name=kind==0?"online":kind==1?"daily":"merge";Point icon,label;
  // Use the full icon core plus its immediately adjoining label. The old
  // references contained clipped labels and the user's red annotation.
  double si=Find("entry-"+name+"-icon",f,kind==0?new Rectangle(690,30,190,100):new Rectangle(535,108,245,100),out icon);
  int labelWidth=kind==1?70:75,labelHeight=kind==0?23:24;
  Rectangle near=new Rectangle(icon.X-labelWidth/2-5,icon.Y+(kind==0?33:36)-labelHeight/2-5,labelWidth+10,labelHeight+10);
  double sl=Find("entry-"+name+"-label",f,near,out label);
  Point surround;double sf=Find("entry-"+name+"-frame",f,new Rectangle(icon.X-38,icon.Y-35,75,72),out surround);
  r.Detail+="；入口图标="+si.ToString("0.00")+" 完整图标="+sf.ToString("0.00")+" 标签="+sl.ToString("0.00")+" 候选="+icon.X+","+icon.Y;
  // Labels are drawn over the moving world. Require the distinctive icon
  // and its surrounding complete image; a changing text background must
  // not make a visible stationary button disappear from the detector.
  if(si>=.88&&sf>=.88){r.Entry=icon;r.MainHud=true;}
 }
 // A close-only observation for recovering an orphaned welfare window after
 // restart/preemption. No tabs, claims or entry buttons are authorized here.
 public WelfareReading ReadCloseOnly(Bitmap frame,int kind){return FrameCache.Get<WelfareReading>(frame,this,"close-only-"+kind,delegate {
  var r=new WelfareReading();if(frame==null||frame.Width!=1216||frame.Height!=684||kind<0||kind>2)return r;
  var f=new WelfarePixels(frame);Point at;string title=kind==0?"title-center":kind==1?"title-daily":"title-merge";
  double score=Find(title,f,new Rectangle(455,25,305,100),out at);r.Panel=score>=.82;r.Detail="完整福利标题="+score.ToString("0.00");if(!r.Panel)return r;
  WelfarePatch p=patches[title];int dx=at.X-p.W/2-(kind==1?583:544),dy=at.Y-p.H/2-(kind==1?42:kind==0?76:77);
  double close=Find(kind==1?"close-daily":"close-center",f,Move(new Rectangle(1002,45,55,74),dx,dy),out at);r.Detail+="；完整关闭="+close.ToString("0.00");if(close>=.86)r.Close=at;return r;
 });}
 public WelfareReading Read(Bitmap frame,int kind,int page){
  WelfareReading r=new WelfareReading();if(frame==null||frame.Width!=1216||frame.Height!=684){r.Detail="截图尺寸不匹配";return r;}WelfarePixels f=r.Pixels=new WelfarePixels(frame);Point at;
  string title=kind==0?"title-center":kind==1?"title-daily":"title-merge";
  double titleScore=Find(title,f,new Rectangle(455,25,305,100),out at);r.Panel=titleScore>=.82;r.Detail="窗口标题="+titleScore.ToString("0.00");
  if(!r.Panel){var owned=ownedPanels.Read(frame);r.Blocked=owned.Bag||owned.Page||HasModalFrame(f);if(r.Blocked){r.Detail+="；其他弹窗仍在，禁止穿透点击后方入口";return r;}FindEntry(f,kind,r);return r;}
  WelfarePatch p=patches[title];int originalX=kind==1?583:544,originalY=kind==1?42:kind==0?76:77;int dx=at.X-p.W/2-originalX,dy=at.Y-p.H/2-originalY;
  if(Match(kind==1?"close-daily":"close-center",f,Move(new Rectangle(1002,45,55,74),dx,dy),.86,out at))r.Close=at;
  if(kind==1){
   r.PageReady=Match("free-heading",f,Move(new Rectangle(374,78,205,64),dx,dy),.82,out at);if(!r.PageReady){r.Detail+="；免费日享标题未确认";return r;}
   // The entire authorized action area is left of the panel divider. Paid
   // 19元激活 and 购买一周 cannot enter this search rectangle.
   Rectangle left=Move(new Rectangle(362,475,205,69),dx,dy);
   if(Match("free-done",f,left,.80,out at)){r.Complete=true;r.Detail+="；免费日享已获得";return r;}
   if(Match("free-activate",f,left,.84,out at)){r.Claims.Add(new WelfareClaim{Row=0,Point=at,ChangeArea=left});r.Detail+="；左栏激活免费日享";return r;}
   r.Unknown=true;r.Detail+="；免费日享领取状态不明确，未点付费区";return r;
  }
  if(kind==0){
   string tab=page==0?"tab-online":"tab-demon",heading=page==0?"online-heading":"demon-heading";
   Rectangle tabArea=Move(page==0?new Rectangle(214,150,140,56):new Rectangle(214,353,140,55),dx,dy);
   if(Match(tab,f,tabArea,.78,out at)|| (page==0&&Match("tab-online-active",f,tabArea,.79,out at))||(page==1&&Match("tab-demon-inactive",f,tabArea,.79,out at)))r.Tab=at;
   r.PageReady=Match(heading,f,Move(new Rectangle(355,179,168,47),dx,dy),.79,out at);if(!r.PageReady)return r;
   int rows=page==0?5:4,known=0;int[] yy=page==0?new int[]{256,335,414,493,573}:new int[]{255,335,415,495};
   for(int i=0;i<rows;i++){
    Rectangle status=Move(new Rectangle(850,yy[i]-26,144,62),dx,dy);
    if(Match("done-row",f,status,.79,out at)||Match("unmet-row",f,status,.79,out at)){known++;continue;}
    if(Match("claim-reward",f,status,.82,out at)){r.Claims.Add(new WelfareClaim{Row=i,Point=at,ChangeArea=Move(new Rectangle(783,yy[i]-23,61,43),dx,dy)});known++;}
   }
   r.Complete=r.Claims.Count==0&&known==rows;r.Unknown=known<rows;r.Detail+="；"+(page==0?"在线奖励":"每日除魔")+" 可领="+r.Claims.Count+"，已确认="+known+"/"+rows;return r;
  }
  Rectangle mergeTab=Move(page==0?new Rectangle(219,105,133,51):new Rectangle(219,153,133,52),dx,dy);
  if(Match(page==0?"tab-sign":"tab-kill",f,mergeTab,.78,out at)||(page==1&&Match("tab-kill-active",f,mergeTab,.79,out at))||(page==0&&Match("tab-sign-inactive",f,mergeTab,.79,out at)))r.Tab=at;
  r.PageReady=Match(page==0?"sign-heading":"kill-heading",f,Move(page==0?new Rectangle(591,228,168,75):new Rectangle(604,203,143,65),dx,dy),.79,out at);if(!r.PageReady)return r;
  if(Match("sign-done",f,Move(new Rectangle(586,472,230,99),dx,dy),.78,out at)){r.Complete=true;r.Detail+="；已领取";return r;}
  Rectangle action=Move(page==0?new Rectangle(546,477,357,92):new Rectangle(742,511,166,69),dx,dy);
  // The free kill claim is the right-hand button. Never scan the left
  // 88元开通5倍领取 button, even when its text includes 领取.
  if(Match("click-claim",f,action,.79,out at)||Match("claim-reward",f,action,.82,out at)){
   if(page==1&&f.RedCount(Move(new Rectangle(696,417,116,28),dx,dy))>9){r.Complete=true;r.Detail+="；杀怪数量未达标";return r;}
   r.Claims.Add(new WelfareClaim{Row=0,Point=at,ChangeArea=Move(page==0?new Rectangle(587,471,325,104):new Rectangle(744,495,147,32),dx,dy)});r.Detail+="；免费领取按钮已确认";return r;
  }
  r.Unknown=true;r.Detail+="；领取状态不明，保留截图等待补样本";return r;
 }
}

// Bounded, cooperative tasks. No sleeps, device access, recursive retries or
// global configuration writes. The host owns the one input writer.
public abstract class WelfareTaskBase : IMaintenanceTask {
 readonly int kind;readonly Func<Bitmap,int,int,WelfareReading> observe;int state,page,tries,claims,clean,changedFrames;double started,stageAt,next,lastNow;bool active,success,seenPanel;string outcome="";WelfareClaim pending;int[] before,changeCandidate;readonly HashSet<int> blocked=new HashSet<int>();
 public abstract string Name{get;}public bool Active{get{return active;}}
 protected WelfareTaskBase(string root,int type){kind=type;observe=new WelfareDetector(root).Read;}
 internal WelfareTaskBase(int type,Func<Bitmap,int,int,WelfareReading> reader){kind=type;observe=reader;}
 public void Reset(){active=false;seenPanel=false;state=0;page=0;tries=0;claims=0;clean=0;changedFrames=0;pending=null;before=null;changeCandidate=null;blocked.Clear();lastNow=-1;}
 public void Begin(double now){Reset();active=true;success=true;started=stageAt=next=now;outcome="";}
 MaintenanceDecision Decision(string text,Point? tap){return new MaintenanceDecision{Tap=tap,Status=Name+"："+text+(tap.HasValue?"；点击="+tap.Value.X+","+tap.Value.Y:"")};}
 void Stage(int value,double now){state=value;stageAt=now;next=now;tries=0;clean=0;changedFrames=0;changeCandidate=null;}
 void Close(double now,bool ok,string why){success=success&&ok;if(outcome.Length>0)outcome+="；";outcome+=why;Stage(4,now);}
 void NextPage(double now,bool ok,string why){success=success&&ok;if(!ok){if(outcome.Length>0)outcome+="；";outcome+=why;}blocked.Clear();pending=null;before=null;if(kind!=1&&page==0){page=1;Stage(1,now);}else Close(now,success,"检查完成，确认领取操作="+claims);}
 public MaintenanceDecision Step(Bitmap frame,double now){
  if(!active)return new MaintenanceDecision{Done=true,Success=false,Status=Name+"未启动"};
  if(now<=lastNow)return Decision("等待新截图",null);lastNow=now;
  if(now-started>=150){active=false;return new MaintenanceDecision{Done=true,Success=false,Status=Name+"：达到150秒总上限，已释放任务；"+outcome};}
  if(now-started>=136&&state!=4)Close(now,false,"总时限将到，关闭自有窗口后恢复守护");
  WelfareReading r=observe(frame,kind,page);
  if(r.Panel)seenPanel=true;
  if(state==4){
   if(!r.Panel&&r.MainHud&&!r.Blocked){if(++clean>=2){active=false;return new MaintenanceDecision{Done=true,Success=success&&seenPanel,Status=Name+"："+outcome+(seenPanel?"；两帧主画面确认窗口关闭，恢复守护":"；未确认打开福利窗口，未执行领取，恢复守护")};}return Decision("已见主画面，等待第二帧确认；"+r.Detail,null);}
   clean=0;if(now-stageAt>=12){active=false;return new MaintenanceDecision{Done=true,Success=false,Status=Name+"：关闭验证超时，任务已释放；"+outcome};}
   if(r.Close.HasValue&&now>=next&&tries<3){tries++;next=now+3;return Decision("关闭本任务窗口，第"+tries+"次；"+r.Detail,r.Close);}
   return Decision("窗口去向未确认，等待主画面证据，最多12秒；"+r.Detail,null);
  }
  if(state==0){
   if(r.Panel){Stage(1,now);return Decision("已打开，确认指定栏目",null);}
   if(r.Blocked){active=false;return new MaintenanceDecision{Done=true,Success=false,Status=Name+"：其他弹窗阻挡，本轮未打开福利入口；"+r.Detail};}
   if(now-stageAt>=12){Close(now,false,"入口打开超时");return Decision("入口未打开，结束本轮",null);}
   if(r.Entry.HasValue&&now>=next&&tries<3){tries++;next=now+3;return Decision("打开入口，第"+tries+"次；"+r.Detail,r.Entry);}
   return Decision("等待入口图样，最多12秒；"+r.Detail,null);
  }
  if(state==1){
   if(r.Panel&&r.PageReady){Stage(2,now);return Decision("栏目已确认；"+r.Detail,null);}
   if(now-stageAt>=12){NextPage(now,false,"栏目切换12秒未确认，跳过");return Decision("栏目未确认，跳过该栏目",null);}
   if(r.Panel&&r.Tab.HasValue&&now>=next&&tries<3){tries++;next=now+3;return Decision("切换栏目，第"+tries+"次；"+r.Detail,r.Tab);}
   return Decision("等待栏目出现，最多12秒",null);
  }
  if(!r.Panel||!r.PageReady){if(now-stageAt>=12){NextPage(now,false,"领取页面消失或被遮挡");return Decision("领取页丢失，结束该栏目",null);}return Decision("领取页面暂未确认，暂停点击",null);}
  if(state==3){
   bool remains=false;foreach(WelfareClaim c in r.Claims)if(c.Row==pending.Row)remains=true;
   int[] current=r.Pixels.Snapshot(pending.ChangeArea);
   bool countChanged=(kind==0||kind==2)&&page==1&&WelfarePixels.Difference(before,current)>=.025;
   if(countChanged){if(changeCandidate!=null&&WelfarePixels.Difference(changeCandidate,current)<.015)changedFrames++;else changedFrames=1;changeCandidate=current;}else{changedFrames=0;changeCandidate=null;}
   // A disappearing button is not sufficient when the row became unknown.
   bool terminal=(!remains&&!r.Unknown)||r.Complete;
   if(terminal)clean++;else clean=0;
   if(clean>=2||changedFrames>=2){claims++;pending=null;before=null;Stage(2,now);return Decision("连续两帧确认领取状态或次数改变",null);}
   if(now-stageAt>=10){blocked.Add(pending.Row);success=false;outcome+="；一项领取无反馈，已跳过";pending=null;before=null;Stage(2,now);return Decision("领取10秒无明确反馈，跳过本项，不连点",null);}
   return Decision("等待领取结果，不重复点击",null);
  }
  if(r.Complete){NextPage(now,true,"");return Decision("本栏目已领完或未达标；"+r.Detail,null);}
  foreach(WelfareClaim c in r.Claims){if(blocked.Contains(c.Row))continue;if(claims>=40){NextPage(now,false,"单轮40次领取上限，剩余留待下轮");return Decision("达到本轮领取上限",null);}pending=c;before=r.Pixels.Snapshot(c.ChangeArea);Stage(3,now);return Decision("领取已确认的免费奖励；"+r.Detail,c.Point);}
  if(now-stageAt>=10){NextPage(now,false,"状态未读清或领取无反馈，保留到下轮");return Decision("本栏目状态不明，结束本轮检查",null);}
  return Decision("复核已领取/未达标/可领取状态，最多10秒；"+r.Detail,null);
 }
}
public sealed class OnlineDemonTask : WelfareTaskBase {public OnlineDemonTask(string root):base(root,0){}public override string Name{get{return "在线奖励与每日除魔";}}}
public sealed class DailyFreeTask : WelfareTaskBase {public DailyFreeTask(string root):base(root,1){}public override string Name{get{return "免费日享";}}}
public sealed class MergeRewardsTask : WelfareTaskBase {public MergeRewardsTask(string root):base(root,2){}public override string Name{get{return "合区签到与杀怪奖励";}}}
