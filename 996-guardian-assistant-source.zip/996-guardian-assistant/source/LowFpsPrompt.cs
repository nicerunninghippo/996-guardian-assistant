using System;
using System.Drawing;
using System.IO;

public sealed class LowFpsReading {
 public bool Prompt,CanCancel;
 public Point Cancel;
}
public sealed class LowFpsPromptDetector {
 readonly Mask title,cancel;
 public LowFpsPromptDetector(string root){
  using(Bitmap b=new Bitmap(Path.Combine(root,"templates","lowfps-title-v413.png")))title=new Mask(b,false);
  using(Bitmap b=new Bitmap(Path.Combine(root,"templates","lowfps-cancel-v413.png")))cancel=new Mask(b,false);
 }
 public LowFpsReading Read(Bitmap image){
  var result=new LowFpsReading();if(image==null||image.Width!=1216||image.Height!=684)return result;
  var frame=new Mask(image,false);Point at,button;
  result.Prompt=title.Find(frame,new Rectangle(300,210,600,160),out at)>=.84;
  if(!result.Prompt)return result;
  result.CanCancel=cancel.Find(frame,new Rectangle(at.X+135,at.Y+60,145,95).IntersectSafe(image),out button)>=.84;
  if(result.CanCancel)result.Cancel=button;return result;
 }
}

public sealed class LowFpsPromptFlow {
 bool active;int attempts,clean;double next,last=-1;
 public void Reset(){active=false;attempts=clean=0;next=0;last=-1;}
 public FarmPopupAction Step(LowFpsReading seen,double now,bool running){
  var a=new FarmPopupAction();if(!running){Reset();return a;}
  if(!seen.Prompt){
   if(!active)return a;
   a.Handled=true;a.Status="低帧率提示已暂时消失，等待新截图确认";
   if(now>last){last=now;clean++;}
   if(clean>=2){Reset();a.Recovered=true;a.Status="已取消低帧率切换，继续原任务";}return a;
  }
  active=true;clean=0;a.Handled=true;
  bool fresh=now>last;last=Math.Max(last,now);
  if(!seen.CanCancel){a.Status="低帧率提示已确认，取消按钮未读清；继续识别，不点确定";return a;}
  a.Status="等待低帧率提示取消反馈";
  if(!fresh||now<next)return a;
  attempts++;a.Tap=seen.Cancel;
  if(attempts>=3){attempts=0;next=now+60;a.Status="取消低帧率提示（本轮第3次）；若仍未消失，60秒后重新确认";}
  else{next=now+3;a.Status="点击低帧率提示的取消按钮；等待关闭验证";}
  return a;
 }
}

partial class Guardian {
 LowFpsPromptDetector lowFpsDetector;readonly LowFpsPromptFlow lowFpsFlow=new LowFpsPromptFlow();
 string lowFpsLast="";DateTime lowFpsLogAt=DateTime.MinValue;
 bool HandleLowFpsPrompt(Bitmap image){
  if(lowFpsDetector==null)lowFpsDetector=new LowFpsPromptDetector(root);
  var action=lowFpsFlow.Step(lowFpsDetector.Read(image),ClockSeconds(),guardRequested&&engine.Running);
  if(!action.Handled)return false;
  engine.ResetObservation();engine.ResetPending();ResetHealthEvidence();
  if(action.Tap.HasValue&&!Click(action.Tap.Value))action.Status="取消按钮点击未发出；下一帧重新确认";
  engine.Status=action.Status;
  if(action.Tap.HasValue||action.Recovered||lowFpsLast!=action.Status||(DateTime.Now-lowFpsLogAt).TotalSeconds>=30){
   Log(action.Status);lowFpsLast=action.Status;lowFpsLogAt=DateTime.Now;
  }
  return true;
 }
}
