using System;
using System.IO;
using System.Drawing;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

// Read the player's bottom HP number only. The target percentage, orb, and MP
// field never contribute to this result. An incomplete or ambiguous read fails.
public sealed class HealthReader {
 sealed class Sample { public int Symbol; public double[] Values; }
 sealed class Glyph { public Rectangle Box; public int Symbol; }
 readonly List<Sample> samples=new List<Sample>();
 readonly bool complete;
 const int FeatureWidth=14,FeatureHeight=20,Slash=10;
 static readonly Rectangle Row=new Rectangle(329,661,96,17);
 public HealthReader(string templateDirectory) {
  bool[] loaded=new bool[11];
  if(Directory.Exists(templateDirectory))foreach(string file in Directory.GetFiles(templateDirectory,"hp-v47-*.png")) {
   string[] parts=Path.GetFileNameWithoutExtension(file).Split('-');int symbol;
   if(parts.Length<4)continue;
   if(parts[2]=="slash")symbol=Slash;
   else if(!int.TryParse(parts[2],out symbol)||symbol<0||symbol>9)continue;
   try { using(Bitmap image=new Bitmap(file)) {
    if(image.Width<2||image.Width>12||image.Height<9||image.Height>18)continue;
    samples.Add(new Sample{Symbol=symbol,Values=Feature(image,new Rectangle(0,0,image.Width,image.Height))});loaded[symbol]=true;
   }} catch(ArgumentException){} catch(IOException){}
  }
  complete=true;for(int i=0;i<loaded.Length;i++)if(!loaded[i])complete=false;
 }
 static int White(Color pixel){return Math.Min(pixel.R,Math.Min(pixel.G,pixel.B));}
 static double Ink(Bitmap image,int x,int y,double brightnessScale){return Math.Max(0,Math.Min(1,(White(image.GetPixel(x,y))*brightnessScale-75)/140.0));}
 static double[] Feature(Bitmap image,Rectangle box){return Feature(image,box,1);}
 static double[] Feature(Bitmap image,Rectangle box,double brightnessScale) {
  double[] result=new double[FeatureWidth*FeatureHeight];
  for(int y=0;y<FeatureHeight;y++)for(int x=0;x<FeatureWidth;x++) {
   double sx=Math.Max(0,Math.Min(box.Width-1,(x+.5)*box.Width/FeatureWidth-.5));
   double sy=Math.Max(0,Math.Min(box.Height-1,(y+.5)*box.Height/FeatureHeight-.5));
   int x0=(int)sx,y0=(int)sy,x1=Math.Min(box.Width-1,x0+1),y1=Math.Min(box.Height-1,y0+1);
   double ax=sx-x0,ay=sy-y0;
   double a=Ink(image,box.X+x0,box.Y+y0,brightnessScale)*(1-ax)+Ink(image,box.X+x1,box.Y+y0,brightnessScale)*ax;
   double b=Ink(image,box.X+x0,box.Y+y1,brightnessScale)*(1-ax)+Ink(image,box.X+x1,box.Y+y1,brightnessScale)*ax;
   result[y*FeatureWidth+x]=a*(1-ay)+b*ay;
  }
  return result;
 }
 static double Error(double[] a,double[] b){double sum=0;for(int i=0;i<a.Length;i++){double d=a[i]-b[i];sum+=d*d;}return sum/a.Length;}
 public bool TryRead(Bitmap frame,out int current,out int maximum,out string detail) {
  current=maximum=-1;detail="生命值未读清";
  if(frame==null){detail="生命值截图为空";return false;}
  if(frame.Width!=1216||frame.Height!=684){detail="生命值截图必须归一化为1216×684";return false;}
  if(!complete){detail="生命值模板不完整（需要0—9及斜杠）";return false;}
  int peak=0;
  for(int y=Row.Top;y<Row.Bottom;y++)for(int x=Row.Left;x<Row.Right;x++)peak=Math.Max(peak,White(frame.GetPixel(x,y)));
  if(peak<85){detail="生命值文字对比度不足";return false;}
  // A modal window can dim the whole HUD uniformly. Restore brightness only;
  // never restore missing pixels or loosen the character confidence limits.
  double brightnessScale=peak<180?255.0/peak:1;
  double threshold=peak<180?Math.Max(65,peak*.55):140;
  List<Glyph> glyphs=new List<Glyph>();int start=-1;
  // The row ends above the HUD border. Its 17 pixels cover both observed
  // vertical positions; only the slash can extend below the digit baseline.
  for(int column=0;column<=Row.Width;column++) {
   bool occupied=false;
   if(column<Row.Width)for(int y=0;y<Row.Height;y++)if(White(frame.GetPixel(Row.X+column,Row.Y+y))>threshold){occupied=true;break;}
   if(occupied&&start<0)start=column;
   if(!occupied&&start>=0) {
    int first=Row.Height,last=-1,occupiedRows=0;
    for(int y=0;y<Row.Height;y++) {
     bool ink=false;for(int x=start;x<column;x++)if(White(frame.GetPixel(Row.X+x,Row.Y+y))>threshold){ink=true;break;}
     if(ink){first=Math.Min(first,y);last=y;occupiedRows++;}
    }
    int width=column-start,height=last-first+1;
    if(start==0||column==Row.Width||width<3||width>10||height<10||height>17||occupiedRows<9){detail="生命值字格缺失、遮挡或模糊";return false;}
    glyphs.Add(new Glyph{Box=new Rectangle(Row.X+start,Row.Y+first,width,height)});start=-1;
   }
  }
  if(glyphs.Count<3||glyphs.Count>11){detail="生命值完整分数未读清";return false;}
  // The game centers this label in its HP cell. A missing leading/trailing
  // digit must not silently turn full HP into a plausible low-HP fraction.
  double textCenter=(glyphs[0].Box.Left+glyphs[glyphs.Count-1].Box.Right)/2.0;
  if(textCenter<372||textCenter>378){detail="生命值文字偏移或两端数字缺失";return false;}
  StringBuilder number=new StringBuilder(),evidence=new StringBuilder();int separator=-1,minTop=1000,maxTop=0,minBottom=1000,maxBottom=0;
  for(int index=0;index<glyphs.Count;index++) {
   Glyph glyph=glyphs[index];
   if(index>0&&glyph.Box.Left-glyphs[index-1].Box.Right>6){detail="生命值数字间距异常";return false;}
   double[] values=Feature(frame,glyph.Box,brightnessScale),scores=new double[11];for(int i=0;i<scores.Length;i++)scores[i]=double.PositiveInfinity;
   foreach(Sample sample in samples)scores[sample.Symbol]=Math.Min(scores[sample.Symbol],Error(values,sample.Values));
   int best=0;for(int i=1;i<scores.Length;i++)if(scores[i]<scores[best])best=i;
   double second=double.PositiveInfinity;for(int i=0;i<scores.Length;i++)if(i!=best)second=Math.Min(second,scores[i]);
   double gap=second-scores[best];glyph.Symbol=best;
   evidence.Append(best==Slash?"/":best.ToString()).Append('(').Append(scores[best].ToString("0.000",CultureInfo.InvariantCulture)).Append('/').Append(gap.ToString("0.000",CultureInfo.InvariantCulture)).Append(") ");
   if(scores[best]>.070||gap<.015){detail="生命值字形低置信；"+evidence;return false;}
   if(best==Slash) {
    if(separator>=0||glyph.Box.Width>7||glyph.Box.Height<13){detail="生命值斜杠不完整";return false;}
    separator=index;number.Append('/');
   } else {
    if(glyph.Box.Height<10||glyph.Box.Height>14){detail="生命值数字高度异常";return false;}
    minTop=Math.Min(minTop,glyph.Box.Top);maxTop=Math.Max(maxTop,glyph.Box.Top);minBottom=Math.Min(minBottom,glyph.Box.Bottom);maxBottom=Math.Max(maxBottom,glyph.Box.Bottom);number.Append(best);
   }
  }
  if(separator<1||separator>5||glyphs.Count-separator-1<1||glyphs.Count-separator-1>5||maxTop-minTop>2||maxBottom-minBottom>2){detail="生命值当前/最大完整格式未确认";return false;}
  Rectangle slash=glyphs[separator].Box;
  if(slash.Top>minTop||slash.Bottom<maxBottom){detail="生命值斜杠位置异常";return false;}
  string[] parts=number.ToString().Split('/');int readCurrent,readMaximum;
  if(parts.Length!=2||!int.TryParse(parts[0],out readCurrent)||!int.TryParse(parts[1],out readMaximum)||readMaximum<=0||readCurrent>readMaximum||(parts[0].Length>1&&parts[0][0]=='0')||(parts[1].Length>1&&parts[1][0]=='0')){detail="生命值数值或完整格式异常";return false;}
  current=readCurrent;maximum=readMaximum;detail="底部生命值="+number+"（"+(100.0*current/maximum).ToString("0.0",CultureInfo.InvariantCulture)+"%）；字形误差/差距="+evidence.ToString().Trim();return true;
 }
}
