﻿using System;
using System.Drawing;

static class RouteTapGuard {
 // The old chat rectangle also covers world scenery. A narrowly scoped exception
 // requires the current Jiaolong frame, a strong NPC label and visible scenery.
 static readonly Rectangle JiaolongNpcArea=new Rectangle(300,180,260,210);
 static readonly Rectangle TargetPortalArea=new Rectangle(80,240,900,340);
 public static bool ConfirmJiaolongNpc(Bitmap frame,int map,Point point,double score){
  if(map!=2||score<.82||!JiaolongNpcArea.Contains(point))return false;
  Rectangle around=new Rectangle(point.X-60,point.Y-70,120,90).IntersectSafe(frame);
  int total=0,visible=0;
  for(int y=around.Top;y<around.Bottom;y+=3)for(int x=around.Left;x<around.Right;x+=3){
   Color c=frame.GetPixel(x,y);total++;
   if((c.R*299+c.G*587+c.B*114)/1000>85)visible++;
  }
  // An expanded chat panel or dark overlay must not receive the exception.
  return total>0&&visible>total*.60;
 }
 public static bool IsProtected(Point p,bool verifiedJiaolongNpc,out string why){
  return IsProtected(p,verifiedJiaolongNpc,false,out why);
 }
 public static bool ConfirmTargetPortal(Bitmap frame,int map,Point p,double score){
  // The complete-name detector now includes the two doors left of the old row.
  // Joystick and bottom-chat exclusions remain unconditional below.
  if(map!=3||score<.76||!TargetPortalArea.Contains(p))return false;
  Rectangle around=new Rectangle(p.X-44,p.Y-50,88,100).IntersectSafe(frame);
  int total=0,portal=0;
  for(int y=around.Top;y<around.Bottom;y+=2)for(int x=around.Left;x<around.Right;x+=2){
   Color c=frame.GetPixel(x,y);total++;
   if(c.B>140&&c.B>c.R*1.1&&c.B>c.G*1.15 || c.B>145&&c.R>95&&c.G<c.B*.8)portal++;
  }
  return total>0&&portal>total*.08;
 }
 public static bool IsProtected(Point p,bool verifiedJiaolongNpc,bool verifiedTargetPortal,out string why){
  why="";
  if(p==Point.Empty||p.X<0||p.Y<0||p.X>=1216||p.Y>=684){why="无效点击坐标";return true;}
  if(new Rectangle(20,390,270,285).Contains(p)){why="识别点落入跑/走摇杆保护区("+p.X+","+p.Y+")，已忽略";return true;}
  if(new Rectangle(435,540,555,125).Contains(p)){why="识别点落入底部聊天文字保护区("+p.X+","+p.Y+")，已忽略";return true;}
  bool allowedPortal=verifiedTargetPortal&&TargetPortalArea.Contains(p);
  if(new Rectangle(0,235,430,449).Contains(p)&&!(verifiedJiaolongNpc&&JiaolongNpcArea.Contains(p))&&!allowedPortal){
   why="识别点落入左下聊天保护区("+p.X+","+p.Y+")，已忽略";return true;
  }
  return false;
 }
}
