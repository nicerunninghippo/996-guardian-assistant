using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

// Only future generated screenshots in diagnostics-current are managed here.
// Historic diagnostics, run journals, configuration, unknown files and all
// subdirectories are outside deletion scope. Errors stop evidence admission,
// never the guard itself. Intended for the existing serial SaveDiagnostic call.
internal sealed class DiagnosticRetention
{
    internal const long DefaultMaxBytes = 512L * 1024 * 1024;
    internal const long DefaultMinimumFreeBytes = 1024L * 1024 * 1024;
    internal const long DefaultWriteReserveBytes = 8L * 1024 * 1024;
    internal static readonly TimeSpan DefaultMaxAge = TimeSpan.FromDays(7);
    internal static readonly TimeSpan ScanInterval = TimeSpan.FromSeconds(60);
    internal static readonly TimeSpan WriteProtection = TimeSpan.FromMinutes(2);
    static readonly Regex GeneratedStem = new Regex(@"^\d{8}-\d{6}-\d{3}-f\d{1,20}-[A-Za-z0-9_][A-Za-z0-9_-]{0,79}$", RegexOptions.CultureInvariant);
    readonly object gate = new object();
    readonly Func<DateTime> utcNow;
    readonly Func<string, long> freeBytes;
    readonly long maxBytes, minimumFreeBytes, writeReserveBytes;
    readonly TimeSpan maxAge;
    readonly Dictionary<string, long> knownSizes = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
    DateTime nextScanUtc = DateTime.MinValue;
    bool scanned, scanGood;
    string setupError = "";
    long bytes;

    sealed class Member
    {
        internal string Path;
        internal long Length;
        internal DateTime Written;
    }
    sealed class Group
    {
        internal string Name;
        internal bool Protected;
        internal DateTime Written = DateTime.MinValue;
        internal List<Member> Files = new List<Member>();
    }

    internal string DirectoryPath { get; private set; }
    internal string Status { get; private set; }
    internal long Bytes { get { lock (gate) return bytes; } }
    internal int ScanCount { get; private set; }
    internal int LastPrunedGroups { get; private set; }

    internal DiagnosticRetention(string directory)
        : this(directory, DefaultMaxBytes, DefaultMaxAge, DefaultMinimumFreeBytes,
               DefaultWriteReserveBytes, delegate { return DateTime.UtcNow; },
               delegate(string path) { return new DriveInfo(Path.GetPathRoot(path)).AvailableFreeSpace; }) { }

    // Limits/clock/free-space injection allows small, fully isolated disk tests.
    internal DiagnosticRetention(string directory, long limit, TimeSpan age,
        long minimumFree, long reserve, Func<DateTime> clock, Func<string, long> diskFree)
    {
        maxBytes = limit; maxAge = age; minimumFreeBytes = minimumFree;
        writeReserveBytes = reserve; utcNow = clock; freeBytes = diskFree;
        DirectoryPath = ""; Status = "";
        try
        {
            if (limit <= 0 || age <= TimeSpan.Zero || minimumFree < 0 || reserve < 0 || reserve > limit || clock == null || diskFree == null)
                throw new ArgumentException("诊断容量参数无效");
            string path = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            if (!String.Equals(Path.GetFileName(path), "diagnostics-current", StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("只允许管理新的 diagnostics-current 目录");
            DirectoryPath = path;
        }
        catch (Exception ex) { setupError = Status = ex.Message; }
    }

    // SafeReason also avoids the reserved title-image suffix, so filename
    // grouping is unambiguous even when a caller supplies a custom reason.
    internal static string SafeReason(string reason)
    {
        var value = new StringBuilder();
        foreach (char c in reason ?? "")
        {
            if (value.Length >= 72) break;
            value.Append((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                         (c >= '0' && c <= '9') || c == '_' || c == '-' ? c : '_');
        }
        if (value.Length == 0) value.Append("diagnostic");
        if (value[0] == '-') value[0] = '_';
        if (value.ToString().EndsWith("-title", StringComparison.OrdinalIgnoreCase)) value.Append('_');
        return value.ToString();
    }

    internal bool ReadyToSave(out string status)
    {
        lock (gate)
        {
            try
            {
                if (setupError.Length != 0) throw new IOException(setupError);
                EnsureSafeDirectory();
                DateTime now = utcNow();
                if (!scanned || now >= nextScanUtc)
                {
                    scanned = true; scanGood = false; nextScanUtc = now.Add(ScanInterval);
                    ScanAndPrune(now);
                    scanGood = true;
                }
                if (!scanGood) { status = Status; return false; }
                if (bytes > maxBytes - writeReserveBytes)
                {
                    status = Status = "诊断截图达到容量上限，等待下一次清理；正在写入或无法清理的文件已保留";
                    return false;
                }
                if (freeBytes(DirectoryPath) < minimumFreeBytes + writeReserveBytes)
                {
                    status = Status = "磁盘剩余空间不足，已暂停诊断截图（保留至少1GB可用空间）";
                    return false;
                }
                status = Status = "";
                return true;
            }
            catch (Exception ex)
            {
                status = Status = "诊断截图暂不可写：" + ex.Message;
                return false;
            }
        }
    }

    // Call from finally after the image/title/text writes, including a partial
    // write failure. Reads at most three file metadata entries; never rescans.
    internal void AfterSave(string basePath)
    {
        lock (gate)
        {
            try
            {
                if (setupError.Length != 0) return;
                EnsureSafeDirectory();
                string full = Path.GetFullPath(basePath);
                if (!String.Equals(Path.GetDirectoryName(full), DirectoryPath, StringComparison.OrdinalIgnoreCase) || !IsGeneratedStem(Path.GetFileName(full)))
                    throw new IOException("诊断文件名或位置无效");
                foreach (string suffix in new string[] { ".png", "-title.png", ".txt" })
                {
                    string path = full + suffix;
                    long previous; knownSizes.TryGetValue(path, out previous);
                    var info = new FileInfo(path);
                    long current = 0;
                    if (info.Exists)
                    {
                        if ((info.Attributes & FileAttributes.ReparsePoint) != 0) throw new IOException("诊断文件不能是链接");
                        current = info.Length;
                    }
                    knownSizes[path] = current;
                    bytes += current - previous;
                }
                if (bytes > maxBytes) Status = "诊断截图已达容量上限，暂停后续截图并等待清理";
            }
            catch (Exception ex)
            {
                scanGood = false;
                Status = "诊断截图大小核对失败：" + ex.Message;
            }
        }
    }

    void EnsureSafeDirectory()
    {
        ValidateDirectoryChain();
        Directory.CreateDirectory(DirectoryPath);
        ValidateDirectoryChain();
    }

    void ValidateDirectoryChain()
    {
        if (DirectoryPath.Length == 0) throw new IOException("诊断目录无效");
        for (DirectoryInfo dir = new DirectoryInfo(DirectoryPath); dir != null; dir = dir.Parent)
        {
            if (dir.Exists && (dir.Attributes & FileAttributes.ReparsePoint) != 0)
                throw new IOException("诊断目录及父目录不能是链接或联接点");
        }
    }

    static bool IsGeneratedStem(string stem)
    {
        if (!GeneratedStem.IsMatch(stem)) return false;
        DateTime parsed;
        return DateTime.TryParseExact(stem.Substring(0, 19), "yyyyMMdd-HHmmss-fff", CultureInfo.InvariantCulture, DateTimeStyles.None, out parsed);
    }

    static string GroupName(string filename)
    {
        string extension = Path.GetExtension(filename);
        if (!String.Equals(extension, ".png", StringComparison.OrdinalIgnoreCase) && !String.Equals(extension, ".txt", StringComparison.OrdinalIgnoreCase)) return null;
        string stem = Path.GetFileNameWithoutExtension(filename);
        if (String.Equals(extension, ".png", StringComparison.OrdinalIgnoreCase) && stem.EndsWith("-title", StringComparison.OrdinalIgnoreCase))
            stem = stem.Substring(0, stem.Length - 6);
        return IsGeneratedStem(stem) ? stem : null;
    }

    void ScanAndPrune(DateTime now)
    {
        ScanCount++; LastPrunedGroups = 0; knownSizes.Clear(); bytes = 0;
        var groups = new Dictionary<string, Group>(StringComparer.OrdinalIgnoreCase);
        // Explicit top-level scan: never enumerate or delete a subdirectory.
        foreach (string path in Directory.GetFiles(DirectoryPath, "*", SearchOption.TopDirectoryOnly))
        {
            var info = new FileInfo(path);
            bool linked = (info.Attributes & FileAttributes.ReparsePoint) != 0;
            string name = GroupName(info.Name);
            Group group = null;
            if (name != null && !groups.TryGetValue(name, out group)) { group = new Group { Name = name }; groups.Add(name, group); }
            if (linked)
            {
                if (group != null) group.Protected = true;
                continue;
            }
            long length = info.Length;
            knownSizes[path] = length; bytes += length;
            if (name == null) continue; // Unknown files consume budget but cannot be deleted.
            DateTime written = info.LastWriteTimeUtc;
            group.Files.Add(new Member { Path = path, Length = length, Written = written });
            if (written > group.Written) group.Written = written;
        }
        var ordered = new List<Group>(groups.Values);
        ordered.Sort(delegate(Group a, Group b) { int c = a.Written.CompareTo(b.Written); return c != 0 ? c : StringComparer.Ordinal.Compare(a.Name, b.Name); });
        foreach (Group group in ordered)
        {
            if (group.Protected) continue;
            if (group.Written >= now.Subtract(WriteProtection)) continue;
            if (group.Written >= now.Subtract(maxAge) && bytes <= maxBytes - writeReserveBytes) continue;
            TryDeleteGroup(group);
        }
    }

    void TryDeleteGroup(Group group)
    {
        var held = new List<FileStream>();
        try
        {
            ValidateDirectoryChain();
            // Preflight every member before deleting any. A locked/readonly or
            // changed file protects the entire group, including its metadata.
            foreach (Member member in group.Files)
            {
                var info = new FileInfo(member.Path);
                if (!info.Exists || (info.Attributes & (FileAttributes.ReparsePoint | FileAttributes.ReadOnly)) != 0 ||
                    info.Length != member.Length || info.LastWriteTimeUtc != member.Written) return;
                held.Add(new FileStream(member.Path, FileMode.Open, FileAccess.Read, FileShare.Read | FileShare.Delete));
            }
            ValidateDirectoryChain();
            foreach (Member member in group.Files)
            {
                File.Delete(member.Path);
                bytes -= member.Length; knownSizes.Remove(member.Path);
            }
            LastPrunedGroups++;
        }
        catch (Exception ex) { Status = "部分诊断文件暂时无法清理：" + ex.Message; }
        finally { foreach (FileStream stream in held) { try { stream.Dispose(); } catch { } } }
    }
}
