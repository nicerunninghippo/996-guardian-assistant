using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;

public sealed class RewardPopupReading {
 public bool Present,Suspected;
 public Point Dismiss;
 public string Detail="";
 public double TitleScore,HintScore;
 public Point TitleAt,HintAt;
}

// The reward overlay has neither a close cross nor an ordinary button. Both
// complete labels must match their expected relative layout before granting
// the one dismiss point outside the reward rectangle. A lone label blocks
// underlying clicks through Suspected, but never authorizes a click itself.
public sealed class RewardPopupDetector {
 const double TitleThreshold=.86,HintThreshold=.88;
 static bool On(int argb,bool gold){
  int r=(argb>>16)&255,g=(argb>>8)&255,b=argb&255;
  return gold?r>=170&&g>=110&&b<=215&&r>=g+8:r>=180&&g>=180&&b>=180&&Math.Max(r,Math.Max(g,b))-Math.Min(r,Math.Min(g,b))<=35;
 }
 sealed class Region {
  public readonly Rectangle Bounds;public readonly bool[] Bits;readonly int[] sums;readonly int pitch;
  public Region(int[] pixels,int width,Rectangle bounds,bool gold){
   Bounds=bounds;Bits=new bool[bounds.Width*bounds.Height];pitch=bounds.Width+1;sums=new int[pitch*(bounds.Height+1)];
   for(int y=0;y<bounds.Height;y++){int row=0;for(int x=0;x<bounds.Width;x++){
    bool ink=On(pixels[(bounds.Y+y)*width+bounds.X+x],gold);Bits[y*bounds.Width+x]=ink;if(ink)row++;
    sums[(y+1)*pitch+x+1]=sums[y*pitch+x+1]+row;
   }}
  }
  public int Count(int x,int y,int w,int h){return sums[(y+h)*pitch+x+w]-sums[y*pitch+x+w]-sums[(y+h)*pitch+x]+sums[y*pitch+x];}
 }
 sealed class Patch {
  public readonly int Width,Height,Count;readonly Point[] ink;
  public Patch(string file,bool gold){
   using(Bitmap b=new Bitmap(file)){
    Width=b.Width;Height=b.Height;int[] px=FrameCache.Pixels(b);var points=new List<Point>();
    for(int y=0;y<Height;y++)for(int x=0;x<Width;x++)if(On(px[y*Width+x],gold))points.Add(new Point(x,y));
    // Interleave glyph pixels spatially. A nonmatching background can fail
    // quickly without scanning only the first letter of the phrase.
    var ordered=new List<Point>();for(int offset=0;offset<23;offset++)for(int i=offset;i<points.Count;i+=23)ordered.Add(points[i]);
    ink=ordered.ToArray();Count=ink.Length;
   }
  }
  public double Find(Region region,out Point center){
   center=Point.Empty;if(Count<40)return 0;double best=0;
   int width=region.Bounds.Width,height=region.Bounds.Height;
   for(int y=0;y<=height-Height;y++)for(int x=0;x<=width-Width;x++){
    int actual=region.Count(x,y,Width,Height);if(actual<Count*.65||actual>Count*1.55)continue;
    int hits=0,i=0;for(;i<ink.Length;i++){
     Point p=ink[i];if(region.Bits[(y+p.Y)*width+x+p.X])hits++;
     if(i==47&&hits<30)break;
    }
    if(i<ink.Length)continue;
    double score=2.0*hits/(Count+actual);if(score>best){best=score;center=new Point(region.Bounds.X+x+Width/2,region.Bounds.Y+y+Height/2);}
   }
   return best;
  }
 }
 readonly Patch title,hint;
 public RewardPopupDetector(string root){
  string dir=Directory.Exists(Path.Combine(root,"templates"))?Path.Combine(root,"templates"):root;
  string titleFile=Path.Combine(dir,"reward-v416-title.png"),hintFile=Path.Combine(dir,"reward-v416-dismiss-label.png");
  if(File.Exists(titleFile))title=new Patch(titleFile,true);
  if(File.Exists(hintFile))hint=new Patch(hintFile,false);
 }
 public RewardPopupReading Read(Bitmap image){
  if(image==null||image.Width!=1216||image.Height!=684)return new RewardPopupReading{Detail="奖励弹窗截图尺寸不匹配，需要1216x684"};
  return FrameCache.Get<RewardPopupReading>(image,this,"reward-overlay",delegate{return ReadFrame(image);});
 }
 RewardPopupReading ReadFrame(Bitmap image){
  var r=new RewardPopupReading();if(title==null||hint==null){r.Detail="奖励弹窗双文本图样缺失";return r;}
  int[] pixels=FrameCache.Pixels(image);
  r.TitleScore=title.Find(new Region(pixels,image.Width,new Rectangle(475,220,270,100),true),out r.TitleAt);
  r.HintScore=hint.Find(new Region(pixels,image.Width,new Rectangle(480,500,260,65),false),out r.HintAt);
  bool hasTitle=r.TitleScore>=TitleThreshold,hasHint=r.HintScore>=HintThreshold;
  r.Suspected=hasTitle||hasHint;
  int dy=r.HintAt.Y-r.TitleAt.Y,dx=Math.Abs(r.HintAt.X-r.TitleAt.X);
  bool layout=hasTitle&&hasHint&&dx<=22&&dy>=245&&dy<=280;
  if(layout){
   Point blank=new Point((r.TitleAt.X+r.HintAt.X)/2+437,r.TitleAt.Y+48);
   // The observed rectangle's right edge is about title.x+365. This area is
   // another 72 px to its right, above the bottom portals/chat/items/joystick.
   if(blank.X>=990&&blank.X<=1130&&blank.Y>=290&&blank.Y<=355){r.Present=true;r.Dismiss=blank;}
  }
  r.Detail="奖励弹窗：恭喜获得="+r.TitleScore.ToString("0.00",CultureInfo.InvariantCulture)+"（阈值0.86）@"+r.TitleAt+"；点击空白区域关闭="+r.HintScore.ToString("0.00",CultureInfo.InvariantCulture)+"（阈值0.88）@"+r.HintAt+"；双锚点布局="+layout+"；"+(r.Present?"侧上方空白点="+r.Dismiss:r.Suspected?"仅疑似，拦截但不点击":"未确认奖励弹窗");
  return r;
 }
}
