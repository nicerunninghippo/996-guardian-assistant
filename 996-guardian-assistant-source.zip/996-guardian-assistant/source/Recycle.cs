﻿using System;
using System.Drawing;
using System.IO;

class RecycleView {
 public bool Bag,Page,Entry,OneKey,Icon;
 public Point BagAt,PageAt,EntryAt,OneAt,IconAt;
}
class RecycleVision {
 Mask bag,page,entry,one,icon,bagAdb,entryAdb,iconAdb,pageAdb,oneAdb;
 public RecycleVision(string root){bag=Read(root,"bag-title");page=Read(root,"recycle-title");entry=Read(root,"bag-recycle");one=Read(root,"one-key");icon=Read(root,"bag-icon");bagAdb=Optional(root,"bag-title-adb");entryAdb=Optional(root,"bag-recycle-adb");iconAdb=Optional(root,"bag-icon-adb");pageAdb=Optional(root,"recycle-title-adb");oneAdb=Optional(root,"one-key-adb");}
 Mask Optional(string root,string n){return File.Exists(Path.Combine(root,"templates",n+".png"))?Read(root,n):null;}
 double Find(Mask a,Mask alt,Mask frame,Rectangle area,out Point p){double s=a.Find(frame,area,out p);if(alt!=null){Point q;double t=alt.Find(frame,area,out q);if(t>s){p=q;s=t;}}return s;}
 Mask Read(string root,string n){using(var b=new Bitmap(Path.Combine(root,"templates",n+".png")))return new Mask(b,false,true);}
 public RecycleView Read(Bitmap b){return FrameCache.Get<RecycleView>(b,this,"recycle",delegate{return ReadFresh(b);});}
 RecycleView ReadFresh(Bitmap b){Mask f=new Mask(b,false,true);var v=new RecycleView();
  v.Page=Find(page,pageAdb,f,new Rectangle(420,45,340,90),out v.PageAt)>.78;
  v.Bag=Find(bag,bagAdb,f,new Rectangle(250,20,780,115),out v.BagAt)>.78;
  v.Icon=Find(icon,iconAdb,f,new Rectangle(1125,230,91,60),out v.IconAt)>.78;
  if(v.Page)v.OneKey=Find(one,oneAdb,f,new Rectangle(v.PageAt.X+30,v.PageAt.Y+420,170,90),out v.OneAt)>.8;
  if(v.Bag&&!v.Page)v.Entry=Find(entry,entryAdb,f,new Rectangle(v.BagAt.X-30,v.BagAt.Y+355,145,75),out v.EntryAt)>.8;
  return v;
 }
}
// A click on OneKey is never retried: its result may be irreversible and ambiguous.
class RecycleFlow {
 public int Stage,Clicks,Completed; public string Status=""; public bool Failed,JustDone;
 int stable,attempts; string previous=""; double entered,lastClick=-100; bool submitted;
 public void Begin(double now){Stage=1;Failed=false;JustDone=false;submitted=false;stable=0;attempts=0;entered=now;lastClick=-100;previous="";Status="定时回收：准备背包";}
 public void Reset(){Stage=0;stable=0;JustDone=false;Failed=false;}
 void Advance(int next,double now){Stage=next;stable=0;attempts=0;entered=now;lastClick=-100;previous="";}
 void Fail(string why){Status="回收停止："+why;Failed=true;Stage=0;}
 public Point? Step(RecycleView v,int map,double now){JustDone=false;if(Stage==0||Failed)return null;
  if(map>=0&&map!=4){Fail("已离开目标地图，请检查游戏");return null;}
  if(now-entered>20){Fail("页面验证超时；未继续点击");return null;}
  string key=map+":"+v.Bag+":"+v.Page+":"+v.Entry+":"+v.OneKey+":"+v.Icon;
  if(previous==key)stable++;else{previous=key;stable=1;}if(stable<2)return null;
  if(Stage==1){if(v.Page){Fail("开始前回收页面已打开，请关闭后重试");return null;}if(v.Bag){Advance(2,now);return null;}if(map==4&&v.Icon)return Action(v.IconAt,now,"打开背包");}
  else if(Stage==2){if(v.Page){Advance(3,now);return null;}if(v.Bag&&v.Entry)return Action(v.EntryAt,now,"打开回收页面");}
  else if(Stage==3){if(v.Page&&v.OneKey&&!submitted){submitted=true;Clicks++;Advance(4,now);Status="已点击一键回收；等待页面稳定（不重复提交）";return v.OneAt;}}
  else if(Stage==4){if(now-entered<3)return null;if(v.Page&&v.OneKey){Advance(5,now);return null;}}
  else if(Stage==5){if(!v.Page&&v.Bag){Advance(6,now);return null;}if(v.Page&&v.OneKey)return Action(new Point(v.PageAt.X+411,v.PageAt.Y+10),now,"关闭回收页面");}
  else if(Stage==6){if(!v.Page&&!v.Bag&&map==4&&v.Icon){Completed++;JustDone=true;Stage=0;Status="回收操作结束，已返回目标地图；实际所得以游戏为准";return null;}if(!v.Page&&v.Bag)return Action(new Point(v.BagAt.X+275,v.BagAt.Y-22),now,"关闭背包");}
  return null;
 }
 Point? Action(Point p,double now,string text){if(now-lastClick<5)return null;if(attempts>=3){Fail(text+"三次未验证");return null;}attempts++;lastClick=now;Status="定时回收："+text+"，等待验证";return p;}
}
