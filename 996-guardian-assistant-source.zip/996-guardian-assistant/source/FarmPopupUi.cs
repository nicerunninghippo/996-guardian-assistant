using System;
using System.Drawing;
using System.IO;

partial class Guardian {
 FarmPopupDetector farmPopupDetector;
 readonly FarmPopupFlow farmPopupFlow=new FarmPopupFlow();
 bool farmContext;
 string farmPopupLastStatus="";
 DateTime farmPopupLastLog=DateTime.MinValue;

 void ResetFarmPopup(){farmPopupFlow.Reset();farmContext=false;farmPopupLastStatus="";farmPopupLastLog=DateTime.MinValue;}

 // Never infer a real map transition from NPC colours, combat effects, or a
 // missing title. A modal can darken/cover the title without changing maps.
 int ReadStrictTitleMap(Bitmap image){
  return FrameCache.Get<int>(image,this,"strict-title-map",delegate{return ReadStrictTitleMapCore(image);});
 }
 int ReadStrictTitleMapCore(Bitmap image){
  if(ReadMinimap(image).State==MinimapState.Collapsed)return -1;
  if(ReadTownTitle(image).Town)return 0;int hellMap=ReadHellMap(image);if(hellMap>=0)return hellMap;
  string detail;
  if(TryRecognizePriorityTarget(image,out detail))return 4;
  if(priorityOcrCount==1&&priorityOcrCandidate.Length>0)return -1;
  using(Bitmap title=image.Clone(new Rectangle(1067,31,149,34).IntersectSafe(image),image.PixelFormat)){
   Mask frame=new Mask(title,false);Point p;
   foreach(Mask target in targetMaps)if(!priorityTitleBlocksLegacy&&target.Find(frame,new Rectangle(0,0,title.Width,title.Height),out p)>=.76)return 4;
  }
  return CalibrationMap(image);
 }
 void ObserveFarmTitle(int map){if(map>=0)farmContext=map==4;}

 bool IsEntryDetailVisible(Bitmap image){
  return FrameCache.Get<bool>(image,this,"entry-detail",delegate{
   if(enterMapButton==null)return false;
   Point p;return enterMapButton.Find(new Mask(image,false,true),new Rectangle(650,470,430,190).IntersectSafe(image),out p)>=.68;
  });
 }

 void InvalidateFarmPopupFrame(){
  engine.ResetObservation();engine.ResetPending();ResetHealthEvidence();autoWaiting=false;
  mengWalk.Pending=false;shenWalk.Pending=false;mzCoordReadyUntil=DateTime.MinValue;
  if(recycle.Stage!=0){
   recycle.Reset();nextRecycle=DateTime.Now.AddMinutes((double)recycleMinutes.Value);
   Log("外来弹窗打断回收，本轮不重放一键提交；关闭窗口后继续守护");
  }
 }
 void LogFarmPopup(FarmPopupAction action){
  engine.Status=action.Status;
  if(action.Tap.HasValue||action.Recovered||action.Status!=farmPopupLastStatus||(DateTime.Now-farmPopupLastLog).TotalSeconds>=10){
   Log(action.Status);farmPopupLastStatus=action.Status;farmPopupLastLog=DateTime.Now;
  }
 }

 bool CloseFarmPopup(Bitmap image){
  if(!guardRequested||!engine.Running||Native.GetAsyncKeyState(0x77)!=0){ResetFarmPopup();return false;}
  // Only BOSS may dismiss its own dialogs, including during retry cooldown.
  // Ordinary nuisance windows can still be closed while BOSS combat runs.
  var boss=ReadBoss(image);
  if(boss.TeleportPrompt||boss.ListShell||boss.SuspectedList||boss.Challenge||BossOwnsWindow&&bossStage!=BossStage.Fighting&&bossStage!=BossStage.Hold){farmPopupFlow.Reset();return false;}
  if(farmPopupDetector==null)farmPopupDetector=new FarmPopupDetector(Path.Combine(root,"templates"));
  ObserveFarmTitle(ReadStrictTitleMap(image));
  RecycleView view=recycleVision.Read(image);
  bool owned=recycle.Stage!=0&&(view.Bag||view.Page);
  // Explicitly known nuisance pages can be closed on any route. Generic
  // windows are closed only after a real farm title was seen. Map details
  // and the recycle transaction remain owned by their existing workflows.
  bool allowGeneric=farmContext&&!owned&&mapPriority.Active<0&&!closeStaleDialog&&!IsEntryDetailVisible(image);
  FarmPopupReading reading=farmPopupDetector.Read(image,allowGeneric);
  FarmPopupAction action=farmPopupFlow.See(reading,ClockSeconds(),true);
  if(!action.Handled)return false;
  InvalidateFarmPopupFrame();
  if(action.Tap.HasValue&&!Click(action.Tap.Value))action.Status="弹窗关闭点击未发出；继续重新识别";
  LogFarmPopup(action);return true;
 }

 bool VerifyFarmPopupRecovery(Bitmap image){
  if(!farmPopupFlow.Active)return false;
  int map=ReadStrictTitleMap(image);ObserveFarmTitle(map);
  FarmPopupAction action=farmPopupFlow.Verify(ClockSeconds(),guardRequested&&engine.Running,map);
  if(!action.Handled)return false;
  InvalidateFarmPopupFrame();LogFarmPopup(action);return true;
 }

 bool HandleOwnedRecyclePanel(Bitmap image){
  if(recycle.Stage==0)return false;
  RecycleView view=recycleVision.Read(image);
  if(!view.Bag&&!view.Page)return false;
  return HandleRecycle(image,ReadStrictTitleMap(image));
 }
}

