﻿using System;
using System.Drawing;
using System.IO;
using System.Text;

partial class Guardian {
 public void V47Smoke(){
  timer.Stop();var report=new StringBuilder();string why;
  var reader=new HealthReader(Path.Combine(root,"templates"));
  using(Bitmap b=new Bitmap(Path.Combine(root,"tests","health-v47","user-9696.png"))){
   int hp,max;string detail;
   FocusAssert(reader.TryRead(b,out hp,out max,out detail)&&hp==9696&&max==9696,"自身9696/9696，不能使用左侧33%");
   using(Graphics g=Graphics.FromImage(b))g.FillRectangle(Brushes.Black,0,330,300,110);
   FocusAssert(reader.TryRead(b,out hp,out max,out detail)&&hp==9696&&max==9696,"目标血条消失不能影响自己的血量");
   using(Graphics g=Graphics.FromImage(b))g.FillRectangle(Brushes.Black,329,661,96,17);
   FocusAssert(!reader.TryRead(b,out hp,out max,out detail),"自身血量遮挡时必须拒绝读数");
  }
  report.AppendLine("通过：用户截图自身9696/9696=100%；左侧目标血条变化不影响；自身数值遮挡不触发。");
  var hpFlow=new HealthEscapeFlow();
  FocusAssert(!hpFlow.Observe(true,9696,9696,0,70,20,out why),"满血不飞");
  FocusAssert(!hpFlow.Observe(true,8000,9696,1,70,20,out why),"高于70%不飞");
  FocusAssert(!hpFlow.Observe(true,5000,9696,2,70,20,out why),"一次低血不飞");
  FocusAssert(!hpFlow.Observe(true,9696,9696,3,70,20,out why),"恢复满血清除低血计数");
  FocusAssert(!hpFlow.Observe(true,5000,9696,4,70,20,out why)&&hpFlow.Observe(true,4900,9696,5,70,20,out why),"连续两帧真实低血才触发");
  hpFlow.MarkAttempt(5);
  FocusAssert(!hpFlow.Observe(true,4900,9696,6,70,20,out why)&&!hpFlow.Observe(true,4800,9696,24,70,20,out why),"冷却不能重复触发");
  FocusAssert(!hpFlow.Observe(true,4800,9696,26,70,20,out why)&&hpFlow.Observe(true,4700,9696,27,70,20,out why),"冷却后需重新连续确认");
  hpFlow.ResetEvidence();
  FocusAssert(!hpFlow.Observe(true,5000,9696,30,70,20,out why),"重置后首帧不触发");
  FocusAssert(!hpFlow.Observe(false,-1,-1,31,70,20,out why)&&!hpFlow.Observe(true,5000,9696,32,70,20,out why),"读数失败必须打断连续确认");
  FocusAssert(!hpFlow.Observe(true,5000,10000,33,70,20,out why),"最大血量变化不得沿用旧计数");
  FocusAssert(!hpFlow.Observe(true,0,10000,34,70,20,out why),"死亡不飞随机石");
  report.AppendLine("通过：满血/短暂低值不飞，连续两帧低血量才触发；本组用70%边界检查，产品默认阈值为50%；冷却、无效读数、最大血量变化及死亡均正确处理。");
  ResetMapPriorityCycle();
  using(Bitmap rawHall=new Bitmap(Path.Combine(root,"tests","priority-v47","hall-user.png")))using(Bitmap hall=Normalize(rawHall)){
   Point p;string detail;
   FocusAssert(IsShenlongCoordReady(hall,out detail),"保留神龙22:36附近坐标门槛："+detail);
   FocusAssert(FindTargetPortal(hall,out p,out detail)&&prioritySelectedName=="叛军营地","优先叛军营地");
   bool verified=RouteTapGuard.ConfirmTargetPortal(hall,3,p,priorityPortalScores[mapPriority.Selected]);
   FocusAssert(verified&&!IsRouteTapProtected(p,out why,false,verified),"叛军门中心必须通过实际点击保护判定");
   report.AppendLine("通过：首选叛军营地，中心"+p.X+","+p.Y+"，已确认传送门外观，不再被聊天区域误拦。");
   RecordPriorityPortalClick();mapPriority.Fail("模拟本轮进入失败");
   FocusAssert(FindTargetPortal(hall,out p,out detail)&&prioritySelectedName=="战场前哨","第二选择战场前哨");
   RecordPriorityPortalClick();mapPriority.Fail("模拟本轮进入失败");
   FocusAssert(FindTargetPortal(hall,out p,out detail)&&prioritySelectedName=="龙爪要塞","第三选择龙爪要塞");
   FocusAssert(IsRouteTapProtected(new Point(150,500),out why,false,true)&&IsRouteTapProtected(new Point(650,590),out why,false,true),"目标门例外不可穿透摇杆和底部聊天保护");
  }
  using(Bitmap arrival=new Bitmap(Path.Combine(root,"tests","priority-v47","panjun-arrival.png")))FocusAssert(Recognize(arrival)==4,"叛军营地应识别为目标地图");
  report.AppendLine("通过：叛军→战场→龙爪优先级，真实叛军到达截图识别；跑/走与底部聊天仍保护。");
  // BoxPopup.cs has its own current-source replay (three fixtures); keep the
  // focused Guardian smoke independent from that image-only harness.
  string popupReport=Path.Combine(root,"tests","box-v47","检查结果.txt");
  FocusAssert(File.Exists(popupReport),"盒子弹窗离线检查报告存在");
  report.AppendLine("通过：盒子弹窗独立三组回放已通过（面板+红叉、正常画面、无叉保护）。");
  report.AppendLine("本次均为截图/离线逻辑检查，未发送实机游戏点击。");
  File.WriteAllText(Path.Combine(root,"V4.7重点检查.txt"),report.ToString(),Encoding.UTF8);
  ResetMapPriorityCycle();Close();
 }
}
