using System;
using System.Drawing;

public sealed class WalkProgress {
 public bool GoalSeen,Pending;
 public Point Before,Target;
 public DateTime SentAt=DateTime.MinValue,DwellAt=DateTime.MinValue;
 public int Moves,Stalls,LastDirection=-1,SearchIndex; public Point[] VisibilityOffsets; public int VisibilityRadius;
 static readonly Point[] SearchOffsets={Point.Empty,new Point(-1,0),Point.Empty,new Point(0,1),Point.Empty,new Point(1,0),Point.Empty,new Point(0,-1)};
 public static bool AtGoal(Point current,Point goal){return current==goal;}
 public bool SearchTarget(Point current,Point goal,DateTime now,out Point target){return SearchTarget(current,goal,now,1,out target);}
 public bool SearchTarget(Point current,Point goal,DateTime now,int radius,out Point target){
  target=goal;
  if(!GoalSeen){if(!AtGoal(current,goal))return true;GoalSeen=true;DwellAt=now;}
  Point[] offsets=VisibilityOffsets??SearchOffsets;if(VisibilityRadius>0)radius=Math.Max(radius,VisibilityRadius); Point off=offsets[SearchIndex];if(Math.Abs(off.X)+Math.Abs(off.Y)>radius)off=Point.Empty;target=new Point(goal.X+off.X,goal.Y+off.Y);
  if(current!=target){DwellAt=DateTime.MinValue;return true;}
  if(DwellAt==DateTime.MinValue)DwellAt=now;
  if((now-DwellAt).TotalSeconds<4)return false;
  SearchIndex=(SearchIndex+1)%offsets.Length;DwellAt=DateTime.MinValue;
  off=offsets[SearchIndex];if(Math.Abs(off.X)+Math.Abs(off.Y)>radius)off=Point.Empty;target=new Point(goal.X+off.X,goal.Y+off.Y);return target!=current;
 }
}

partial class Guardian {
 bool guardRequested,userActionBusy;
 DateTime guardResumeAt=DateTime.MinValue,autoCalRetryAt=DateTime.MinValue;
 WalkProgress mengWalk=new WalkProgress(),shenWalk=new WalkProgress();
 int lastWalkMap=-9;
 static double ClockSeconds(){return (DateTime.UtcNow-new DateTime(2020,1,1)).TotalSeconds;}
 void RetryGuard(string reason,double seconds=2){
  if(!guardRequested)return;
  if(Native.GetAsyncKeyState(0x77)<0){StopAll("F8已停止");return;}
  engine.Recover(reason,ClockSeconds(),seconds);Log(engine.Status);
 }
 void ResumeGuardIfNeeded(){
  if(userActionBusy||!guardRequested||engine.Running||coordCalibration.Active||DateTime.Now<guardResumeAt)return;
  engine.Start();Log("守护持续运行，恢复识别和寻路");
 }
 void ObserveWalkMap(int map){
  if(map<0||map==lastWalkMap)return;
  // Keep progress through one uncertain frame; reset it only on a confirmed new map.
  if(engine.Stable!=map||engine.Count<3)return;
  lastWalkMap=map;mengWalk=new WalkProgress();shenWalk=new WalkProgress();
 }
 bool IsMengzhongCoordReady(Bitmap b,out string detail){
  int x,y;if(!ReadMengzhongCoord(b,out x,out y,out detail))return false;
  return navigationSettings.Mengzhong.IsReady(new Point(x,y),mengWalk);
 }
 bool TryMoveMengzhongByCoord(Bitmap b){return MoveByCoordinate(b,0,navigationSettings.Mengzhong.Point,mengWalk);}
 bool TryMoveShenlongByCoord(Bitmap b){return MoveByCoordinate(b,3,navigationSettings.Shenlong.Point,shenWalk);}
 bool MoveByCoordinate(Bitmap b,int map,Point goal,WalkProgress walk){
  int x,y;string detail;string name=map==0?"盟重省":map==5?"冥界":"神龙帝国";
  bool ok=map==0?ReadMengzhongCoord(b,out x,out y,out detail):ReadCoordForCalibration(b,map,out x,out y,out detail);
  if(!ok){engine.Status=name+"：坐标暂未读清，继续截图识别";Log(engine.Status+"；"+detail);return true;}
  if(!RequireCoordDirections())return true;
  Point current=new Point(x,y);DateTime now=DateTime.Now;
  if(walk.Pending){
   double elapsed=(now-walk.SentAt).TotalSeconds;
   if(elapsed<1.3)return true;
   if(current==walk.Before&&elapsed<3.5){engine.Status=name+"：等待移动反馈 当前"+x+":"+y;return true;}
   int before=Math.Abs(walk.Before.X-walk.Target.X)+Math.Abs(walk.Before.Y-walk.Target.Y);
   int after=Math.Abs(x-walk.Target.X)+Math.Abs(y-walk.Target.Y);
   TraceEvent("movement_feedback","before_x",walk.Before.X,"before_y",walk.Before.Y,"after_x",x,"after_y",y,"distance_before",before,"distance_after",after,"elapsed_seconds",elapsed,"moved",current!=walk.Before);
   walk.Stalls=after<before?0:walk.Stalls+1;walk.Pending=false;
   Log(name+"移动实测："+walk.Before.X+":"+walk.Before.Y+" → "+x+":"+y+"；距离"+before+"→"+after+(current==walk.Before?"；未移动，重新选择方向":""));
  }
  Point target;
  int radius=map==0?navigationSettings.Mengzhong.SearchRadius:map==5?navigationSettings.Mingjie.SearchRadius:navigationSettings.Shenlong.SearchRadius;
  if(!walk.SearchTarget(current,goal,now,radius,out target)){
   engine.Status=name+"：已到"+goal.X+":"+goal.Y+"附近，继续识别传送点，随后小范围换位寻找";Log(engine.Status);return false;
  }
  Point center=mzStickCenter;int direction,ms;Point to;string why;
  if(!SelectWalkingStep(current,target,walk,center,out direction,out to,out ms,out why)){
   coordDirReady=false;autoCalRetryAt=DateTime.Now;RetryGuard(name+"：现有方向无法接近坐标，将重新校准",2);return true;
  }
  TraceBeforeAction(b,name+"：当前"+x+":"+y+" 目标"+target.X+":"+target.Y+" "+why);
  TraceEvent("movement_plan","map",map,"current_x",x,"current_y",y,"target_x",target.X,"target_y",target.Y,"direction",coordDirNames[direction],"duration_ms",ms,"stalls",walk.Stalls);
  if(!Swipe(center,to,ms)){RetryGuard(name+"：移动未发出，稍后重试",2);return true;}
  walk.Before=current;walk.Target=target;walk.LastDirection=direction;walk.SentAt=DateTime.Now;walk.Pending=true;walk.Moves++;
  engine.Status=name+"：当前"+x+":"+y+"，"+(walk.GoalSeen?"传送点附近换位":"目标")+target.X+":"+target.Y+"，"+why+"（第"+walk.Moves+"步，持续寻路）";
  Log(engine.Status);
  // Same map stays confirmed. The next fresh frame verifies movement; no three-frame restart per tile.
  return true;
 }
 bool SelectWalkingStep(Point current,Point target,WalkProgress walk,Point center,out int direction,out Point to,out int ms,out string why){
  direction=-1;to=Point.Empty;ms=550;why="";
  double distance=Math.Abs(target.X-current.X)+Math.Abs(target.Y-current.Y),best=distance;
  bool blocked=walk.Stalls>=2;double[] scales=distance>6?new[]{2.0,1.0,.5}:new[]{1.0,.5,.25};
  for(int i=0;i<8;i++){
   if(coordDirDx[i]==0&&coordDirDy[i]==0)continue;
   if(blocked&&i==walk.LastDirection)continue;
   foreach(double scale in scales){
    double next=Math.Abs(target.X-current.X-coordDirDx[i]*scale)+Math.Abs(target.Y-current.Y-coordDirDy[i]*scale);
    if(next<best){best=next;direction=i;ms=(int)Math.Round(DirectionCalibration.Duration*scale);}
   }
  }
  if(direction<0&&blocked){
   // A confirmed obstacle: try one adjacent, calibrated direction, then re-read the position.
   for(int k=1;k<8;k++){
    int candidate=(walk.LastDirection+(walk.Stalls%2==0?k:8-k)+8)%8;
    if(Math.Abs(coordDirDx[candidate])+Math.Abs(coordDirDy[candidate])==0)continue;
    direction=candidate;ms=DirectionCalibration.Duration;break;
   }
  }
  if(direction<0)return false;
  Point off=coordDirOffsets[direction];to=new Point(center.X+off.X,center.Y+off.Y);
  why="方向"+coordDirNames[direction]+" "+ms+"ms"+(blocked?"，尝试绕开阻挡":"");return true;
 }
}

