﻿using System;
using System.Drawing;
using System.Windows.Forms;

partial class Guardian {
 AutoBattleVision autoBattleVision;readonly AutoBattleFlow autoBattleFlow=new AutoBattleFlow();
 readonly Label autoBattleInfo=new Label();string lastAutoBattleLog="",lastAutoBattleDetail="尚未检查";double lastAutoBattleLogAt,autoAdmissionSince=-1;
 void InitAutoBattle(Control top){autoBattleInfo.AutoSize=true;autoBattleInfo.MaximumSize=new Size(835,0);autoBattleInfo.Text="自动战斗：等待确认；右侧“挂机”=关闭，“自动”=开启";top.Controls.Add(autoBattleInfo);}
 AutoBattleReading ReadAutoBattle(Bitmap image){if(autoBattleVision==null)autoBattleVision=new AutoBattleVision(root);return autoBattleVision.Read(image);}
 void ResetAutoBattle(){autoBattleFlow.Reset();autoWaiting=false;autoTries=0;autoAdmissionSince=-1;lastAutoBattleDetail="等待新的地图与按钮证据";autoBattleInfo.Text="自动战斗：等待确认；右侧“挂机”=关闭，“自动”=开启";}
 void SuspendAutoBattle(){autoBattleFlow.Suspend(traceClock.Elapsed.TotalSeconds);autoWaiting=autoBattleFlow.Waiting;autoBattleInfo.Text="自动战斗：等待刷怪地图确认";}
 // Only new background work yields. Already-owned windows retain ownership.
 // Unknown button evidence holds admission for at most12s; never monopolize
 // the guard when a layout is unreadable. Each fresh frame still gets checked.
 bool AutoBattleAllowsMaintenance(Bitmap image){
  double now=traceClock.Elapsed.TotalSeconds;
  if(autoBattleFlow.Waiting)return false;
  if(autoBattleFlow.CooldownUntil>now)return true;
  if(ReadStrictTitleMap(image)!=4){autoAdmissionSince=-1;return true;}
  var reading=ReadAutoBattle(image);
  if(reading.State==AutoBattleState.On){autoAdmissionSince=-1;return true;}
  if(reading.State==AutoBattleState.Off){autoAdmissionSince=-1;return false;}
  if(autoAdmissionSince<0)autoAdmissionSince=now;
  return now-autoAdmissionSince>=12;
 }
 void CheckAuto(Bitmap image,bool verifiedBoss=false){
  double now=traceClock.Elapsed.TotalSeconds;var reading=ReadAutoBattle(image);lastAutoBattleDetail=reading.Detail;
  bool eligible=guardRequested&&engine.Running&&(verifiedBoss||engine.Stable==4&&engine.Count>=3)&&engine.Pending<0&&maintenanceTask==null&&recycle.Stage==0&&!coordCalibration.Active&&Native.GetAsyncKeyState(0x77)>=0;
  // Tick invokes this only after reward/popup/panel recovery has yielded a clean
  // frame. The same checks also make direct/offline invocation safe.
  if(IsEntryDetailVisible(image))eligible=false;
  var action=autoBattleFlow.Step(reading,now,traceFrame,eligible);autoWaiting=action.Waiting;autoTries=autoBattleFlow.Attempts;
  engine.Status=action.Status;autoBattleInfo.Text="自动战斗："+(reading.State==AutoBattleState.On?"自动（开启）":reading.State==AutoBattleState.Off?"挂机（关闭）":"待确认")+(autoWaiting?"；等待开启反馈":"");
  if(action.Tap.HasValue){
   TraceBeforeAction(image,action.Status+"；"+reading.Detail);
   bool sent=Click(action.Tap.Value);TraceEvent("auto_battle_input","attempt",autoTries,"sent",sent,"button",action.Tap.Value,"evidence",reading.Detail);
   if(!sent)engine.Status="自动开启输入结果未确认，仍等待新截图，避免重复切换";
  }
  if(action.Diagnostic){SaveDiagnostic(image,4,"auto-battle-unconfirmed");TraceEvent("auto_battle_unconfirmed","attempts",autoTries,"cooldown_until",autoBattleFlow.CooldownUntil,"evidence",reading.Detail);}
  if(engine.Status!=lastAutoBattleLog||now-lastAutoBattleLogAt>=30||action.Tap.HasValue){
   Log(engine.Status+"；"+reading.Detail);TraceEvent("auto_battle_state","state",reading.State.ToString(),"confirmed_on",action.ConfirmedOn,"waiting",autoWaiting,"attempts",autoTries,"off_score",reading.OffScore,"on_score",reading.OnScore);
   lastAutoBattleLog=engine.Status;lastAutoBattleLogAt=now;
  }
 }
}
