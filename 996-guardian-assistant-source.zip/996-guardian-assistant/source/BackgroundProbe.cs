﻿using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
class BackgroundProbe {
 [DllImport("user32.dll")] static extern bool GetCursorPos(out Point p);
 static Bitmap Frame(BackgroundDevice d){using(var raw=d.Capture()){var b=new Bitmap(1216,684);using(var g=Graphics.FromImage(b))g.DrawImage(raw,new Rectangle(0,0,1216,684));return b;}}
 public static void Run(string root,bool tap){
  var d=new BackgroundDevice();string console=BackgroundDevice.Discover();string[] lines=BackgroundDevice.Text(console,"list2").Split('\n');IntPtr h=IntPtr.Zero;
  // Probe only when exactly one instance is running; never choose an arbitrary instance.
  int running=0;foreach(string line in lines){string[] a=line.Trim().Split(',');if(a.Length>4&&a[4]=="1"){h=new IntPtr(long.Parse(a[2]));running++;}}
  if(running!=1)throw new Exception("实机探测要求只有一个运行中的雷电实例");d.Connect(h,console);
  Point before,after;GetCursorPos(out before);IntPtr foreground=Native.GetForegroundWindow();var vision=new RecycleVision(root);string report="后台连接："+d.Serial+"\r\n雷电在前台："+(foreground==h)+"\r\n";
  using(var b=Frame(d)){b.Save(Path.Combine(root,"后台截图测试.png"));var v=vision.Read(b);double mapScore=0,autoScore=0;try{using(var title=b.Clone(new Rectangle(1067,31,149,34),b.PixelFormat)){var frame=new Mask(title,false);var tplPath=File.Exists(Path.Combine(GuardianStorage.Resolve(root),"map4-adb.png"))?Path.Combine(GuardianStorage.Resolve(root),"map4-adb.png"):Path.Combine(root,"templates","map4-adb.png");using(var tplBmp=new Bitmap(tplPath)){Point mp;mapScore=new Mask(tplBmp,false).Find(frame,new Rectangle(0,0,title.Width,title.Height),out mp);}}}catch{}try{var autoPath=Path.Combine(root,"templates","auto-fighting-adb.png");if(File.Exists(autoPath)){using(var autoBmp=new Bitmap(autoPath)){Point ap;autoScore=new Mask(autoBmp,false,true).Find(new Mask(b,false,true),new Rectangle(560,430,360,115),out ap);}}}catch{}report+="后台截图："+d.Width+"×"+d.Height+"；背包="+v.Bag+"；回收入口="+v.Entry+"；战场标题分="+mapScore.ToString("0.00")+"；自动战斗分="+autoScore.ToString("0.00")+"\r\n";
   if(tap){if(v.Page&&v.OneKey){d.Tap(new Point(v.PageAt.X+411,v.PageAt.Y+10));Thread.Sleep(600);using(var clear=Frame(d))v=vision.Read(clear);report+="已关闭上一轮测试留下的回收页\r\n";}if(!v.Bag||!v.Entry||v.Page)throw new Exception("当前不是已识别的背包页面，不执行测试点击");
    d.Tap(v.EntryAt);bool appeared=false;Point title=Point.Empty;
    for(int i=0;i<8;i++){Thread.Sleep(500);using(var next=Frame(d)){var r=vision.Read(next);if(r.Page&&r.OneKey){appeared=true;title=r.PageAt;next.Save(Path.Combine(root,"后台回收页面测试.png"));break;}}}
    if(!appeared)throw new Exception("后台打开回收页面未验证；停止测试");report+="后台点击打开回收页：通过（未提交一键回收）\r\n";
    d.Tap(new Point(title.X+411,title.Y+10));bool closed=false;
    for(int i=0;i<8;i++){Thread.Sleep(500);using(var next=Frame(d)){var r=vision.Read(next);if(!r.Page&&r.Bag){closed=true;break;}}}
    if(!closed)throw new Exception("后台关闭回收页未验证");report+="后台点击关闭回收页：通过\r\n";
   }
  }
  GetCursorPos(out after);report+="测试期间鼠标位置未变："+(before==after)+"\r\n测试期间前台窗口未变："+(foreground==Native.GetForegroundWindow())+"\r\n";
  File.WriteAllText(Path.Combine(root,"后台实机测试.txt"),report);
 }
}



