﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;

public sealed class BagItemObservation {
 public string Kind="",Variant="";public int Slot,Count=-1;public Point Center;public double Score;
}
public sealed class BagUseObservation {
 public bool Bag,TooltipVisible,HudClear;public Point Title;public Point? Open,Close,Use;public string TooltipKind="",Detail="";
 public readonly List<BagItemObservation> Items=new List<BagItemObservation>();
 public int Total(string kind){int total=0;foreach(BagItemObservation i in Items)if(i.Kind==kind){if(i.Count<0)return -1;total+=i.Count;}return total;}
 public int Stacks(string kind){int n=0;foreach(BagItemObservation i in Items)if(i.Kind==kind)n++;return n;}
}

// The six graphic variants below are the marked, authorized four item kinds.
// Matching a general orb, scroll or red color never grants permission to use it.
public sealed class BagUseVision {
 sealed class Pix {
  public int W,H;public int[] D;
  public Pix(Bitmap b){W=b.Width;H=b.Height;D=FrameCache.Pixels(b);}
  public int At(int x,int y){return x<0||y<0||x>=W||y>=H?0:D[y*W+x];}
 }
 static int R(int p){return(p>>16)&255;}static int G(int p){return(p>>8)&255;}static int B(int p){return p&255;}
 static bool White(int p){return R(p)>185&&G(p)>185&&B(p)>185&&Math.Abs(R(p)-G(p))<30&&Math.Abs(G(p)-B(p))<30;}
 static bool Gold(int p){return R(p)>180&&G(p)>95&&B(p)<150;}
 sealed class Patch {
  public int W,H,Mode;public double Scale;public string Kind,Variant;public List<Point> P=new List<Point>();public List<int> C=new List<int>();
  public Patch(Bitmap image,double scale,int mode,string kind,string variant){Scale=scale;Mode=mode;Kind=kind;Variant=variant;W=(int)Math.Round(image.Width*scale);H=(int)Math.Round(image.Height*scale);using(Bitmap b=new Bitmap(W,H)){using(Graphics g=Graphics.FromImage(b))g.DrawImage(image,0,0,W,H);Pix pix=new Pix(b);for(int y=1;y<H-1;y+=2)for(int x=1;x<W-1;x+=2){int v=pix.At(x,y);bool on=mode==1?Gold(v):mode==2?White(v):Math.Max(R(v),Math.Max(G(v),B(v)))>90;if(on){P.Add(new Point(x,y));C.Add(v);}}}}
  public double Score(Pix f,int x,int y){if(P.Count<12||x<0||y<0||x+W>f.W||y+H>f.H)return 0;double sum=0;int hit=0;for(int i=0;i<P.Count;i++){int a=C[i],b=f.At(x+P[i].X,y+P[i].Y);if(Mode==1){if(Gold(b))hit++;}else if(Mode==2){if(White(b))hit++;}else{double err=(Math.Abs(R(a)-R(b))+Math.Abs(G(a)-G(b))+Math.Abs(B(a)-B(b)))/765.0;sum+=Math.Max(0,1-err*2.6);}if(i==11&&((Mode>0&&hit<5)||(Mode==0&&sum<5)))return 0;}
   if(Mode==0)return sum/P.Count;int actual=0;for(int yy=1;yy<H-1;yy+=2)for(int xx=1;xx<W-1;xx+=2){int b=f.At(x+xx,y+yy);if(Mode==1?Gold(b):White(b))actual++;}return 2.0*hit/(P.Count+actual);}
  public double Find(Pix f,Rectangle box,out Point p){p=Point.Empty;double best=0;box=Rectangle.Intersect(box,new Rectangle(0,0,f.W,f.H));for(int y=box.Top;y<=box.Bottom-H;y++)for(int x=box.Left;x<=box.Right-W;x++){double s=Score(f,x,y);if(s>best){best=s;p=new Point(x+W/2,y+H/2);}}return best;}
 }
 readonly List<Patch> titles=new List<Patch>(),icons=new List<Patch>(),tooltipIcons=new List<Patch>(),use=new List<Patch>(),close=new List<Patch>(),open=new List<Patch>();
 readonly Dictionary<char,bool[]> digits=new Dictionary<char,bool[]>();
 readonly RecycleVision hudBag;
 readonly WelfareDetector hud;
 public BagUseVision(string root){
  hudBag=new RecycleVision(root);hud=new WelfareDetector(root);
  string dir=Path.Combine(root,"templates");double[] scales={1,.945};
  Add(titles,dir,"items-v413-title.png",scales,1,"","");Add(close,dir,"items-v413-close.png",scales,0,"","");Add(use,dir,"items-v413-use.png",scales,0,"","");
  Add(open,dir,"bag-icon-adb.png",new[]{1.0},1,"","");Add(open,dir,"bag-icon.png",new[]{1.0},1,"","");
  string[] variants={"orb-red","orb-yellow","orb-purple","official","red-envelope","cumulative"};string[] kinds={"聚灵珠","聚灵珠","聚灵珠","官职经验","红包","累充"};
  for(int i=0;i<variants.Length;i++)Add(icons,dir,"items-v413-"+variants[i]+".png",scales,0,kinds[i],variants[i]);
  Add(icons,dir,"items-v413-official-alt.png",scales,0,"官职经验","official-alt");
  tooltipIcons.AddRange(icons);Add(tooltipIcons,dir,"items-v413-tooltip-cumulative.png",scales,0,"累充","tooltip-cumulative");
  for(char d='0';d<='9';d++){string p=Path.Combine(dir,"items-v413-digit-"+d+".png");if(File.Exists(p))using(Bitmap b=new Bitmap(p)){Pix px=new Pix(b);digits[d]=Glyph(px,new Rectangle(0,0,b.Width,b.Height));}}
 }
 static void Add(List<Patch> list,string dir,string file,double[] scales,int mode,string kind,string variant){string path=Path.Combine(dir,file);if(!File.Exists(path))return;using(Bitmap b=new Bitmap(path))foreach(double s in scales)list.Add(new Patch(b,s,mode,kind,variant));}
 static bool[] Glyph(Pix pix,Rectangle box){int l=box.Right,t=box.Bottom,r=-1,b=-1;for(int y=box.Top;y<box.Bottom;y++)for(int x=box.Left;x<box.Right;x++)if(White(pix.At(x,y))){l=Math.Min(l,x);r=Math.Max(r,x);t=Math.Min(t,y);b=Math.Max(b,y);}if(r<l||b-t<5)return null;bool[] result=new bool[126];for(int y=0;y<14;y++)for(int x=0;x<9;x++)result[y*9+x]=White(pix.At(l+x*(r-l+1)/9,t+y*(b-t+1)/14));return result;}
 int Number(Pix f,Rectangle box){List<Rectangle> groups=new List<Rectangle>();int start=-1;for(int x=box.Left;x<=box.Right;x++){bool any=false;if(x<box.Right)for(int y=box.Top;y<box.Bottom;y++)if(White(f.At(x,y))){any=true;break;}if(any&&start<0)start=x;if(!any&&start>=0){if(x-start>=3)groups.Add(new Rectangle(start,box.Top,x-start,box.Height));start=-1;}}if(groups.Count==0)return 1;string text="";foreach(Rectangle group in groups){bool[] g=Glyph(f,group);if(g==null)continue;double best=1,second=1;char found='?';foreach(KeyValuePair<char,bool[]> d in digits){if(d.Value==null)continue;int errors=0;for(int i=0;i<g.Length;i++)if(g[i]!=d.Value[i])errors++;double e=(double)errors/g.Length;if(e<best){second=best;best=e;found=d.Key;}else second=Math.Min(second,e);}if(best>.21||second-best<.02)return -1;text+=found;}int value;return text.Length>0&&int.TryParse(text,out value)?value:-1;}
 public BagUseObservation Read(Bitmap image){BagUseObservation v=new BagUseObservation();if(image==null)return v;Pix f=new Pix(image);Patch anchor=null;double best=0;Point p;
  foreach(Patch t in titles){double score=t.Find(f,new Rectangle(180,0,480,155),out p);if(score>best){best=score;v.Title=p;anchor=t;}}
  v.Bag=best>=.78;v.Detail="背包标题="+best.ToString("0.00");
  if(!v.Bag){
   var clear=hud.Read(image,0,0);v.HudClear=clear.MainHud&&!clear.Blocked&&!clear.Panel;
   if(v.HudClear){var known=hudBag.Read(image);if(known.Icon&&!known.Bag&&!known.Page){v.Open=known.IconAt;v.Detail+="；主画面及原生背包按钮同时确认 @"+known.IconAt;}}
   return v;
  }
  double scale=anchor.Scale;int step=(int)Math.Round(71*scale);int firstX=v.Title.X-(int)Math.Round(246*scale),firstY=v.Title.Y+(int)Math.Round(53*scale);
  foreach(Patch c in close){if(Math.Abs(c.Scale-scale)>.025)continue;if(c.Find(f,new Rectangle(v.Title.X+(int)(266*scale),Math.Max(0,v.Title.Y-(int)(48*scale)),(int)(64*scale),(int)(51*scale)),out p)>=.88){v.Close=p;break;}}
  // A use control alone is not enough. A matching authorized icon must also
  // occur inside the tooltip body below/left of this button, outside the grid.
  double useScore=0;foreach(Patch u in use){double s=u.Find(f,new Rectangle(Math.Max(0,firstX+4*step),110,Math.Max(0,f.W-firstX-4*step),Math.Min(430,f.H-110)),out p);if(s>=.85&&s>useScore){useScore=s;v.Use=p;}}
  for(int row=0;row<5;row++)for(int col=0;col<8;col++){
   Point center=new Point(firstX+col*step,firstY+row*step);double win=0,other=0;Patch chosen=null;
   foreach(Patch item in icons){if(Math.Abs(item.Scale-scale)>.025)continue;Point q;double s=item.Find(f,new Rectangle(center.X-step/2+7,center.Y-step/2+7,step-11,step-12),out q);if(s>win){if(chosen!=null&&chosen.Kind!=item.Kind)other=win;win=s;chosen=item;}else if(chosen!=null&&chosen.Kind!=item.Kind)other=Math.Max(other,s);}
   if(chosen==null||win<.90||win-other<.05)continue;
   // Tooltips can cover later grid cells; do not turn tooltip artwork into
   // an inventory slot. Its item image is below-left of the use button.
   if(v.Use.HasValue&&center.X>v.Use.Value.X-340&&center.X<v.Use.Value.X+45&&center.Y>v.Use.Value.Y-15&&center.Y<v.Use.Value.Y+240)continue;
   BagItemObservation o=new BagItemObservation();o.Slot=row*8+col;o.Kind=chosen.Kind;o.Variant=chosen.Variant;o.Score=win;o.Center=center;
   o.Count=Number(f,new Rectangle(center.X-step/2+12,center.Y+step/2-21,step-16,19));v.Items.Add(o);
  }
  v.TooltipVisible=v.Use.HasValue;v.Detail+="；使用按钮="+useScore.ToString("0.00");
  if(v.Use.HasValue){Point button=v.Use.Value;double iconScore=0;foreach(Patch item in tooltipIcons){Point q;double s=item.Find(f,new Rectangle(Math.Max(0,button.X-315),button.Y+35,100,135),out q);if(s>=.87&&s>iconScore){iconScore=s;v.TooltipKind=item.Kind;}}v.Detail+="；说明图标="+iconScore.ToString("0.00");if(v.TooltipKind.Length==0)v.Use=null;}
  return v;
 }
}

public sealed class BagUseTask : IMaintenanceTask {
 public string Name{get{return "背包指定道具";}}public bool Active{get;private set;}public bool UseAll=true;public bool HasMore{get;private set;}
 public int VerifiedUses{get;private set;}public int MaxUses=20;
 readonly BagUseVision vision;readonly HashSet<string> finished=new HashSet<string>(),blocked=new HashSet<string>();
 int stage,taps,attempts,stable,baselineTotal,baselineStacks,progressTotal=-1,progressStacks=-1;double started,entered,last=-1,next;bool dismissSent,closingSuccess,hadFailure;string endReason="",candidateKey="";BagItemObservation selected;
 public BagUseTask(string root){vision=new BagUseVision(root);}
 public void Reset(){Active=false;HasMore=false;hadFailure=false;stage=taps=attempts=stable=0;last=-1;selected=null;finished.Clear();blocked.Clear();}
 public void Begin(double now){Reset();Active=true;started=entered=now;VerifiedUses=0;next=now;}
 MaintenanceDecision Say(string status){return new MaintenanceDecision{Status=Name+"："+status};}
 MaintenanceDecision Tap(Point point,double now,string status){taps++;next=now+1.5;return new MaintenanceDecision{Tap=point,Status=Name+"："+status};}
 void Advance(int value,double now){stage=value;entered=now;stable=attempts=0;progressTotal=progressStacks=-1;dismissSent=false;}
 void Finish(double now,bool success,string reason){closingSuccess=success;endReason=reason;Advance(4,now);}
 public MaintenanceDecision Step(Bitmap frame,double now){if(!Active)return new MaintenanceDecision{Done=true,Success=true,Status=Name+"：未运行"};if(now<=last)return Say("等待新截图");last=now;BagUseObservation v=vision.Read(frame);return StepObserved(v,now);}
 // Pure observation entry point for focused replay tests; it never sends input.
 public MaintenanceDecision StepObserved(BagUseObservation v,double now){if(!Active)return new MaintenanceDecision{Done=true,Success=true};
  // Reserve 12 seconds and three actions for a verified bag close.
  if(stage!=4&&(now-started>=165||taps>=57)){HasMore=!hadFailure&&VerifiedUses>0&&v.Items.Count>0;Finish(now,!hadFailure&&VerifiedUses>0,"本批到达时间/动作上限，已验证使用"+VerifiedUses+"次，剩余留待下一批");}
  if(now<next)return Say("等待操作后的新截图");
  if(stage==0){if(v.Bag){Advance(1,now);return Say("已确认背包，扫描四类白名单道具");}if(now-entered>12||attempts>=3){Active=false;return new MaintenanceDecision{Done=true,Success=false,Status=Name+"：背包未验证打开，本轮结束"};}if(v.Open.HasValue&&now-entered>=attempts*3){attempts++;return Tap(v.Open.Value,now,"打开已识别的背包按钮");}return Say("等待背包按钮清晰");}
  if(stage==4){
   if(!v.Bag&&v.HudClear){if(++stable>=2){Active=false;return new MaintenanceDecision{Done=true,Success=closingSuccess,Status=Name+"："+endReason+"；两帧主画面确认背包已关闭"};}}else stable=0;
   if(now-entered>12||attempts>=3){Active=false;return new MaintenanceDecision{Done=true,Success=false,Status=Name+"："+endReason+"；背包关闭未确认，交回守护恢复"};}
   if(v.Close.HasValue&&now-entered>=attempts*3){attempts++;return Tap(v.Close.Value,now,"关闭本任务背包，等待验证");}return Say("等待背包关闭及主画面恢复证据");
  }
  if(!v.Bag){Finish(now,false,"背包意外消失，停止使用");return Say("背包意外消失");}
  if(stage==1){if(v.TooltipVisible||v.Use.HasValue){if(!dismissSent){dismissSent=true;return Tap(v.Title,now,"收起上一道具说明后重新扫描");}if(now-entered>12){Finish(now,false,"道具说明未收起");}return Say("等待道具说明收起");}
   selected=null;foreach(BagItemObservation item in v.Items){string key=item.Kind+":"+item.Slot+":"+item.Count;if(!finished.Contains(item.Kind)&&!blocked.Contains(key)){selected=item;candidateKey=key;break;}}
   if(selected==null){Finish(now,!hadFailure,(VerifiedUses>0?"本批已验证使用"+VerifiedUses+"次":"未发现可继续使用的白名单道具")+(hadFailure?"；部分结果未验证，本批跳过":""));return Say("本批扫描完成");}
   if(VerifiedUses>=MaxUses){HasMore=!hadFailure&&VerifiedUses>0;Finish(now,!hadFailure,"本批已验证使用"+VerifiedUses+"次，剩余延后处理");return Say("本批使用上限");}
   baselineTotal=v.Total(selected.Kind);baselineStacks=v.Stacks(selected.Kind);Advance(2,now);return Tap(selected.Center,now,"选中"+selected.Kind+"（格"+selected.Slot+"，数量"+selected.Count+"），等待同款说明和使用按钮");
  }
  if(stage==2){if(v.Use.HasValue&&v.TooltipKind==selected.Kind){Advance(3,now);if(!UseAll)finished.Add(selected.Kind);return Tap(v.Use.Value,now,"已核对"+selected.Kind+"说明图标，点击使用；等待数量减少验证");}if(now-entered>12){hadFailure=true;blocked.Add(candidateKey);Advance(1,now);return Say(selected.Kind+"说明或使用按钮未核对，本轮跳过避免盲点");}return Say("等待"+selected.Kind+"说明与使用按钮同时吻合");}
  if(stage==3){if(v.TooltipVisible||v.Use.HasValue){if(!dismissSent&&now-entered>2){dismissSent=true;return Tap(v.Title,now,"使用已提交一次，收起说明核对背包数量");}if(now-entered>12){blocked.Add(candidateKey);Finish(now,false,"使用结果被说明遮挡，未重复使用");}return Say("等待已提交使用的结果");}
   int total=v.Total(selected.Kind),stacks=v.Stacks(selected.Kind);int decrease=baselineTotal-total;
   bool progress=baselineTotal>=0&&total>=0&&selected.Count>0&&decrease>0&&decrease<=selected.Count&&stacks==baselineStacks;
   // If a stack disappeared, require no same-kind replacement elsewhere; this
   // handles full-stack consumption without treating a slot shift as success.
   if(!progress&&baselineTotal>=0&&selected.Count>0&&stacks==baselineStacks-1&&total==baselineTotal-selected.Count)progress=true;
   if(progress){if(total==progressTotal&&stacks==progressStacks)stable++;else{stable=1;progressTotal=total;progressStacks=stacks;}if(stable>=2){VerifiedUses++;Advance(1,now);return Say(selected.Kind+"使用已验证：总数量"+baselineTotal+"→"+total+"；重新扫描位置");}if(now-entered<=12)return Say("数量变化待第二张新截图一致确认");}
   else{stable=0;progressTotal=progressStacks=-1;}
   if(now-entered>12){hadFailure=true;blocked.Add(candidateKey);finished.Add(selected.Kind);Advance(1,now);return Say(selected.Kind+"使用后未确认数量减少，本轮不再重复提交");}return Say("使用已提交一次，等待数量减少；不重复点击使用");
  }
  return Say("等待下一帧");
 }
}
