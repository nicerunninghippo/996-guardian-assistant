﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;

public sealed class UpgradeMapReading {
 public bool Present;
 public string Name="",Requirements="unknown",Detail="";
 public double TitleScore,RunnerUpScore;
 public Point? Enter,Close;
}

// All coordinates refer to the existing 1216x684 GDI-normalized capture.
// Every name template contains all four characters. A shared 叛军 prefix is
// insufficient: each quarter of the complete glyph must match independently.
// This class never sends input and provides no unobserved arrival template.
public sealed class UpgradeMapVision {
 enum Ink { Gold,Green,Condition }
 static readonly string[] Names={"石原森林","叛军基地","叛军营地","战场前哨","龙爪要塞","鬼门关"};
 readonly List<Patch>[] titles=new List<Patch>[6],portals=new List<Patch>[6];
 readonly List<Patch> levels=new List<Patch>(),equipment=new List<Patch>(),ghostLevels=new List<Patch>(),ghostEquipment=new List<Patch>();
 readonly Patch heading;
 readonly List<Patch> enter=new List<Patch>(),close=new List<Patch>();
 static bool Green(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return g>100&&g>r*1.45&&g>b*1.30;}
 static bool Red(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return r>130&&r>g*1.8&&r>b*1.65;}
 static bool On(int p,Ink kind){
  if(kind==Ink.Green)return Green(p);if(kind==Ink.Condition)return Green(p)||Red(p);
  int r=(p>>16)&255,g=(p>>8)&255,b=p&255;
  return r>125&&g>110&&r>=g*.90&&g>=b*.95;
 }
 sealed class Region {
  internal readonly Rectangle Area;internal readonly bool[] Bits;readonly int[] sums;readonly int stride;
  internal Region(int[] pixels,int width,Rectangle area,Ink kind){
   Area=area;Bits=new bool[area.Width*area.Height];stride=area.Width+1;sums=new int[stride*(area.Height+1)];
   for(int y=0;y<area.Height;y++){int row=0;for(int x=0;x<area.Width;x++){
    bool on=On(pixels[(area.Y+y)*width+area.X+x],kind);Bits[y*area.Width+x]=on;if(on)row++;
    sums[(y+1)*stride+x+1]=sums[y*stride+x+1]+row;
   }}
  }
  internal int Count(int x,int y,int w,int h){return sums[(y+h)*stride+x+w]-sums[y*stride+x+w]-sums[(y+h)*stride+x]+sums[y*stride+x];}
 }
 sealed class Patch {
  internal readonly int W,H,Count;readonly Point[] ink;readonly int[] portions=new int[4];
  internal Patch(string file,Ink kind){
   using(Bitmap b=new Bitmap(file)){
    int[] pixels=FrameCache.Pixels(b);int left=b.Width,top=b.Height,right=-1,bottom=-1;
    for(int y=0;y<b.Height;y++)for(int x=0;x<b.Width;x++)if(On(pixels[y*b.Width+x],kind)){left=Math.Min(left,x);top=Math.Min(top,y);right=Math.Max(right,x);bottom=Math.Max(bottom,y);}
    W=Math.Max(0,right-left+1);H=Math.Max(0,bottom-top+1);var points=new List<Point>();
    for(int y=top;y<=bottom;y++)for(int x=left;x<=right;x++)if(On(pixels[y*b.Width+x],kind)){Point p=new Point(x-left,y-top);points.Add(p);portions[Math.Min(3,p.X*4/W)]++;}
    var ordered=new List<Point>();for(int k=0;k<23;k++)for(int i=k;i<points.Count;i+=23)ordered.Add(points[i]);
    ink=ordered.ToArray();Count=ink.Length;
   }
  }
  internal double Find(Region frame,out Point center,double minPortion,bool distinctSuffix=false){
   center=Point.Empty;if(Count<20||W==0||H==0)return 0;double best=0;
   int width=frame.Area.Width,height=frame.Area.Height;
   for(int y=0;y<=height-H;y++)for(int x=0;x<=width-W;x++){
    int actual=frame.Count(x,y,W,H);if(actual<Count*.65||actual>Count*1.55)continue;
    int hit=0,n=0;int a=0,b=0,c=0,d=0;
    for(;n<ink.Length;n++){
     Point p=ink[n];if(frame.Bits[(y+p.Y)*width+x+p.X]){hit++;int q=Math.Min(3,p.X*4/W);if(q==0)a++;else if(q==1)b++;else if(q==2)c++;else d++;}
     if(n==47&&hit<27)break;
    }
    if(n<ink.Length||a<portions[0]*minPortion||b<portions[1]*minPortion||c<portions[2]*minPortion||d<portions[3]*minPortion)continue;
    if(distinctSuffix){
     // 基/营 is the distinguishing character. Matching the shared 叛军*地
     // prefix/suffix is never enough, even if the overall score is high.
     int from=W*2/4,to=W*3/4,actualSuffix=0;
     for(int yy=0;yy<H;yy++)for(int xx=from;xx<to;xx++)if(frame.Bits[(y+yy)*width+x+xx])actualSuffix++;
     if(portions[2]<5||2.0*c/(portions[2]+actualSuffix)<.86)continue;
    }
    double score=2.0*hit/(Count+actual);if(score>best){best=score;center=new Point(frame.Area.X+x+W/2,frame.Area.Y+y+H/2);}
   }
   return best;
  }
 }
 public UpgradeMapVision(string root){
  string dir=Directory.Exists(Path.Combine(root,"templates"))?Path.Combine(root,"templates"):root;
  string[] titleFiles={"upgrade-title-forest.png","upgrade-title-base.png","dialog-panjun-real-v47.png","dialog-zhanqian-real-v47.png","dialog-longzhao-real-v47.png","upgrade-title-ghost.png"};
  string[] portalFiles={"upgrade-portal-forest.png","upgrade-portal-base.png","upgrade-portal-camp.png","upgrade-portal-outpost.png","upgrade-portal-fortress.png","hell-portal-label.png"};
  for(int i=0;i<Names.Length;i++){
   titles[i]=new List<Patch>();portals[i]=new List<Patch>();Add(titles[i],Load(dir,titleFiles[i],Ink.Gold));Add(portals[i],Load(dir,portalFiles[i],Ink.Green));
  }
  Add(titles[3],Load(dir,"upgrade-title-outpost.png",Ink.Gold));
  Add(portals[1],Load(dir,"upgrade-portal-base-alt.png",Ink.Green));
  Add(portals[0],Load(dir,"upgrade-portal-forest-v41912.png",Ink.Green));Add(portals[1],Load(dir,"upgrade-portal-base-v41912.png",Ink.Green));Add(portals[2],Load(dir,"upgrade-portal-camp-v41912.png",Ink.Green));
  Add(portals[3],Load(dir,"shenlong-zhanqian-v47.png",Ink.Green));
  Add(portals[3],Load(dir,"shenlong-zhanqian-user-v47.png",Ink.Green));
  Add(portals[4],Load(dir,"shenlong-longzhao-v47.png",Ink.Green));
  Add(portals[4],Load(dir,"shenlong-longzhao-user-v47.png",Ink.Green));
  heading=Load(dir,"upgrade-dialog-heading.png",Ink.Gold);Add(equipment,Load(dir,"upgrade-equipment.png",Ink.Condition));Add(equipment,Load(dir,"upgrade-equipment-base.png",Ink.Condition));
  Add(enter,Load(dir,"upgrade-enter.png",Ink.Gold));Add(enter,Load(dir,"upgrade-enter-native.png",Ink.Gold));
  Add(close,Load(dir,"upgrade-close.png",Ink.Gold));Add(close,Load(dir,"upgrade-close-native.png",Ink.Gold));
  Add(levels,Load(dir,"upgrade-level-78.png",Ink.Condition));Add(levels,Load(dir,"upgrade-level-79.png",Ink.Condition));Add(ghostLevels,Load(dir,"upgrade-level-80.png",Ink.Condition));Add(ghostEquipment,Load(dir,"upgrade-equipment-500.png",Ink.Condition));
 }
 static void Add(List<Patch> list,Patch patch){if(patch!=null)list.Add(patch);}
 static Patch Load(string dir,string name,Ink kind){string path=Path.Combine(dir,name);return File.Exists(path)?new Patch(path,kind):null;}
 static bool Valid(Bitmap image){return image!=null&&image.Width==1216&&image.Height==684;}
 static Rectangle Box(int x,int y,int w,int h){return Rectangle.Intersect(new Rectangle(x,y,w,h),new Rectangle(0,0,1216,684));}
 Region ReadRegion(Bitmap image,Rectangle area,Ink kind,string key){return FrameCache.Get<Region>(image,this,key,delegate{return new Region(FrameCache.Pixels(image),1216,area,kind);});}
 static double Find(List<Patch> patches,Region region,out Point point,double portions,bool suffix=false){double best=0;point=Point.Empty;foreach(Patch patch in patches){Point p;double s=patch.Find(region,out p,portions,suffix);if(s>best){best=s;point=p;}}return best;}

 public bool FindPortal(Bitmap image,string name,out Point point,out string detail){double score;return FindPortal(image,name,out point,out detail,out score);}
 public bool FindPortal(Bitmap image,string name,out Point point,out string detail,out double score){score=0;
  point=Point.Empty;detail="入口未确认";if(!Valid(image)){detail="入口识别需要1216x684规范帧";return false;}
  int index=Array.IndexOf(Names,name);if(index<0){detail="不支持的完整地图名";return false;}
  Region region=ReadRegion(image,new Rectangle(80,240,900,340),Ink.Green,"upgrade-portals");Point label;
  score=Find(portals[index],region,out label,.65,index==1||index==2);
  detail=name+"完整入口名="+score.ToString("0.00")+"（阈值0.76，每字至少65%）";
  if(score<.76)return false;
  // Compare names at this same door. Different valid doors may coexist in
  // the hall; comparing their global scores would wrongly reject them all.
  double other=0;Region local=new Region(FrameCache.Pixels(image),1216,Box(label.X-42,label.Y-16,84,32),Ink.Green);
  for(int i=0;i<Names.Length;i++)if(i!=index){Point q;other=Math.Max(other,Find(portals[i],local,out q,.65,i==1||i==2));}
  detail+="；同位置其他完整名="+other.ToString("0.00");if(score-other<.06)return false;
  point=new Point(label.X,label.Y-45);detail+="；门中心="+point.X+","+point.Y;return true;
 }

 public UpgradeMapReading ReadDialog(Bitmap image){
  if(!Valid(image))return new UpgradeMapReading{Detail="地图详情识别需要1216x684规范帧"};
  return FrameCache.Get<UpgradeMapReading>(image,this,"upgrade-dialog",delegate{return ReadDialogFresh(image);});
 }
 // Closing an owned but unreadable detail needs a full dialog heading and
 // the observed close control. It never supplies an enter point.
 public bool FindDialogClose(Bitmap image,out Point point){
  point=Point.Empty;if(!Valid(image)||heading==null)return false;
  Point header;if(heading.Find(ReadRegion(image,new Rectangle(520,60,180,60),Ink.Gold,"upgrade-heading"),out header,.65)<.80)return false;
  double score=Find(close,ReadRegion(image,Box(990,58,82,86),Ink.Gold,"upgrade-shell-close"),out point,.65);
  return score>=.86&&RedPixels(image,Box(point.X-8,point.Y-14,16,28))>=60;
 }
 UpgradeMapReading ReadDialogFresh(Bitmap image){
  var result=new UpgradeMapReading();Region title=ReadRegion(image,new Rectangle(265,105,240,53),Ink.Gold,"upgrade-titles");
  int winner=-1;Point bestPoint=Point.Empty;
  for(int i=0;i<Names.Length;i++){
   Point p;double score=Find(titles[i],title,out p,.62);
   if(score>result.TitleScore){result.RunnerUpScore=result.TitleScore;result.TitleScore=score;winner=i;bestPoint=p;}else result.RunnerUpScore=Math.Max(result.RunnerUpScore,score);
  }
  result.Detail="详情完整地图名="+(winner<0?"未知":Names[winner])+" "+result.TitleScore.ToString("0.00")+"；次高="+result.RunnerUpScore.ToString("0.00");
  if(winner<0||result.TitleScore<.77||result.TitleScore-result.RunnerUpScore<.07)return result;
  // A map name painted on its own never grants either a close or enter point.
  Point header;double hs=heading==null?0:heading.Find(ReadRegion(image,new Rectangle(520,60,180,60),Ink.Gold,"upgrade-heading"),out header,.65);
  result.Detail+="；地图传送="+hs.ToString("0.00");if(hs<.80)return result;
  result.Present=true;result.Name=Names[winner];
  // Observed title center is (347,132). Permit small capture phase/placement
  // changes; all subsequent controls must agree with that same dialog layout.
  int dx=bestPoint.X-347,dy=bestPoint.Y-132;
  dx=Math.Max(-12,Math.Min(12,dx));dy=Math.Max(-8,Math.Min(8,dy));
  string level=ReadCondition(image,Box(802+dx,446+dy,150,42),winner==5?ghostLevels:levels,"upgrade-level");
  string gear=ReadCondition(image,Box(802+dx,490+dy,150,42),winner==5?ghostEquipment:equipment,"upgrade-equipment");
  result.Requirements=level=="red"||gear=="red"?"red":level=="green"&&gear=="green"?"green":"unknown";
  result.Detail+="；等级条件="+level+"，装备碎片条件="+gear;
  Point found;double es=Find(enter,ReadRegion(image,Box(795+dx,542+dy,164,63),Ink.Gold,"upgrade-enter"),out found,.65);
  if(es>=.83)result.Enter=found;result.Detail+="；进入按钮="+es.ToString("0.00");
  double cs=Find(close,ReadRegion(image,Box(1005+dx,66+dy,55,62),Ink.Gold,"upgrade-close"),out found,.65);
  if(cs>=.86&&RedPixels(image,Box(found.X-8,found.Y-14,16,28))>=60)result.Close=found;
  result.Detail+="；完整关闭叉="+cs.ToString("0.00");return result;
 }
 string ReadCondition(Bitmap image,Rectangle area,List<Patch> glyphs,string key){
  Point p;double score=Find(glyphs,ReadRegion(image,area,Ink.Condition,key),out p,.65);if(score<.78)return "unknown";
  int[] pixels=FrameCache.Pixels(image);int green=0,red=0;
  for(int y=area.Top;y<area.Bottom;y++)for(int x=area.Left;x<area.Right;x++){int color=pixels[y*1216+x];if(Green(color))green++;if(Red(color))red++;}
  if(red>=70&&red>green*2)return "red";if(green>=90&&green>red*8&&red<12)return "green";return "unknown";
 }
 static int RedPixels(Bitmap image,Rectangle area){int[] pixels=FrameCache.Pixels(image);int count=0;for(int y=area.Top;y<area.Bottom;y++)for(int x=area.Left;x<area.Right;x++)if(Red(pixels[y*1216+x]))count++;return count;}
}
