using System;
using System.IO;
using System.Drawing;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

// Reads only the main player's bottom status bar. Call with Guardian.Normalize's
// 1216 x 684 image; the hero portrait and previously read values are never used.
public sealed class PlayerLevelReader {
 sealed class Sample { public int Symbol; public double[] Values; }
 readonly List<Sample> samples=new List<Sample>();
 readonly bool complete;
 const int Mark=10,FeatureWidth=14,FeatureHeight=20;
 static readonly Rectangle Row=new Rectangle(655,660,84,18);
 public PlayerLevelReader(string templateDirectory) {
  bool[] loaded=new bool[11];
  if(Directory.Exists(templateDirectory))foreach(string pattern in new string[]{"hp-v47-*.png","coord-v44-*.png","level-v417-*.png"})foreach(string file in Directory.GetFiles(templateDirectory,pattern)) {
   string[] parts=Path.GetFileNameWithoutExtension(file).Split('-');int symbol;
   if(parts.Length<4)continue;
   if(pattern=="level-v417-*.png"&&parts[2]=="mark")symbol=Mark;
   else if(!int.TryParse(parts[2],out symbol)||symbol<0||symbol>9)continue;
   try {using(Bitmap image=new Bitmap(file)) {
    if(image.Width<3||image.Width>18||image.Height<9||image.Height>18)continue;
    samples.Add(new Sample{Symbol=symbol,Values=Feature(image,new Rectangle(0,0,image.Width,image.Height),1)});loaded[symbol]=true;
   }} catch(ArgumentException){} catch(IOException){}
  }
  complete=true;for(int i=0;i<loaded.Length;i++)if(!loaded[i])complete=false;
 }
 static int White(Color pixel){return Math.Min(pixel.R,Math.Min(pixel.G,pixel.B));}
 static double Ink(Bitmap image,int x,int y,double scale){return Math.Max(0,Math.Min(1,(White(image.GetPixel(x,y))*scale-75)/140.0));}
 static double[] Feature(Bitmap image,Rectangle box,double scale) {
  double[] result=new double[FeatureWidth*FeatureHeight];
  for(int y=0;y<FeatureHeight;y++)for(int x=0;x<FeatureWidth;x++) {
   double sx=Math.Max(0,Math.Min(box.Width-1,(x+.5)*box.Width/FeatureWidth-.5));
   double sy=Math.Max(0,Math.Min(box.Height-1,(y+.5)*box.Height/FeatureHeight-.5));
   int x0=(int)sx,y0=(int)sy,x1=Math.Min(box.Width-1,x0+1),y1=Math.Min(box.Height-1,y0+1);
   double ax=sx-x0,ay=sy-y0;
   double a=Ink(image,box.X+x0,box.Y+y0,scale)*(1-ax)+Ink(image,box.X+x1,box.Y+y0,scale)*ax;
   double b=Ink(image,box.X+x0,box.Y+y1,scale)*(1-ax)+Ink(image,box.X+x1,box.Y+y1,scale)*ax;
   result[y*FeatureWidth+x]=a*(1-ay)+b*ay;
  }
  return result;
 }
 static double Error(double[] a,double[] b){double sum=0;for(int i=0;i<a.Length;i++){double d=a[i]-b[i];sum+=d*d;}return sum/a.Length;}
 public bool TryRead(Bitmap frame,out int level,out string detail) {
  level=-1;detail="主角色等级未读清";
  if(frame==null){detail="主角色等级截图为空";return false;}
  if(frame.Width!=1216||frame.Height!=684){detail="等级截图必须归一化为1216×684";return false;}
  if(!complete){detail="主角色等级模板不完整（需要0—9和级字）";return false;}
  int peak=0;for(int y=Row.Top;y<Row.Bottom;y++)for(int x=Row.Left;x<Row.Right;x++)peak=Math.Max(peak,White(frame.GetPixel(x,y)));
  if(peak<100){detail="底部等级文字对比度不足";return false;}
  double scale=peak<180?255.0/peak:1,threshold=peak<180?Math.Max(65,peak*.55):140;
  List<Rectangle> glyphs=new List<Rectangle>();int start=-1;
  for(int column=0;column<=Row.Width;column++) {
   bool occupied=false;
   if(column<Row.Width)for(int y=Row.Top;y<Row.Bottom;y++)if(White(frame.GetPixel(Row.X+column,y))>threshold){occupied=true;break;}
   if(occupied&&start<0)start=column;
   if(!occupied&&start>=0) {
    int first=Row.Bottom,last=0,rows=0;
    for(int y=Row.Top;y<Row.Bottom;y++) {
     bool ink=false;for(int x=start;x<column;x++)if(White(frame.GetPixel(Row.X+x,y))>threshold){ink=true;break;}
     if(ink){first=Math.Min(first,y);last=y;rows++;}
    }
    int width=column-start,height=last-first+1;
    if(start==0||column==Row.Width||width<3||width>18||height<10||height>18||rows<10){detail="底部等级字格遮挡或模糊";return false;}
    glyphs.Add(new Rectangle(Row.X+start,first,width,height));start=-1;
   }
  }
  if(glyphs.Count<2||glyphs.Count>4){detail="底部等级完整位数或级字未确认";return false;}
  // The level label is centered in its fixed HUD cell. Dropping a leading digit
  // moves the remaining text to the right; the suffix also fixes the right end.
  double center=(glyphs[0].Left+glyphs[glyphs.Count-1].Right)/2.0;
  if(center<693.5||center>698.0){detail="底部等级定位偏移或首尾字缺失";return false;}
  StringBuilder number=new StringBuilder(),evidence=new StringBuilder();int minTop=1000,maxTop=0,minBottom=1000,maxBottom=0;
  for(int index=0;index<glyphs.Count;index++) {
   Rectangle box=glyphs[index];bool isMark=index==glyphs.Count-1;
   if(index>0&&(box.Left-glyphs[index-1].Right<1||box.Left-glyphs[index-1].Right>4)){detail="底部等级字间距不完整";return false;}
   if(isMark) {
    if(box.Width<12||box.Width>18||box.Height<14||box.Top>minTop||box.Bottom<maxBottom){detail="底部级字或基线不完整";return false;}
   } else {
    if(box.Width>10||box.Height>14){detail="底部等级数字字格异常";return false;}
    minTop=Math.Min(minTop,box.Top);maxTop=Math.Max(maxTop,box.Top);minBottom=Math.Min(minBottom,box.Bottom);maxBottom=Math.Max(maxBottom,box.Bottom);
   }
   double[] values=Feature(frame,box,scale),scores=new double[11];for(int i=0;i<scores.Length;i++)scores[i]=double.PositiveInfinity;
   foreach(Sample sample in samples)scores[sample.Symbol]=Math.Min(scores[sample.Symbol],Error(values,sample.Values));
   int best=0;for(int i=1;i<scores.Length;i++)if(scores[i]<scores[best])best=i;
   double second=double.PositiveInfinity;for(int i=0;i<scores.Length;i++)if(i!=best)second=Math.Min(second,scores[i]);
   double gap=second-scores[best];
   evidence.Append(best==Mark?"级":best.ToString()).Append('(').Append(scores[best].ToString("0.000",CultureInfo.InvariantCulture)).Append('/').Append(gap.ToString("0.000",CultureInfo.InvariantCulture)).Append(") ");
   if(scores[best]>.060||gap<.018||(isMark&&best!=Mark)||(!isMark&&best==Mark)){detail="底部等级字形低置信；"+evidence;return false;}
   if(!isMark)number.Append(best);
  }
  int value;
  if(maxTop-minTop>2||maxBottom-minBottom>2||number[0]=='0'||!int.TryParse(number.ToString(),out value)||value<1||value>999){detail="底部等级数值或完整格式异常";return false;}
  level=value;detail="底部主角色等级="+level+"；完整数字+级字；字形误差/差距="+evidence.ToString().Trim();return true;
 }
}
