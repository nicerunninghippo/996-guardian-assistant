using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;

public enum AutoBattleState { Unknown, Off, On }

public sealed class AutoBattleReading {
 public AutoBattleState State;
 public Point? Button;
 public double OffScore,OnScore;
 public string Detail="";
}

// The right round sword button is the only authority: 挂机 = off, 自动 = on.
// The orange 自动战斗中 animation elsewhere can survive a stopped action and is
// deliberately never inspected. The caller must supply an actual game capture,
// normalized to 1216x684; screenshots containing desktop chrome are not captures.
public sealed class AutoBattleVision {
 sealed class Patch {
  internal readonly int Width,Height;
  internal readonly double[] Values;
  internal Patch(string path){using(Bitmap b=new Bitmap(path)){Width=b.Width;Height=b.Height;Values=new double[Width*Height];int[] pixels=FrameCache.Pixels(b);for(int i=0;i<Values.Length;i++)Values[i]=Light(pixels[i]);}}
 }
 sealed class Sample { internal AutoBattleState State; internal Patch Label,Icon; }
 sealed class Match { internal double Score,Icon;internal Point Offset; }
 readonly List<Sample> samples=new List<Sample>();
 bool complete;
 const double LabelThreshold=.80,GlyphThreshold=.73,IconThreshold=.67,StateMargin=.09;
 static double Light(int pixel){int r=(pixel>>16)&255,g=(pixel>>8)&255,b=pixel&255;return (r+g+b)/3.0;}
 public AutoBattleVision(string root){
  string dir=Directory.Exists(Path.Combine(root,"templates"))?Path.Combine(root,"templates"):root;
  bool hasOff=false,hasOn=false;
  foreach(string name in new[]{"off-hall","off-town","on-native","on-boss"}){
   string prefix=name=="on-boss"?"auto-v419-":"auto-v418-";
   string label=Path.Combine(dir,prefix+name+"-label.png"),icon=Path.Combine(dir,prefix+name+"-icon.png");
   if(!File.Exists(label)||!File.Exists(icon))continue;
   try{Sample s=new Sample{State=name.StartsWith("off-",StringComparison.Ordinal)?AutoBattleState.Off:AutoBattleState.On,Label=new Patch(label),Icon=new Patch(icon)};
    if(s.Label.Width!=38||s.Label.Height!=18||s.Icon.Width!=42||s.Icon.Height!=29)continue;
    samples.Add(s);if(s.State==AutoBattleState.Off)hasOff=true;else hasOn=true;
   }catch(ArgumentException){}catch(IOException){}
  }
  complete=hasOff&&hasOn;
 }
 public AutoBattleReading Read(Bitmap image){
  if(image==null||image.Width!=1216||image.Height!=684)return new AutoBattleReading{Detail="自动状态未知：需要1216x684游戏画面"};
  return FrameCache.Get<AutoBattleReading>(image,this,"right-auto-button",delegate{return ReadFrame(image);});
 }
 // Pearson correlation is invariant to a modest brightness change. Match each
 // entire glyph separately as well: one recognizable character is insufficient.
 static double Correlation(Patch patch,int[] pixels,int x,int y,int left,int width,out double contrast,out double peak){
  double a=0,b=0,aa=0,bb=0,ab=0;int n=width*patch.Height;peak=0;double low=255;
  for(int yy=0;yy<patch.Height;yy++)for(int xx=left;xx<left+width;xx++){
   double p=patch.Values[yy*patch.Width+xx],v=Light(pixels[(y+yy)*1216+x+xx]);
   a+=p;b+=v;aa+=p*p;bb+=v*v;ab+=p*v;peak=Math.Max(peak,v);low=Math.Min(low,v);
  }
  contrast=peak-low;double va=aa-a*a/n,vb=bb-b*b/n;if(va<1||vb<1)return 0;
  return Math.Max(0,(ab-a*b/n)/Math.Sqrt(va*vb));
 }
 static Match Find(Sample sample,int[] pixels){
  Match best=new Match();
  // Search only the known label and its sword icon, with a tiny shared offset.
  for(int dy=-4;dy<=4;dy++)for(int dx=-4;dx<=4;dx++){
   double contrast,peak;double score=Correlation(sample.Label,pixels,1093+dx,323+dy,0,38,out contrast,out peak);
   if(score<=best.Score||contrast<55||peak<140)continue;
   double first=Correlation(sample.Label,pixels,1093+dx,323+dy,0,18,out contrast,out peak);if(first<GlyphThreshold||contrast<45||peak<135)continue;
   double second=Correlation(sample.Label,pixels,1093+dx,323+dy,18,20,out contrast,out peak);if(second<GlyphThreshold||contrast<45||peak<135)continue;
   double icon=Correlation(sample.Icon,pixels,1090+dx,294+dy,0,42,out contrast,out peak);
   if(icon<IconThreshold||contrast<55||peak<140)continue;
   best.Score=score;best.Icon=icon;best.Offset=new Point(dx,dy);
  }
  return best;
 }
 AutoBattleReading ReadFrame(Bitmap image){
  AutoBattleReading r=new AutoBattleReading();if(!complete){r.Detail="自动状态未知：右侧挂机/自动双状态图样不完整";return r;}
  int[] pixels=FrameCache.Pixels(image);Match off=new Match(),on=new Match();
  foreach(Sample s in samples){Match match=Find(s,pixels);if(s.State==AutoBattleState.Off){if(match.Score>off.Score)off=match;}else if(match.Score>on.Score)on=match;}
  r.OffScore=off.Score;r.OnScore=on.Score;Match selected=off.Score>on.Score?off:on;
  if(selected.Score>=LabelThreshold&&Math.Abs(off.Score-on.Score)>=StateMargin){r.State=off.Score>on.Score?AutoBattleState.Off:AutoBattleState.On;r.Button=new Point(1110+selected.Offset.X,315+selected.Offset.Y);}
  r.Detail="右侧自动按钮="+(r.State==AutoBattleState.Off?"挂机（关闭）":r.State==AutoBattleState.On?"自动（开启）":"未知")+"；挂机="+r.OffScore.ToString("0.000",CultureInfo.InvariantCulture)+"；自动="+r.OnScore.ToString("0.000",CultureInfo.InvariantCulture)+"；双字阈值0.80/单字0.73；剑形="+selected.Icon.ToString("0.000",CultureInfo.InvariantCulture)+"；差值阈值0.09";
  return r;
 }
}
