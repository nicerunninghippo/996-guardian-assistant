using System;
using System.Drawing;

public sealed class RewardPopupAction {
 public bool Handled,Recovered,Diagnostic;
 public Point? Tap;
 public string Status="";
}
public sealed class RewardPopupFlow {
 public bool Active{get;private set;}
 int tries,clean;double last=-1,next,cooldown,absent=-1,roundStarted;
 bool reported;
 public void Reset(){Active=false;tries=clean=0;last=-1;next=cooldown=roundStarted=0;absent=-1;reported=false;}
 public RewardPopupAction Step(RewardPopupReading seen,bool underlyingClear,double now,bool running){
  var action=new RewardPopupAction();if(!running){Reset();return action;}
  if(!seen.Present&&!seen.Suspected&&!Active)return action;
  action.Handled=true;
  if(now<=last){action.Status="奖励弹窗：等待新截图，不重复点击";return action;}last=now;
  if(!seen.Present&&!seen.Suspected){
   if(absent<0)absent=now;
   clean=underlyingClear?clean+1:0;
   action.Status="奖励弹窗：等待两帧主画面或原窗口恢复确认";
   if(clean>=2){Reset();action.Recovered=true;action.Status="奖励弹窗已关闭，两帧恢复确认；继续原任务，领取结果由原流程核对";}
   else if(now-absent>=12){Reset();action.Diagnostic=true;action.Status="奖励弹窗恢复12秒未确认，结束本轮关闭验证，交回常规识别；不补点";}
   return action;
  }
  if(!Active){Active=true;roundStarted=now;}clean=0;absent=-1;
  if(cooldown>0){
   if(now<cooldown){action.Status="奖励弹窗：本轮关闭次数已用完或确认超时，冷却60秒后重新识别；暂停其他点击";if(!reported){action.Diagnostic=true;reported=true;}return action;}
   cooldown=0;tries=0;roundStarted=now;reported=false;
  }
  if(now-roundStarted>=15){cooldown=now+60;action.Diagnostic=true;reported=true;action.Status="奖励弹窗：15秒未确认关闭，冷却60秒后重新识别；暂停其他点击";return action;}
  if(!seen.Present){action.Status="疑似奖励弹窗：标题和关闭提示尚未同时确认，暂停其他点击";return action;}
  if(now<next){action.Status="奖励弹窗：已点击空白处，等待关闭反馈";return action;}
  tries++;next=now+3;action.Tap=seen.Dismiss;
  action.Status="奖励弹窗：已确认恭喜获得和空白关闭提示，点击侧边空白处（"+tries+"/3）";
  if(tries>=3){cooldown=now+60;reported=false;}
  return action;
 }
}
