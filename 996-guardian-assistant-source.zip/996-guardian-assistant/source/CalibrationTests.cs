using System;
using System.Drawing;
using System.Collections.Generic;

static class CalibrationTests {
 static int passed;
 static void Check(bool condition,string message){if(!condition)throw new Exception("方向校准回归失败："+message);}
 sealed class Session {
  public readonly DirectionCalibration Flow=new DirectionCalibration();
  public readonly Engine Guard=new Engine();
  public readonly List<string> Logs=new List<string>();
  public bool Connected=true,StopKey,TransportOk=true;
  public int Requests,ActualSends;
  public double Now;
  public Point LastFrom,LastTo;
  public int LastDuration;
  public Session(){Guard.Start();Guard.Stop("校准中");Flow.Begin(0,new Point(100,500));}
  public bool Send(Point from,Point to,int ms){Requests++;return CalibrationInput.Send(Flow.Active,Guard.Running,Connected,StopKey,from,to,ms,(a,b,d)=>{ActualSends++;LastFrom=a;LastTo=b;LastDuration=d;return TransportOk;});}
  public void At(Point? p,int map,double time){Now=time;Flow.Step(p,map,time,Send,Logs.Add);}
  public void Frame(Point? p){At(p,0,Now+2);}
  public void Stable(Point p){Frame(p);Frame(p);}
  public bool HasFeedback(){return Logs.Exists(s=>s.Contains("反馈"));}
 }
 static void Table(Session s,int[] dx,int[] dy){
  Point current=new Point(300,300);
  for(int i=0;i<8&&s.Flow.Active;i++){
   int repeats=dx[i]==0&&dy[i]==0?2:1;
   for(int n=0;n<repeats&&s.Flow.Active;n++){
    s.Stable(current);
    current=new Point(current.X+dx[i],current.Y+dy[i]);
    s.Stable(current);
   }
  }
 }
 static void Case(Action test){test();passed++;}
 public static string Run(){
  passed=0;
  Case(()=>{
   var s=new Session();Check(!s.Guard.Running,"校准必须暂停普通守护");
   s.Stable(new Point(312,333));
   Check(s.ActualSends==1&&s.Flow.Sent==1&&s.Flow.Active,"守护停止后校准仍需真实调用发送接口");
   Check(s.LastFrom==new Point(100,500)&&s.LastTo==new Point(100,438)&&s.LastDuration==550,"第一方向必须从已选圆心向上短移");
  });
  Case(()=>{
   var s=new Session();s.Guard.Start();s.Stable(new Point(312,333));
   Check(s.ActualSends==0&&s.Flow.Sent==0&&s.Flow.Complete&&!s.Flow.Success&&!s.HasFeedback(),"正常守护运行时禁止同时发校准指令");
  });
  Case(()=>{
   var s=new Session();s.Connected=false;s.Stable(new Point(312,333));
   Check(s.ActualSends==0&&s.Flow.Sent==0&&!s.Flow.Active&&!s.HasFeedback(),"未连接不得发送或生成位移反馈");
  });
  Case(()=>{
   var s=new Session();s.StopKey=true;s.Stable(new Point(312,333));
   Check(s.ActualSends==0&&s.Flow.Sent==0&&!s.Flow.Active&&!s.HasFeedback(),"F8按下不得发送");
  });
  Case(()=>{
   int actual=0;bool ok=CalibrationInput.Send(false,false,true,false,Point.Empty,new Point(2,2),550,(a,b,d)=>{actual++;return true;});
   Check(!ok&&actual==0,"未进入校准流程时校准通道不得发送");
  });
  Case(()=>{
   var s=new Session();s.TransportOk=false;s.Stable(new Point(312,333));
   Check(s.ActualSends==1&&s.Flow.Sent==0&&s.Flow.Complete&&!s.Flow.Success&&!s.HasFeedback(),"发送接口失败必须立即终止且不得声称已移动");
   s.Stable(new Point(300,320));Check(!s.HasFeedback()&&s.ActualSends==1,"发送失败后不可用后来读数伪造反馈");
  });
  Case(()=>{
   var s=new Session();s.At(new Point(312,333),0,0);Check(s.ActualSends==0,"单帧起点不得发送");
   s.At(new Point(312,333),0,0.9);Check(s.ActualSends==1,"第二帧一致起点应发送");
   s.At(new Point(311,332),0,1.0);s.At(new Point(311,332),0,2.0);
   Check(!s.HasFeedback(),"等待时间未结束时不能采集移动后结果");
   s.At(new Point(311,332),0,2.3);Check(!s.HasFeedback(),"第一帧移动后坐标不得入表");
   s.At(new Point(311,332),0,3.2);Check(s.Flow.Index==1&&s.Flow.Dx[0]==-1&&s.Flow.Dy[0]==-1,"两帧一致反馈才可记录方向");
  });
  Case(()=>{
   var s=new Session();s.Frame(new Point(312,333));s.Frame(new Point(313,333));s.Frame(new Point(312,333));
   Check(s.ActualSends==0,"起点抖动时不得发送");s.Frame(new Point(312,333));Check(s.ActualSends==1,"起点重新稳定后发送");
  });
  Case(()=>{
   var s=new Session();s.Stable(new Point(300,300));s.Frame(null);s.Stable(new Point(299,299));
   Check(s.Flow.Index==1&&s.Flow.Dx[0]==-1&&s.Flow.Dy[0]==-1,"短暂读丢后仍应按本次起点算位移");
   s.Stable(new Point(302,299));s.Stable(new Point(302,297));
   Check(s.ActualSends==2&&s.Flow.Dx[1]==0&&s.Flow.Dy[1]==-2,"下一方向必须重新读起点，不累计前一步位移");
  });
  Case(()=>{
   var s=new Session();s.Stable(new Point(312,333));for(int i=0;i<6;i++)s.Frame(null);
   Check(s.Flow.Complete&&!s.Flow.Success&&s.ActualSends==1&&!s.HasFeedback(),"移动后连续读丢应终止，不能继续扫后续方向");
  });
  Case(()=>{
   var s=new Session();for(int i=0;i<6;i++)s.Frame(i%2==0?new Point(312,333):new Point(313,333));
   Check(s.Flow.Complete&&!s.Flow.Success&&s.ActualSends==0,"6帧始终不稳定应退出且没有发送");
  });
  Case(()=>{
   var s=new Session();Table(s,new int[8],new int[8]);
   Check(s.ActualSends==16&&s.Flow.Sent==16&&s.Flow.Complete&&!s.Flow.Success,"八方向全零必须各有限重试一次且整体失败");
   int sends=s.ActualSends;s.Stable(new Point(312,333));Check(s.ActualSends==sends,"全零失败后禁止继续发送");
  });
  Case(()=>{
   var s=new Session();s.Stable(new Point(312,333));s.Stable(new Point(312,533));
   Check(s.ActualSends==1&&s.Flow.Complete&&!s.Flow.Success&&s.Flow.Dy[0]==0,"333误读533的跳变不得写入方向表");
  });
  Case(()=>{
   var s=new Session();Table(s,new[]{0,1,2,1,0,-1,-2,-1},new int[8]);
   Check(s.ActualSends==10&&s.Flow.Complete&&!s.Flow.Success,"只有X方向移动无法组成可用方向表");
  });
  Case(()=>{
   var s=new Session();int[] diagonal={1,2,1,-1,-2,-1,1,-1};Table(s,diagonal,diagonal);
   Check(s.ActualSends==8&&s.Flow.Complete&&!s.Flow.Success,"X和Y都变化但始终共线也应失败");
  });
  Case(()=>{
   var s=new Session();int[] dx={-1,0,1,2,1,0,-1,-2},dy={-1,-2,-1,0,1,2,1,0};Table(s,dx,dy);
   Check(s.ActualSends==8&&s.Flow.Sent==8&&s.Flow.Complete&&s.Flow.Success&&!s.Flow.Active,"8方向有实际反馈才算校准成功");
   for(int i=0;i<8;i++)Check(s.Flow.Dx[i]==dx[i]&&s.Flow.Dy[i]==dy[i],"第"+i+"方向记录错误");
  });
  Case(()=>{
   var s=new Session();s.Stable(new Point(312,333));s.At(new Point(22,36),3,s.Now+2);
   Check(s.ActualSends==1&&s.Flow.Complete&&!s.Flow.Success&&!s.HasFeedback(),"校准中换图应立即取消，不把传送差作为位移");
  });
  Case(()=>{
   var s=new Session();s.Stable(new Point(312,333));s.Flow.Cancel("用户停止");
   for(int i=0;i<8;i++)s.Frame(new Point(310,332));
   Check(s.ActualSends==1&&s.Flow.Complete&&!s.Flow.Success&&!s.HasFeedback(),"取消后不得继续发送或记录新方向");
  });
  return "方向校准回归测试通过："+passed+"项（含真实发送计数、稳定采样、失败终止及8方向反馈）";
 }
}
