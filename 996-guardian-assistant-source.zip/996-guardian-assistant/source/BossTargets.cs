using System;
using System.IO;
using System.Collections.Generic;
using System.Web.Script.Serialization;

public sealed class BossTarget {
 public string name,map;
 public bool enabled=true,allow_resource_challenge=true;
}
public static class BossTargets {
 public static readonly string[] Names={"前哨先锋","战场主宰","石原之主","要塞统领","叛军首领","游荡鬼王"};
 public static int MinLevel(string name){return name=="游荡鬼王"?80:name=="叛军首领"?79:0;}
 public static string Map(string name){switch(name){case "前哨先锋":return "战场前哨";case "战场主宰":return "叛军营地";case "石原之主":return "石原森林";case "要塞统领":return "龙爪要塞";case "叛军首领":return "叛军基地";case "游荡鬼王":return "鬼门关";default:throw new ArgumentException("尚未支持的BOSS："+name);}}
 public static List<BossTarget> Load(string root){
  string file=Path.Combine(root,"boss-targets.json");
  if(!File.Exists(file)){var defaults=new List<BossTarget>();foreach(string n in Names)defaults.Add(new BossTarget{name=n,map=Map(n)});return defaults;}
  var targets=new JavaScriptSerializer().Deserialize<List<BossTarget>>(File.ReadAllText(file));
  if(targets==null||targets.Count==0)throw new InvalidDataException("BOSS配置为空");
  var unique=new HashSet<string>();foreach(var t in targets){if(t==null||t.map!=Map(t.name)||!unique.Add(t.name))throw new InvalidDataException("BOSS配置名称重复或地图不符");}
  return targets;
 }
}
