using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

partial class Guardian {
 readonly MaintenanceSchedule maintenanceSchedule=new MaintenanceSchedule();
 IMaintenanceTask maintenanceTask;
 OnlineDemonTask onlineTask;DailyFreeTask dailyTask;MergeRewardsTask mergeTask;MailTask mailTask;BagUseTask bagUseTask;
 CheckBox maintenanceEnabled=new CheckBox();
 string maintenanceLast="";DateTime maintenanceLogAt=DateTime.MinValue;
 bool maintenanceReady,maintenanceDiagnosticSaved;
 double maintenanceCleanupUntil,maintenanceCleanupTap;
 int maintenanceCleanupClicks;
 readonly MaintenanceAdmission maintenanceAdmission=new MaintenanceAdmission();
 double maintenanceNextMailScan;
 int maintenanceEvidenceCount;
 string maintenanceTraceStep="";

 void InitMaintenance(Control top){
  maintenanceEnabled.Text="自动福利/邮件/指定道具（刷怪后及每4小时）";maintenanceEnabled.AutoSize=true;maintenanceEnabled.Checked=true;
  top.Controls.Add(maintenanceEnabled);
  maintenanceEnabled.CheckedChanged+=(s,e)=>{
   if(!maintenanceEnabled.Checked){TraceEvent("maintenance_setting","enabled",false);ResetMaintenance();Log("福利、邮件和道具任务已关闭；继续原守护");}
   else if(guardRequested){maintenanceSchedule.Start(ClockSeconds());TraceEvent("maintenance_setting","enabled",true,"next_cycle",maintenanceSchedule.NextCycle);Log("福利任务已启用：入图且自动开启后检查，每4小时；盟重与路线阶段不抢占");}
  };
 }
 void PrepareMaintenance(){
  if(maintenanceReady)return;
  onlineTask=new OnlineDemonTask(root);dailyTask=new DailyFreeTask(root);mergeTask=new MergeRewardsTask(root);mailTask=new MailTask(root);bagUseTask=new BagUseTask(root);
  bagUseTask.UseAll=true;
  maintenanceReady=true;
 }
 void ResetMaintenance(){
  if(maintenanceTask!=null){TraceEvent("maintenance_cancel","task",maintenanceSchedule.Active,"name",maintenanceTask.Name,"reason","停止或重连取消维护");TraceTaskEnd(false,"停止或重连取消维护");}
  if(maintenanceTask!=null)maintenanceTask.Reset();maintenanceTask=null;maintenanceSchedule.Reset();
  ResetRewardPopup();lowFpsFlow.Reset();maintenanceCleanupUntil=maintenanceCleanupTap=0;maintenanceCleanupClicks=0;maintenanceLast="";
  maintenanceAdmission.Reset();maintenanceNextMailScan=0;
  maintenanceTraceStep="";
 }
 void StartMaintenance(){ResetMaintenance();maintenanceSchedule.Start(ClockSeconds());TraceEvent("maintenance_schedule_start","next_cycle",maintenanceSchedule.NextCycle,"next_mail",maintenanceSchedule.NextMail);}
 void InvalidateMaintenanceObservation(){
  engine.ResetObservation();engine.ResetPending();ResetHealthEvidence();autoWaiting=false;
  mengWalk.Pending=false;shenWalk.Pending=false;mzCoordReadyUntil=DateTime.MinValue;
 }
 void MaintenanceLog(string value,bool important){
  engine.Status=value;
  if(important||value!=maintenanceLast||(DateTime.Now-maintenanceLogAt).TotalSeconds>=20){
   Log(value);maintenanceLast=value;maintenanceLogAt=DateTime.Now;
  }
 }
 void FinishMaintenance(double now,bool success,string reason){
  string id=maintenanceSchedule.Active;
  bool more=id=="items"&&bagUseTask.HasMore;
  maintenanceTask.Reset();maintenanceTask=null;maintenanceSchedule.Finish(id,now,success,more);
  double retryAt=id=="mail"?maintenanceSchedule.NextMail:maintenanceSchedule.RetryTime(id);
  TraceEvent("maintenance_finish","task",id,"success",success,"reason",reason,"remaining_items",more,"retry_due",retryAt,"retry_after_seconds",retryAt>now?retryAt-now:0,"next_cycle",maintenanceSchedule.NextCycle);
  maintenanceTraceStep="";
  InvalidateMaintenanceObservation();
  string followup=id=="mail"?(success?"":"；5分钟后可重新检查邮件通知"):maintenanceSchedule.RetryTime(id)>now?"；5分钟后补查，其间继续原守护":success?"":"；本周期不再立即重试，继续原守护";
  MaintenanceLog("维护任务结束："+id+"；"+reason+followup,true);
  TraceTaskEnd(success,reason);
  maintenanceCleanupUntil=now+12;maintenanceCleanupTap=now;maintenanceCleanupClicks=0;
  try{
   string serial=(backend.Serial??"unknown").Replace(':','_');
   File.WriteAllText(Path.Combine(data,"maintenance-"+serial+".txt"),"version="+DatedLogWriter.Release+Environment.NewLine+"last="+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+Environment.NewLine+"task="+id+Environment.NewLine+"success="+success+Environment.NewLine+"result="+reason+Environment.NewLine+"next="+DateTime.Now.AddSeconds(Math.Max(0,maintenanceSchedule.NextCycle-now)).ToString("yyyy-MM-dd HH:mm:ss"));
  }catch(Exception ex){TraceEvent("maintenance_record_error","task",id,"exception",ex.ToString());Log("维护记录写入失败："+ex.Message);}
 }
 bool CleanupMaintenance(Bitmap image,double now){
  if(maintenanceCleanupUntil<=0)return false;
  if(now>=maintenanceCleanupUntil){maintenanceCleanupUntil=0;TraceEvent("maintenance_cleanup_end","reason","12秒清理期限已到","clicks",maintenanceCleanupClicks);Log("维护窗口清理时间已到，交回常规窗口恢复，守护继续");return false;}
  if(farmPopupDetector==null)farmPopupDetector=new FarmPopupDetector(Path.Combine(root,"templates"));
  var popup=farmPopupDetector.Read(image,true);
  if(popup.CanClose){
   if(now>=maintenanceCleanupTap&&maintenanceCleanupClicks<3){
    maintenanceCleanupClicks++;maintenanceCleanupTap=now+3;
    TraceEvent("maintenance_cleanup_action","attempt",maintenanceCleanupClicks,"point",popup.ClosePoint,"detail",popup.Detail);
    TraceBeforeAction(image,"维护收尾：关闭已确认的窗口；"+popup.Detail);
    if(Click(popup.ClosePoint))MaintenanceLog("维护收尾：关闭已确认的窗口，等待新截图",true);
   }
   else TraceGate("维护收尾等待：点击冷却或本轮已达3次；clicks="+maintenanceCleanupClicks+" next="+maintenanceCleanupTap);
   return true;
  }
  // Dedicated task modules verify their own close controls; leave unresolved
  // bag/mail prompts to the normal bounded task retry instead of random taps.
  maintenanceCleanupUntil=0;TraceEvent("maintenance_cleanup_end","reason","当前截图没有可确认关闭的弹窗","detail",popup.Detail);return false;
 }
 bool HandleMaintenance(Bitmap image){if(bossResumeFlow.Active&&maintenanceTask==null)return false;
  if(!guardRequested||!engine.Running||!maintenanceEnabled.Checked){TraceGate("维护未启用：guardRequested="+guardRequested+" running="+engine.Running+" enabled="+maintenanceEnabled.Checked);return false;}
  double now=ClockSeconds();
  int routeMap=ReadStrictTitleMap(image);
  bool inTown=routeMap==0||BossTitle(image)=="盟重省";
  if(inTown){
   maintenanceAdmission.Reset();
   if(maintenanceTask!=null)FinishMaintenance(now,false,"确认盟重，取消维护并关闭残留窗口，优先下图刷怪");
   TraceGate("盟重下图优先：不启动福利、邮件或道具维护");
   return CleanupMaintenance(image,now);
  }
  // Existing owned tasks can finish through a dimmed title. New work needs
  // a positively verified farming map and an actually enabled right toggle.
  if(maintenanceTask==null&&(routeMap!=4||ReadAutoBattle(image).State!=AutoBattleState.On)){
   maintenanceAdmission.Reset();TraceGate("维护等待刷怪地图及右侧自动确认；当前地图="+routeMap);return false;
  }
  if(maintenanceTask==null&&BossWaitingForAdmission())return false;
  if(maintenanceTask==null&&(priorityEntryDeadline!=DateTime.MinValue||mapPriority.Active>=0||closeStaleDialog)){TraceGate("优先地图进入或关闭验证尚未结束，维护任务等待");maintenanceAdmission.Reset();return false;}
  try{
   PrepareMaintenance();
   if(maintenanceTask==null&&CleanupMaintenance(image,now))return true;
   if(maintenanceTask==null){
    // The previous version performed full-frame scans even when no task was
    // due, and admitted new work while minimap recovery was still pending.
    bool due=maintenanceSchedule.HasDueWork(now);
    bool mailDue=now>=maintenanceSchedule.NextMail&&now>=maintenanceNextMailScan;
    if(!due&&!mailDue){TraceGate("维护未到检查时间：nextCycle="+maintenanceSchedule.NextCycle+" nextMail="+maintenanceSchedule.NextMail+" nextMailScan="+maintenanceNextMailScan);return false;}
    if(!AutoBattleAllowsMaintenance(image)){TraceGate("刷怪图右侧尚未确认自动开启，先恢复自动战斗");maintenanceAdmission.Reset();return false;}
    if(mailDue)maintenanceNextMailScan=now+3;
    bool recovering=coordCalibration.Active||recycle.Stage!=0||engine.Pending>=0||autoWaiting||minimapRecovery.Active||farmPopupFlow.Active||welfarePending||welcomeClosing||mengWalk.Pending||shenWalk.Pending;
    if(recovering){TraceGate("恢复或其他动作尚未结束：坐标校准="+coordCalibration.Active+" 回收阶段="+recycle.Stage+" 待切图="+engine.Pending+" 自动战斗等待="+autoWaiting+" 小地图恢复="+minimapRecovery.Active+" 弹窗恢复="+farmPopupFlow.Active+" 福利弹窗="+welfarePending+" 欢迎关闭="+welcomeClosing+" 盟重移动="+mengWalk.Pending+" 神龙移动="+shenWalk.Pending);maintenanceAdmission.Reset();return false;}
    var minimap=ReadMinimap(image);
    if(minimap.State!=MinimapState.Expanded){TraceGate("小地图尚未展开：state="+minimap.State);maintenanceAdmission.Reset();return false;}
    var bag=recycleVision.Read(image);
    bool ready=bag.Icon&&!bag.Bag&&!bag.Page;
    // Known nuisance windows are closed before scheduling another owned task.
    if(farmPopupDetector==null)farmPopupDetector=new FarmPopupDetector(Path.Combine(root,"templates"));
    var popup=farmPopupDetector.Read(image,true);
    bool blocked=popup.Panel||popup.MapDetail||IsEntryDetailVisible(image);
    if(!maintenanceAdmission.Observe(now,false,true,ready,blocked)){TraceGate(blocked?"模态窗口阻挡维护：panel="+popup.Panel+" mapDetail="+popup.MapDetail+" detail="+popup.Detail:!ready?"主画面入口未就绪：bagIcon="+bag.Icon+" bag="+bag.Bag+" recyclePage="+bag.Page:"主画面尚待连续稳定确认");return false;}
    bool notification=mailDue&&mailTask.HasNotification(image);
    string id=maintenanceSchedule.Next(now,true,notification,true);if(id.Length==0){TraceGate("当前没有可启动的维护任务：due="+due+" mailDue="+mailDue+" notification="+notification);return false;}
    if(id=="online")maintenanceTask=onlineTask;
    else if(id=="daily")maintenanceTask=dailyTask;
    else if(id=="merge")maintenanceTask=mergeTask;
    else if(id=="mail")maintenanceTask=mailTask;
    else maintenanceTask=bagUseTask;
    TraceTaskBegin(id,maintenanceTask.Name);maintenanceTraceStep="";
    TraceEvent("maintenance_begin","task",id,"name",maintenanceTask.Name,"instance",backend.Serial,"notification",notification,"due",due,"mail_due",mailDue);
    now=ClockSeconds();maintenanceTask.Begin(now);maintenanceSchedule.Started=now;maintenanceDiagnosticSaved=false;maintenanceEvidenceCount=0;maintenanceAdmission.Reset();InvalidateMaintenanceObservation();
    farmPopupFlow.Reset();boxPopupFlow.Reset();ResetWelcomePopup();
    MaintenanceLog("开始维护任务："+maintenanceTask.Name+"；实例="+backend.Serial+"；窗口由本任务处理，自动关窗暂时让位",true);
   }
   if(maintenanceSchedule.Expired(now)){TraceEvent("maintenance_abandon","reason","210秒总时限","elapsed_seconds",now-maintenanceSchedule.Started);FinishMaintenance(now,false,"总时间超过210秒，结束本轮恢复正常守护");return true;}
   MaintenanceDecision action=maintenanceTask.Step(image,now);
   string traceStep=action.Status+"|"+action.Done+"|"+action.Success+"|"+action.Tap;
   if(traceStep!=maintenanceTraceStep||action.Tap.HasValue||action.Done){TraceEvent("maintenance_step","task",maintenanceSchedule.Active,"status",action.Status,"done",action.Done,"success",action.Success,"tap",action.Tap,"elapsed_seconds",now-maintenanceSchedule.Started);maintenanceTraceStep=traceStep;}
   InvalidateMaintenanceObservation();
   if(action.Tap.HasValue){
    if(!guardRequested||!engine.Running||Native.GetAsyncKeyState(0x77)!=0){TraceEvent("maintenance_action_cancel","reason","守护停止或F8","guard_requested",guardRequested,"running",engine.Running,"tap",action.Tap);return true;}
    SaveMaintenanceEvidence(image,action);
    TraceBeforeAction(image,action.Status);
    if(!Click(action.Tap.Value)){TraceEvent("maintenance_action_failed","reason","本次点击未发出","tap",action.Tap);FinishMaintenance(now,false,"本次点击未发出");return true;}
   }
   MaintenanceLog(action.Status.StartsWith(maintenanceTask.Name+"：")?action.Status:maintenanceTask.Name+"："+action.Status,action.Tap.HasValue||action.Done);
   if(!maintenanceDiagnosticSaved&&((action.Done&&!action.Success)||action.Status.Contains("超时")||action.Status.Contains("跳过")||action.Status.Contains("无明确反馈")||action.Status.Contains("状态不明"))){
    maintenanceDiagnosticSaved=true;SaveDiagnostic(image,-1,"maintenance-"+maintenanceSchedule.Active);
   }
   if(action.Done)FinishMaintenance(now,action.Success,action.Status);
   return true;
  }catch(Exception ex){
   TraceEvent("maintenance_exception","task",maintenanceSchedule.Active,"exception",ex.ToString());
   if(maintenanceTask!=null)FinishMaintenance(now,false,"任务异常："+ex.Message);
   else{maintenanceEnabled.Checked=false;Log("福利模块初始化失败，已停用该模块，原守护继续："+ex.Message);}
   return true;
  }
 }
 void SaveMaintenanceEvidence(Bitmap image,MaintenanceDecision action){
  // A bounded pre-action record preserves the actual frame that authorized
  // input, rather than only saving a later, possibly closed, failure screen.
  if(maintenanceEvidenceCount>=4)return;
  try{
   maintenanceEvidenceCount++;
   SaveDiagnostic(image,-1,"maintenance-"+maintenanceSchedule.Active+"-before-"+maintenanceEvidenceCount);
   TraceEvent("maintenance_evidence_context","status",action.Status,"normalized_tap",action.Tap,"native_size",backend.Width+"x"+backend.Height);
  }catch(Exception ex){TraceEvent("maintenance_evidence_error","exception",ex.ToString());Log("维护截图保存失败："+ex.Message);}
 }
}

