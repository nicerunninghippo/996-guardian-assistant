using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;

public sealed class BoxPopupReading {
 public bool Panel,CanClose;
 public Point ClosePoint;
 public double LogoScore,MenuScore,CrossScore;
}

// The supplied 1215 x 684 game screenshot is normalized to 1216 x 684 using
// the same DrawImage operation as Guardian. Templates deliberately exclude
// the user's red annotation around the close control.
public sealed class BoxPopupDetector {
 sealed class Pixels {
  public int Width,Height; public int[] Values;
  public Pixels(Bitmap source) {
   Width=source.Width;Height=source.Height;Values=new int[Width*Height];
   using(Bitmap copy=new Bitmap(Width,Height,PixelFormat.Format32bppArgb)) {
    using(Graphics g=Graphics.FromImage(copy))g.DrawImageUnscaled(source,0,0);
    BitmapData bits=copy.LockBits(new Rectangle(0,0,Width,Height),ImageLockMode.ReadOnly,PixelFormat.Format32bppArgb);
    try { for(int y=0;y<Height;y++)Marshal.Copy(IntPtr.Add(bits.Scan0,y*bits.Stride),Values,y*Width,Width); }
    finally {copy.UnlockBits(bits);}
   }
  }
 }
 sealed class Patch {
  readonly Pixels pixels; readonly int stride;
  public int Width {get{return pixels.Width;}} public int Height {get{return pixels.Height;}}
  public Patch(string file,int sampleStride){using(Bitmap b=new Bitmap(file))pixels=new Pixels(b);stride=sampleStride;}
  static bool Gold(int value){int r=(value>>16)&255,g=(value>>8)&255,b=value&255;return r>135&&g>100&&b<150&&r>g*1.08&&g>b*1.20;}
  public double Score(Pixels frame,int left,int top) {
   if(left<0||top<0||left+Width>frame.Width||top+Height>frame.Height)return 0;
   long error=0;int count=0,expected=0,actual=0,hit=0;
   for(int y=0;y<Height;y+=stride)for(int x=0;x<Width;x+=stride) {
    int a=pixels.Values[y*Width+x],b=frame.Values[(top+y)*frame.Width+left+x];
    error+=Math.Abs(((a>>16)&255)-((b>>16)&255))+Math.Abs(((a>>8)&255)-((b>>8)&255))+Math.Abs((a&255)-(b&255));count++;
    bool ag=Gold(a),bg=Gold(b);if(ag)expected++;if(bg)actual++;if(ag&&bg)hit++;
   }
   if(expected<8)return 0;
   double color=1-error/(765.0*count),shape=2.0*hit/(expected+actual);
   // A red rectangle without the X fails the gold-shape check, even when
   // its average color matches the reference close button.
   return Math.Min(color,shape);
  }
 }
 readonly Patch logo,menu,cross;
 static readonly Point LogoAt=new Point(509,132),MenuAt=new Point(886,316),CrossAt=new Point(1026,195);
 public BoxPopupDetector(string templateDirectory) {
  try {
   logo=new Patch(Path.Combine(templateDirectory,"box-logo-v47.png"),3);
   menu=new Patch(Path.Combine(templateDirectory,"box-menu-v47.png"),2);
   cross=new Patch(Path.Combine(templateDirectory,"box-cross-v47.png"),1);
  } catch(IOException){} catch(ArgumentException){}
 }
 public BoxPopupReading Read(Bitmap image) {
  BoxPopupReading result=new BoxPopupReading();
  if(image==null||image.Width!=1216||image.Height!=684||logo==null||menu==null||cross==null)return result;
  Pixels frame=new Pixels(image);Point offset=Point.Empty;
  // Only a small translation around the observed layout is supported.
  // An unknown or resized panel does not authorize a guessed close point.
  for(int dy=-8;dy<=8;dy++)for(int dx=-8;dx<=8;dx++) {
   double score=logo.Score(frame,LogoAt.X+dx,LogoAt.Y+dy);
   if(score>result.LogoScore){result.LogoScore=score;offset=new Point(dx,dy);}
  }
  if(result.LogoScore<.82)return result;
  for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)
   result.MenuScore=Math.Max(result.MenuScore,menu.Score(frame,MenuAt.X+offset.X+dx,MenuAt.Y+offset.Y+dy));
  result.Panel=result.MenuScore>=.84;if(!result.Panel)return result;
  for(int dy=-2;dy<=2;dy++)for(int dx=-2;dx<=2;dx++) {
   int left=CrossAt.X+offset.X+dx,top=CrossAt.Y+offset.Y+dy;
   double score=cross.Score(frame,left,top);
   if(score>result.CrossScore){result.CrossScore=score;result.ClosePoint=new Point(left+cross.Width/2,top+cross.Height/2);}
  }
  result.CanClose=result.CrossScore>=.84;
  if(!result.CanClose)result.ClosePoint=Point.Empty;
  return result;
 }
}

public sealed class BoxPopupAction {
 public bool Handled; public Point? Tap; public string Status="";
}

// Pure decision logic: no capture, window lookup, or device input is performed.
public sealed class BoxPopupFlow {
 bool awaiting;int cleanFrames,attempts;double nextTap,lastFrame=-1;
 public void Reset(){awaiting=false;cleanFrames=0;attempts=0;nextTap=0;lastFrame=-1;}
 public BoxPopupAction Step(BoxPopupReading seen,double now,bool running) {
  BoxPopupAction action=new BoxPopupAction();
  if(!running){Reset();return action;}
  if(seen.Panel) {
   awaiting=true;cleanFrames=0;lastFrame=now;action.Handled=true;
   if(!seen.CanClose){action.Status="996盒子页面已识别，关闭叉不清晰；等待下一帧，不点击";return action;}
   if(now<nextTap){action.Status="等待996盒子页面关闭验证";return action;}
   action.Tap=seen.ClosePoint;attempts++;nextTap=now+(attempts<3?2.5:10);
   if(attempts>=3)attempts=0;
   action.Status="已识别996盒子页面和关闭叉，单点关闭后等待新截图";return action;
  }
  if(!awaiting)return action;
  action.Handled=true;action.Status="996盒子页面暂未出现，等待连续新截图确认";
  if(now>lastFrame){lastFrame=now;cleanFrames++;}
  if(cleanFrames>=2){Reset();action.Status="996盒子页面已消失，下一帧重新识别游戏";}
  return action;
 }
}

#if !BOX_POPUP_REPLAY
partial class Guardian {
 BoxPopupDetector boxPopupDetector;readonly BoxPopupFlow boxPopupFlow=new BoxPopupFlow();
 void ResetBoxPopup(){boxPopupFlow.Reset();}
 // Invoke before map, health, recycle, or other popup handling; a handled
 // frame must return from Tick. Reset the health baseline at that call site.
 bool CloseBoxPopup(Bitmap image) {
  if(!guardRequested||!engine.Running||Native.GetAsyncKeyState(0x77)!=0){ResetBoxPopup();return false;}
  if(boxPopupDetector==null)boxPopupDetector=new BoxPopupDetector(Path.Combine(root,"templates"));
  BoxPopupAction action=boxPopupFlow.Step(boxPopupDetector.Read(image),ClockSeconds(),true);
  if(!action.Handled)return false;
  engine.ResetObservation();engine.ResetPending();autoWaiting=false;
  // A popup invalidates any half-finished recycle observation sequence.
  if(recycle.Stage!=0){recycle.Reset();nextRecycle=DateTime.Now.AddMinutes((double)recycleMinutes.Value);}
  engine.Status=action.Status;
  if(action.Tap.HasValue) {
   // Re-check immediately before the single permitted input. Click also
   // checks the running flag and F8; no gift/menu control is ever selected.
   if(!guardRequested||!engine.Running||Native.GetAsyncKeyState(0x77)!=0){ResetBoxPopup();return true;}
   if(!Click(action.Tap.Value))engine.Status="996盒子关闭点击未发出；等待下一帧重新确认";
  }
  Log(engine.Status);return true;
 }
}
#endif
