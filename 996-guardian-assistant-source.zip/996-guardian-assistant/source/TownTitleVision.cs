using System;
using System.Drawing;
using System.IO;

sealed class TownTitleReading {
 public bool Town;
 public double Score;
 public string Detail="";
}

// Current-frame evidence of all three characters, never NPC/coordinate/HP
// inference. Correlation allows brightness changes; every character must match.
sealed class TownTitleVision {
 readonly double[] title;
 const int Width=56,Height=22;
 public TownTitleVision(string root){
  string file=Path.Combine(root,"templates","town-v4199-full-title.png");
  if(File.Exists(file))using(var b=new Bitmap(file))if(b.Width==Width&&b.Height==Height){
   var pixels=FrameCache.Pixels(b);title=new double[pixels.Length];
   for(int i=0;i<pixels.Length;i++)title[i]=Light(pixels[i]);
  }
 }
 public TownTitleReading Read(Bitmap b){return FrameCache.Get<TownTitleReading>(b,this,"town-title",delegate {
  var v=new TownTitleReading();
  if(title==null||b==null||b.Width!=1216||b.Height!=684){v.Detail="完整盟重标题图样或截图不可用";return v;}
  var pixels=FrameCache.Pixels(b);double best=0,parts=0;
  for(int dy=-3;dy<=3;dy++)for(int dx=-3;dx<=3;dx++){
   double score=Correlation(pixels,1114+dx,37+dy,0,Width);
   if(score<=best)continue;
   double glyph=Math.Min(Correlation(pixels,1114+dx,37+dy,0,19),Math.Min(Correlation(pixels,1114+dx,37+dy,19,18),Correlation(pixels,1114+dx,37+dy,37,19)));
   if(glyph>=.88){best=score;parts=glyph;}
  }
  v.Score=best;v.Town=best>=.94;
  v.Detail="当前帧完整盟重省标题="+best.ToString("0.000")+"；最弱字="+parts.ToString("0.000")+"；阈值0.94/每字0.88";
  return v;
 });}
 static double Light(int p){return (((p>>16)&255)+((p>>8)&255)+(p&255))/3.0;}
 double Correlation(int[] pixels,int x,int y,int left,int width){
  double a=0,b=0,aa=0,bb=0,ab=0,low=255,high=0;int n=width*Height;
  for(int yy=0;yy<Height;yy++)for(int xx=left;xx<left+width;xx++){
   double p=title[yy*Width+xx],q=Light(pixels[(y+yy)*1216+x+xx]);
   a+=p;b+=q;aa+=p*p;bb+=q*q;ab+=p*q;low=Math.Min(low,q);high=Math.Max(high,q);
  }
  double va=aa-a*a/n,vb=bb-b*b/n;
  return high-low<30||va<1||vb<1?0:(ab-a*b/n)/Math.Sqrt(va*vb);
 }
}

partial class Guardian {
 TownTitleVision townTitleVision;
 TownTitleReading ReadTownTitle(Bitmap b){if(townTitleVision==null)townTitleVision=new TownTitleVision(root);return townTitleVision.Read(b);}
}
