using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

partial class Guardian {
 int bossGhostScroll;double bossGhostScrollAt;
 enum BossStage { Idle, Opening, Reading, AwaitingDetail, Challenge, Entering, Fighting, Closing, ClosingWelfare, Hold }
 BossStage bossStage;
 BossVision bossVision;BossCombatVision bossCombatVision;BossCountdownReader bossCountdown;
 BossSchedule bossSchedule;
 BossTextReader bossTitle,bossNameOcr,bossLevelOcr;
 Rectangle bossNameArea,bossLevelArea;
 readonly CheckBox bossEnabled=new CheckBox(),bossPaidEnabled=new CheckBox();
 readonly NumericUpDown bossPaidMinutes=new NumericUpDown();
 readonly Label bossInfo=new Label(),bossTimers=new Label();
 string bossSerial="",bossActive="",bossLastLog="",bossCandidate="",bossPreviousTitle="",bossExpected="";
 bool bossPaid,bossSubmitted,bossWasChallengeMap,bossTeleportConfirmAttempted;
 double bossStageAt,bossTapAt,bossLogAt,bossAdmissionAt=-1,bossCombatAt,bossLastSeenAt;
 int bossTaps,bossCandidateFrames,bossMapFrames,bossClearFrames,bossPromptFrames,bossOldX=-1,bossOldY=-1;
 long bossLastFrame=-1;
 double bossCombatEvidenceAt;int bossCombatEvidenceCount;
 double bossArrivalPanelAt=-1;bool bossArrivalPanelWarned;
 double bossTownSeenAt=-1,bossUnknownSceneAt=-1;
 string bossTitleReadDetail="尚未读取",bossSceneEvidence="尚未检查";
 long bossSceneFrame=-1;
 WelfareDetector bossWelfareDetector;int bossWelfareKind;
 string bossWaitReason="尚未检查",bossWaitDetail="",bossWaitLogged="";double bossWaitLoggedAt=-100;
 bool BossOwnsWindow {get{return bossStage!=BossStage.Idle;}}
 double BossNow {get{return traceClock.Elapsed.TotalSeconds;}}
 void InitBoss(Control top){
  bossEnabled.Text="BOSS优先（启动检查及计时）";bossEnabled.Checked=true;bossEnabled.AutoSize=true;
  bossPaidEnabled.Text="允许挑战令";bossPaidEnabled.Checked=true;bossPaidEnabled.AutoSize=true;
  bossPaidMinutes.Minimum=10;bossPaidMinutes.Maximum=1440;bossPaidMinutes.Value=60;bossPaidMinutes.Width=55;
  top.Controls.Add(bossEnabled);top.Controls.Add(bossPaidEnabled);top.Controls.Add(new Label{Text="同一BOSS资源挑战间隔≥",AutoSize=true,Padding=new Padding(0,6,0,0)});top.Controls.Add(bossPaidMinutes);top.Controls.Add(new Label{Text="分钟",AutoSize=true,Padding=new Padding(0,6,0,0)});
  bossInfo.AutoSize=true;bossInfo.MaximumSize=new Size(835,0);bossInfo.Text="BOSS：启动读取配置BOSS的倒计时；挑战令可用优先";top.Controls.Add(bossInfo);
  bossTimers.AutoSize=true;bossTimers.MaximumSize=new Size(835,0);bossTimers.Text="BOSS计时：等待启动读取";top.Controls.Add(bossTimers);
  bossEnabled.CheckedChanged+=(s,e)=>{if(!bossEnabled.Checked){ResetBoss();Log("BOSS调度已关闭；当前游戏界面交回原守护");}else if(guardRequested)StartBoss();};
  bossPaidMinutes.ValueChanged+=(s,e)=>{if(bossSchedule!=null){bossSchedule=new BossSchedule(data,bossSerial,(int)bossPaidMinutes.Value,BossTargets.Load(root));Log("BOSS挑战间隔已修改；已经预留的挑战冷却仍保留");}};
 }
 void ResetBoss(){bossResumeFlow.Reset();bossResumeMap="";bossResumeFrame=-1;
  bossTownSeenAt=bossUnknownSceneAt=-1;bossSceneFrame=-1;bossSceneEvidence="尚未检查";bossTitleReadDetail="尚未读取";
  bossStage=BossStage.Idle;bossSchedule=null;bossActive="";bossSubmitted=bossWasChallengeMap=bossTeleportConfirmAttempted=false;bossCandidateFrames=bossMapFrames=bossClearFrames=bossPromptFrames=0;bossAdmissionAt=-1;bossLastFrame=-1;bossWaitReason="尚未检查";bossWaitDetail=bossWaitLogged="";bossWaitLoggedAt=-100;
  if(bossCountdown!=null)bossCountdown.Reset();if(bossTitle!=null)bossTitle.Reset();if(bossNameOcr!=null)bossNameOcr.Reset();if(bossLevelOcr!=null)bossLevelOcr.Reset();
 }
 void DisposeBoss(){if(bossCountdown!=null)bossCountdown.Dispose();if(bossTitle!=null)bossTitle.Dispose();if(bossNameOcr!=null)bossNameOcr.Dispose();if(bossLevelOcr!=null)bossLevelOcr.Dispose();}
 void StartBoss(){ResetBoss();if(!bossEnabled.Checked)return;bossSerial=backend.Serial??"";if(bossSerial.Length==0)return;bossSchedule=new BossSchedule(data,bossSerial,(int)bossPaidMinutes.Value,BossTargets.Load(root));BossLog("启动目标="+String.Join("、",bossSchedule.Records.Select(r=>r.Name).ToArray())+"；挑战令可用优先；目标状态独立调度；倒计时每60秒校准，临近15秒加密检查",true);}
 RouteTextLocator ghostBossLocator;Rectangle ghostBossArea;
 BossView ReadBoss(Bitmap b){if(bossVision==null)bossVision=new BossVision(root);var view=bossVision.Read(b);if(view.List&&!view.Rows.Any(row=>row.Name=="游荡鬼王")){if(ghostBossLocator==null||ghostBossArea!=view.NameSearchRect){if(ghostBossLocator!=null)ghostBossLocator.Dispose();ghostBossArea=view.NameSearchRect;ghostBossLocator=new RouteTextLocator(ghostBossArea,true);}Point point;string word,why;if(ghostBossLocator.TryFind(b,new[]{"游荡鬼王"},out point,out word,out why))bossVision.ReadGhostRow(b,view,point);}return view;}
 BossCombatView ReadBossCombat(Bitmap b){if(bossCombatVision==null)bossCombatVision=new BossCombatVision(root);return bossCombatVision.Read(b);}
 string BossTitle(Bitmap b){if(bossTitle==null)bossTitle=new BossTextReader(StrictMapTitleReader.TitleRectangle);string text,why;bool ok=bossTitle.TryRead(b,out text,out why);bossTitleReadDetail=why;return ok?text:"";}
 void BossLog(string s,bool force=false){engine.Status="BOSS："+s;bossInfo.Text=engine.Status;if(force||s!=bossLastLog||BossNow-bossLogAt>=30){Log(engine.Status);TraceEvent("boss_state","stage",bossStage.ToString(),"boss",bossActive,"paid",bossPaid,"submitted",bossSubmitted,"detail",s);bossLastLog=s;bossLogAt=BossNow;}}
 void BossSet(BossStage stage){if(stage==BossStage.Reading){bossGhostScroll=0;bossGhostScrollAt=BossNow;}bossStage=stage;bossStageAt=BossNow;bossTaps=0;bossTapAt=-100;bossPromptFrames=bossMapFrames=bossClearFrames=bossCandidateFrames=0;bossCandidate="";bossLastFrame=-1;bossTownSeenAt=bossUnknownSceneAt=-1;if(stage==BossStage.Fighting){bossCombatEvidenceAt=BossNow;bossCombatEvidenceCount=0;}}
 bool BossTap(Bitmap b,Point point,string reason){bossTaps++;bossTapAt=BossNow;TraceBeforeAction(b,"BOSS："+reason);bool sent=Click(point);TraceEvent("boss_input","stage",bossStage.ToString(),"boss",bossActive,"point",point,"attempt",bossTaps,"sent",sent,"reason",reason);BossLog(reason+(sent?"；等待新截图":"；输入结果未确认，等待反馈"),true);return sent;}
 bool BossFresh(){if(traceFrame==bossLastFrame)return false;if(bossLastFrame>=0&&(traceFrame!=bossLastFrame+1||BossNow-bossLastSeenAt>5)){bossPromptFrames=bossCandidateFrames=bossMapFrames=bossClearFrames=0;}bossLastSeenAt=BossNow;bossLastFrame=traceFrame;return true;}
 void BossEnd(string reason,Bitmap b,bool diagnostic,bool closeWindow=true){if(hellEnabled.Checked&&mapPriority.CurrentLevel>=80&&!bossResumeFlow.Active){bossResumeMap=bossExpected;bossResumeFlow.Start(BossNow);Log("BOSS任务结束：锁定冥界28:52 → 鬼门关；完成恢复前禁止普通地图兜底");}
  if(diagnostic)SaveDiagnostic(b,-1,"boss-"+bossStage.ToString().ToLowerInvariant());
  if(bossSchedule!=null){if(bossActive.Length>0)bossSchedule.MarkAttemptEnded(bossActive,DateTimeOffset.UtcNow,reason);else bossSchedule.Delay(DateTimeOffset.UtcNow,60);}
  BossLog(reason,true);bossActive="";bossSubmitted=false;BossSet(closeWindow?BossStage.Closing:BossStage.Idle);bossAdmissionAt=-1;InvalidateMaintenanceObservation();ResetAutoBattle();
 }
 bool BossWaitingForAdmission(){return bossEnabled.Checked&&bossSchedule!=null&&(BossOwnsWindow||bossSchedule.Due(DateTimeOffset.UtcNow));}
 void BossWait(string reason,string detail){
  bossWaitReason=reason;bossWaitDetail=detail;
  if((reason!=bossWaitLogged&&BossNow-bossWaitLoggedAt>=3)||BossNow-bossWaitLoggedAt>=20){bossWaitLogged=reason;bossWaitLoggedAt=BossNow;TraceEvent("boss_wait","stage",bossStage.ToString(),"reason",reason,"detail",detail);BossLog("等待："+reason+"；"+detail,true);}
 }
 void BossAdoptList(Bitmap b,BossView view,bool preserveOrigin=false){
  if(!preserveOrigin){bossPreviousTitle=BossTitle(b);string coord;if(!TryReadCoord(b,out bossOldX,out bossOldY,out coord))bossOldX=bossOldY=-1;}
  InvalidateMaintenanceObservation();BossSet(BossStage.Reading);bossAdmissionAt=-1;
  BossLog((view.List?"已确认BOSS奖励列表，读取配置目标计时":"已确认BOSS窗口外框，等待列头恢复；超时只关闭窗口")+"；"+view.Detail,true);
 }
 WelfareReading BossWelfare(Bitmap b,int kind){if(bossWelfareDetector==null)bossWelfareDetector=new WelfareDetector(root);return bossWelfareDetector.ReadCloseOnly(b,kind);}
 void BossSaveScan(DateTimeOffset utc){
  bossSchedule.MarkScanComplete(utc);
  string summary=String.Join("；",bossSchedule.Records.Select(r=>r.Name+"="+(r.Status=="Ready"?"已刷新":r.Status=="Challenge"?"可挑战":r.Status=="Countdown"?"倒计时":"待核对")+(r.DueTicks>0?"，预计刷新="+new DateTimeOffset(r.DueTicks,TimeSpan.Zero).ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss"):"")).ToArray());
  BossLog("计时记录："+summary+"；空闲时下次核对="+bossSchedule.NextPollUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss")+(String.IsNullOrEmpty(bossSchedule.LastError)?"；保存成功":"；保存异常="+bossSchedule.LastError),true);
 }
 void UpdateBossTimers(){
  if(bossSchedule==null)return;var now=DateTimeOffset.UtcNow;
  bossTimers.Text=String.Join(" ｜ ",bossSchedule.Records.Select(r=>{string status=r.Status=="Ready"?"上次已刷新":r.Status=="Challenge"?"上次可挑战":"待核对";if(r.DueTicks>0){var due=new DateTimeOffset(r.DueTicks,TimeSpan.Zero);status="预计"+due.ToLocalTime().ToString("HH:mm:ss")+(due<=now?"（待复核）":"");}return r.Name+"："+status;}).ToArray());
 }
 bool HandleBoss(Bitmap b){
  if(!guardRequested||!engine.Running||!bossEnabled.Checked||coordCalibration.Active)return false;
  LoadMapPriority();
  if(bossSchedule==null||bossSerial!=(backend.Serial??""))StartBoss();if(bossSchedule==null)return false;UpdateBossTimers();
  double now=BossNow;DateTimeOffset utc=DateTimeOffset.UtcNow;
  if(bossStage==BossStage.Idle){if(bossResumeFlow.Active){BossWait("上一轮BOSS结束，先恢复鬼门关",bossResumeMap);return false;}
   if(ReadTownTitle(b).Town||BossTitle(b)=="盟重省"||CalibrationMap(b)==0){BossWait("盟重下图优先，BOSS检查等待入图","不打开BOSS列表、不启动福利；现有窗口由原流程关闭");return false;}
   int routeMap=CalibrationMap(b);
   if(routeMap>0&&routeMap<4&&!(routeMap==3&&mapPriority.CanUseBossFallback(DateTime.Now))){BossWait("路线下图优先，BOSS检查等待进入刷怪地图","路线地图="+routeMap+"；各图限时寻找；神龙帝国超过5分钟无入图时允许BOSS备用入口");return false;}
   if(maintenanceTask!=null){BossWait("已开始的维护先完成有界收尾","周期计时检查不取消领取；最长210秒，确认盟重时维护仍会取消");return false;}
   if(!bossSchedule.Due(utc)){
    var blocked=ReadBoss(b);
    if(blocked.TeleportPrompt||blocked.ListShell||blocked.SuspectedList||blocked.Challenge){BossWait("BOSS窗口冷却中，暂停其他流程点击",blocked.Detail);return true;}
    return false;
   }
   if(bossAdmissionAt<0)bossAdmissionAt=now;
   if(now-bossAdmissionAt>20){bossSchedule.Delay(utc,30);bossAdmissionAt=-1;BossLog("入口检查20秒未就绪，30秒后补查；阻塞="+bossWaitReason+"；"+bossWaitDetail,true);SaveDiagnostic(b,-1,"boss-admission-timeout");return false;}
   if(CleanupMaintenance(b,ClockSeconds()))return true;
   // Recognize an already-open BOSS window before testing the dimmed HUD.
   // A positive shell may be closed even when row recognition is incomplete.
   var view=ReadBoss(b);
   if(view.TeleportPrompt){BossSet(BossStage.Closing);BossLog("发现没有对应进入任务的传送提示，取消后重新读取列表",true);return true;}
   if(view.List||view.ListShell||view.SuspectedList){BossAdoptList(b,view);return true;}
   if(view.Challenge){BossSet(BossStage.Closing);BossLog("发现没有对应进入任务的BOSS挑战详情，仅关闭恢复，不提交挑战；"+view.Detail,true);return true;}
   if(recycle.Stage!=0||priorityEntryDeadline>DateTime.Now||engine.Pending>=0){BossWait("已有回收或传送尚未结束","回收="+recycle.Stage+" 待传送="+engine.Pending+" 进入期限="+priorityEntryDeadline.ToString("HH:mm:ss"));return false;}
   // Startup inside a challenge must never spend another ticket or navigate
   // away. Reconnect resumes combat observation, with no inferred kill result.
   if(ReadBossCombat(b).ChallengeMap){bossActive="当前BOSS";bossExpected="BOSS挑战";bossWasChallengeMap=true;bossCombatAt=now;BossSet(BossStage.Fighting);ResetAutoBattle();BossLog("检测到已在BOSS挑战图，恢复自动战斗与收尾保护",true);return true;}
   var bag=recycleVision.Read(b);var mini=ReadMinimap(b);
   if(farmPopupDetector==null)farmPopupDetector=new FarmPopupDetector(Path.Combine(root,"templates"));var popup=farmPopupDetector.Read(b,true);
   if(popup.Panel){
    for(int kind=0;kind<3;kind++){var welfare=BossWelfare(b,kind);if(welfare.Panel&&welfare.Close.HasValue){bossWelfareKind=kind;BossSet(BossStage.ClosingWelfare);InvalidateMaintenanceObservation();BossTap(b,welfare.Close.Value,"关闭阻挡BOSS检查的已确认福利窗口；"+welfare.Detail);return true;}}
    BossWait("其他弹窗遮挡","弹窗="+popup.Name+"；"+popup.Detail);return false;
   }
   if(popup.MapDetail||IsEntryDetailVisible(b)){BossWait("地图详情尚未结束",popup.Detail);return false;}
   // The complete BOSS icon+label and expanded minimap identify the HUD.
   // The independent bag shortcut can hide during combat without blocking
   // that visible BOSS entry; actual bag/recycle pages still veto admission.
   if(bag.Bag||bag.Page||mini.State!=MinimapState.Expanded||!view.Entry.HasValue){
    BossWait("主画面入口证据不足","背包入口="+bag.Icon+" 背包窗口="+bag.Bag+" 回收窗口="+bag.Page+" 小地图="+mini.State+" BOSS入口="+view.Entry.HasValue+"；"+view.Detail);return false;
   }
   bossPreviousTitle=BossTitle(b);string cd;if(!TryReadCoord(b,out bossOldX,out bossOldY,out cd))bossOldX=bossOldY=-1;
   InvalidateMaintenanceObservation();BossSet(BossStage.Opening);bossAdmissionAt=-1;BossTap(b,view.Entry.Value,(routeMap==3?"神龙下图超过5分钟，启用BOSS备用入口；":"")+"打开BOSS奖励，读取刷新时间");return true;
  }
  bool fresh=BossFresh();var seen=ReadBoss(b);
  if(bossStage==BossStage.Opening){
   if(seen.List||seen.ListShell||seen.SuspectedList){BossAdoptList(b,seen,true);return true;}
   BossWait("等待BOSS列表打开",seen.Detail);
   if(now-bossStageAt>15){BossEnd("15秒内未确认奖励列表，结束本轮并冷却；"+seen.Detail,b,true);return true;}
   if(bossTaps<2&&now-bossTapAt>4&&seen.Entry.HasValue)BossTap(b,seen.Entry.Value,"再次打开已确认的BOSS奖励入口");return true;
  }
  if(bossStage==BossStage.Reading){
   if(!seen.List){BossWait("BOSS列头未完整确认",seen.Detail);if(now-bossStageAt>18)BossEnd("BOSS列表未读清，本轮不进入；"+seen.Detail,b,true);return true;}
   if(bossCountdown==null)bossCountdown=new BossCountdownReader();int readable=0;
   foreach(var row in seen.Rows){if(bossSchedule.Find(row.Name)==null)continue;int seconds;DateTimeOffset at;string detail;
    if(row.Status==BossRowStatus.Countdown){if(bossCountdown.TryRead(b,row.Name,row.CountdownRect,out seconds,out at,out detail)){bool changed=bossSchedule.Observe(row.Name,row.Status,at,seconds,utc);readable++;if(changed)TraceEvent("boss_countdown","boss",row.Name,"seconds",seconds,"observed_at",at.ToString("o"),"due",at.AddSeconds(seconds).ToLocalTime().ToString("o"),"evidence",detail);}}
    else if(row.Status==BossRowStatus.Ready||row.Status==BossRowStatus.Challenge){bossSchedule.Observe(row.Name,row.Status,utc,null,utc);readable++;}
   }
   if(bossSchedule.Find("游荡鬼王")!=null&&mapPriority.CurrentLevel>=80&&!seen.Rows.Any(row=>row.Name=="游荡鬼王")&&bossGhostScroll<3&&now-bossStageAt<=16){
    if(fresh&&now-bossGhostScrollAt>=3){TraceBeforeAction(b,"BOSS列表：有限滚动寻找游荡鬼王");if(Swipe(new Point(800,530),new Point(800,300),400)){bossGhostScroll++;bossGhostScrollAt=now;bossCandidateFrames=0;BossLog("列表下方检查游荡鬼王；滚动"+bossGhostScroll+"/3；只按实际完整名称识别",true);}}return true;
   }
   bool all=readable>=bossSchedule.Records.Count(record=>BossTargets.MinLevel(record.Name)==0||mapPriority.CurrentLevel>=BossTargets.MinLevel(record.Name));
   if(!all)BossWait("部分BOSS状态待核对；已确认目标可独立调度","已读="+readable+"/"+bossSchedule.TargetCount+"；"+seen.Detail);
   var candidate=bossSchedule.Select(seen.Rows,utc,bossPaidEnabled.Checked,mapPriority.CurrentLevel);
   if(candidate!=null&&fresh){string id=candidate.Name+candidate.Status+candidate.Button.ToString();bossCandidateFrames=id==bossCandidate?bossCandidateFrames+1:1;bossCandidate=id;
    if(bossCandidateFrames>=2&&(all||now-bossStageAt>=8)){
     bossActive=candidate.Name;bossPaid=candidate.Status==BossRowStatus.Challenge;bossExpected=BossTargets.Map(bossActive);bossSubmitted=false;bossWasChallengeMap=false;bossTeleportConfirmAttempted=false;
     BossSaveScan(utc);
     // A row action navigates to a prompt/NPC, not a resource submission.
     // Reserve immediately before the actual entry action, after its costs
     // are known, so a natural row can safely lead to a paid detail.
     BossSet(BossStage.AwaitingDetail);
     BossTap(b,candidate.Button.Value,"选中"+bossActive+"："+(bossPaid?"前往挑战，先核对条件":"已刷新，前往击杀"));return true;
    }
   }else if(candidate==null){bossCandidateFrames=0;bossCandidate="";}
   if((all&&candidate==null&&now-bossStageAt>=3)||now-bossStageAt>18){
    BossSaveScan(utc);
    if(!all)SaveDiagnostic(b,-1,"boss-list-incomplete");BossSet(BossStage.Closing);
   }return true;
  }
  if(bossStage==BossStage.AwaitingDetail){
   if(now-bossStageAt>25){BossEnd("选中BOSS后25秒未完成传送确认或详情打开；结束本轮；"+seen.Detail,b,true);return true;}
   if(HandleBossTeleportPrompt(b,seen,fresh))return true;
   if(seen.Challenge){BossSet(BossStage.Challenge);BossLog("已打开BOSS挑战详情；重新核对完整名称、绿色等级和实际消耗",true);return true;}
   if(HandleBossMapDetail(b,fresh,utc))return true;
   if(BossObserveArrival(b,seen,fresh,now,utc))return true;
   BossWait("等待BOSS传送提示、挑战详情或实际地图",seen.Detail);return true;
  }
  if(bossStage==BossStage.Challenge){
   // The native confirmation may be shown before the challenge detail. Own
   // it here so a dimmed list cannot be mistaken for a lost challenge state.
   if(now-bossStageAt>15){BossEnd("挑战条件或名称未确认，未消耗挑战令；结束本轮",b,true);return true;}
   if(HandleBossTeleportPrompt(b,seen,fresh))return true;
   if(!seen.Challenge){bossCandidateFrames=0;BossWait("等待挑战详情完整显示",seen.Detail);return true;}
   string name=seen.ChallengeName,detail;
   if(name.Length==0){if(bossNameOcr==null||bossNameArea!=seen.ChallengeNameRect){if(bossNameOcr!=null)bossNameOcr.Dispose();bossNameArea=seen.ChallengeNameRect;bossNameOcr=new BossTextReader(bossNameArea);}bossNameOcr.TryRead(b,out name,out detail);}
   bool green=seen.ChallengeLevelGreen&&seen.ChallengeRequiredLevel>=BossTargets.MinLevel(bossActive);
   if(!green&&BossGreenCondition(b,seen.ChallengeLevelRect)){
    if(bossLevelOcr==null||bossLevelArea!=seen.ChallengeLevelRect){if(bossLevelOcr!=null)bossLevelOcr.Dispose();bossLevelArea=seen.ChallengeLevelRect;bossLevelOcr=new BossTextReader(bossLevelArea);}string level;
    bool readLevel=bossLevelOcr.TryRead(b,out level,out detail);var match=Regex.Match(level??"","^等级达到([0-9]{2,3})级$");
    green=readLevel&&match.Success&&Int32.Parse(match.Groups[1].Value)>=BossTargets.MinLevel(bossActive);
   }
   bool levelEligible=BossTargets.MinLevel(bossActive)==0||mapPriority.CurrentLevel>=BossTargets.MinLevel(bossActive);
   bool good=name==bossActive&&green&&levelEligible&&seen.ChallengeCostsVisible&&seen.ChallengeActionPoint.HasValue&&bossPaidEnabled.Checked&&bossSchedule.AllowsPaid(bossActive);
   if(fresh)bossCandidateFrames=good?bossCandidateFrames+1:0;
   if(!good){BossWait("挑战名称/条件/消耗核对","当前名称="+name+" 目标="+bossActive+" 等级通过="+green+" 允许资源="+bossPaidEnabled.Checked+"；"+seen.Detail);return true;}
   if(bossCandidateFrames<2)return true;
   if(!bossSchedule.Reserve(bossActive,true,utc)){BossEnd("挑战记录无法预留或仍在冷却："+bossSchedule.LastError,b,true);return true;}
   bossPaid=true;bossSubmitted=true;BossSet(BossStage.Entering);BossTap(b,seen.ChallengeActionPoint.Value,"我要挑战"+bossActive+"；金币20000+元宝50+挑战令1；本次只提交一次");return true;
  }
  if(bossStage==BossStage.Entering){
   // Natural rows continue directly to the target map; challenge rows may
   // continue to a challenge detail. In either case the confirmation is a
   // one-shot input, followed only by fresh-frame observation.
   if(BossObserveArrival(b,seen,fresh,now,utc))return true;
   if(now-bossStageAt>22){var combat=ReadBossCombat(b);if(combat.ChallengeMap&&!seen.Challenge&&!seen.TeleportPrompt){bossWasChallengeMap=true;bossCombatAt=now;BossSet(BossStage.Hold);BossLog("进入反馈不完整，保持当前BOSS图，不重复扣资源",true);}else BossEnd("进入22秒未确认；本次不重交进入指令",b,true);return true;}
   if(HandleBossTeleportPrompt(b,seen,fresh))return true;
   BossWait("进入指令已提交，等待实际地图",seen.Detail);return true;
  }
  if(bossStage==BossStage.Fighting||bossStage==BossStage.Hold){return BossFight(b,seen,fresh);}
  if(bossStage==BossStage.ClosingWelfare){
   if(seen.List||seen.ListShell){BossAdoptList(b,seen);return true;}
   var welfare=BossWelfare(b,bossWelfareKind);
   if(welfare.Panel){bossClearFrames=0;if(welfare.Close.HasValue&&bossTaps<2&&now-bossTapAt>3)BossTap(b,welfare.Close.Value,"再次关闭已确认的福利窗口；"+welfare.Detail);}
   else if(fresh&&ReadBoss(b).Entry.HasValue&&recycleVision.Read(b).Icon)bossClearFrames++;
   if(bossClearFrames>=2){bossStage=BossStage.Idle;bossAdmissionAt=-1;InvalidateMaintenanceObservation();BossLog("已确认福利窗口关闭，继续BOSS计时检查",true);}
   else if(now-bossStageAt>12){bossStage=BossStage.Idle;bossAdmissionAt=-1;bossSchedule.Delay(utc,30);BossLog("福利窗口12秒关闭未确认，30秒后补查；"+welfare.Detail,true);SaveDiagnostic(b,-1,"boss-welfare-close-timeout");}
   return true;
  }
  if(bossStage==BossStage.Closing){
   Point? close=seen.TeleportPrompt?seen.TeleportCancel:seen.Close;
   if(!close.HasValue&&!seen.TeleportPrompt){Point mapClose;if(upgradeMapVision.FindDialogClose(b,out mapClose))close=mapClose;}
   if(close.HasValue){bossClearFrames=0;if(now-bossStageAt<=12&&bossTaps<2&&now-bossTapAt>3)BossTap(b,close.Value,seen.TeleportPrompt?"取消未完成的BOSS传送提示":"关闭已确认的BOSS窗口");}
   else if(fresh){if(!seen.TeleportPrompt&&!seen.List&&!seen.ListShell&&!seen.SuspectedList&&!seen.Challenge&&recycleVision.Read(b).Icon)bossClearFrames++;else bossClearFrames=0;}
   if(bossClearFrames>=2||now-bossStageAt>12){bool clear=bossClearFrames>=2;BossLog(clear?"已确认BOSS窗口关闭":"BOSS窗口12秒关闭未确认，30秒后复核；"+seen.Detail,true);bossStage=BossStage.Idle;bossAdmissionAt=-1;InvalidateMaintenanceObservation();if(!clear)bossSchedule.Delay(utc,30);else if(bossSchedule.Due(utc))bossSchedule.Delay(utc,3);}return true;
  }return false;
 }
 bool HandleBossTeleportPrompt(Bitmap b,BossView seen,bool fresh){
  if(!seen.TeleportPrompt){bossPromptFrames=0;return false;}
  if(!seen.TeleportConfirm.HasValue){bossPromptFrames=0;BossWait("等待BOSS传送确认控件",seen.Detail);return true;}
  if(!bossTeleportConfirmAttempted){
   if(fresh)bossPromptFrames++;if(bossPromptFrames<2){BossWait("传送确认框等待第二帧",seen.Detail);return true;}
   // Mark before sending input. A stale frame or an unconfirmed click must
   // never cause the native modal to be clicked repeatedly.
   bossTeleportConfirmAttempted=true;
   BossTap(b,seen.TeleportConfirm.Value,"确认BOSS立即传送至地图NPC处；本次只点击一次");
   BossLog("已确认BOSS传送提示；等待挑战详情或实际地图",true);
  }else BossWait("等待BOSS传送结果","已点击确定一次；等待挑战详情或实际地图；"+seen.Detail);
  return true;
 }
 bool HandleBossMapDetail(Bitmap b,bool fresh,DateTimeOffset utc){
  var map=upgradeMapVision.ReadDialog(b);Point shellClose;
  if(!map.Enter.HasValue&&!upgradeMapVision.FindDialogClose(b,out shellClose)){bossCandidateFrames=0;return false;}
  bool good=map.Present&&map.Name==bossExpected&&map.Requirements=="green"&&map.Enter.HasValue;
  if(fresh)bossCandidateFrames=good?bossCandidateFrames+1:0;
  if(!good){BossWait("地图详情名称与进入条件核对",map.Detail);return true;}
  if(bossCandidateFrames<2)return true;
  if(!bossSchedule.Reserve(bossActive,false,utc)){BossEnd("地图进入记录保存失败或冷却中："+bossSchedule.LastError,b,true);return true;}
  bossPaid=false;bossSubmitted=true;BossSet(BossStage.Entering);BossTap(b,map.Enter.Value,"进入地图"+bossExpected+"；完整名称和绿色条件通过，本次只提交一次");return true;
 }
 bool BossObserveArrival(Bitmap b,BossView seen,bool fresh,double now,DateTimeOffset utc){
  var combat=ReadBossCombat(b);string title=BossTitle(b);bool good=false;
  bool challengeMap=combat.ChallengeMap||title=="BOSS挑战";
  // A submitted challenge may leave its detail panel on top of the arrived
  // map. The full current map title is independent from the panel title.
  bool submittedResidual=bossSubmitted&&bossStage==BossStage.Entering&&seen.Challenge;
  if(!seen.TeleportPrompt&&!seen.List&&!seen.ListShell&&!seen.SuspectedList&&(!seen.Challenge||submittedResidual)){if(challengeMap)good=true;else if(!bossPaid&&title==bossExpected){int x,y;string why;good=bossPreviousTitle!=bossExpected&&bossPreviousTitle.Length>0||TryReadCoord(b,out x,out y,out why)&&bossOldX>=0&&bossOldY>=0&&Math.Abs(x-bossOldX)+Math.Abs(y-bossOldY)>=5;}}
  if(fresh)bossMapFrames=good?bossMapFrames+1:0;
  if(bossMapFrames<2)return false;
  if(!bossSubmitted){bossSchedule.Reserve(bossActive,false,utc);bossSubmitted=true;}
  bossWasChallengeMap=challengeMap;bossCombatAt=now;BossSet(BossStage.Fighting);bossArrivalPanelAt=-1;bossArrivalPanelWarned=false;ResetAutoBattle();BossLog("已确认进入"+(challengeMap?"BOSS挑战":bossExpected)+(seen.Challenge?"；挑战详情残留，先关闭已确认的详情，再核对自动；不重复提交资源":"，核对右侧自动开关"),true);return true;
 }
 static bool BossGreenCondition(Bitmap b,Rectangle area){if(area.Width<=0||area.Height<=0)return false;var px=FrameCache.Pixels(b);int green=0,red=0;for(int y=area.Top;y<area.Bottom;y++)for(int x=area.Left;x<area.Right;x++){int p=px[y*1216+x],r=(p>>16)&255,g=(p>>8)&255,blue=p&255;if(g>110&&g>r*1.4&&g>blue*1.3)green++;if(r>130&&r>g*1.5&&r>blue*1.5)red++;}return green>=100&&red<8;}
 bool BossFight(Bitmap b,BossView seen,bool fresh){
  if(seen.TeleportPrompt){
   if(bossArrivalPanelAt<0)bossArrivalPanelAt=BossNow;
   if(BossNow-bossArrivalPanelAt>45){BossEnd("额外传送提示持续45秒，结束本轮并有限关闭；不重交挑战",b,true);return true;}
   if(seen.TeleportCancel.HasValue&&bossTaps<2&&BossNow-bossTapAt>4)BossTap(b,seen.TeleportCancel.Value,"战斗中取消额外的传送提示");return true;
  }
  if(seen.List||seen.ListShell||seen.SuspectedList||seen.Challenge){
   if(bossArrivalPanelAt<0)bossArrivalPanelAt=BossNow;
   if(fresh)bossClearFrames=bossMapFrames=0;
   if(BossNow-bossArrivalPanelAt<=12&&seen.Close.HasValue&&BossNow-bossTapAt>4&&bossTaps<2)BossTap(b,seen.Close.Value,seen.Challenge?"已入图，关闭残留挑战详情；不点击我要挑战":"战斗期间关闭BOSS列表，恢复视野");
   if(BossNow-bossArrivalPanelAt>12&&!bossArrivalPanelWarned){bossArrivalPanelWarned=true;SaveDiagnostic(b,-1,"boss-arrival-panel-unclosed");BossLog("已入BOSS图，但残留窗口12秒未关闭；两次关闭预算已结束，等待界面恢复，不重交挑战、不记为入图失败",true);}
   if(BossNow-bossArrivalPanelAt>45){BossEnd("残留BOSS窗口持续45秒，释放战斗占用并有限关闭；保留资源冷却，不重复挑战",b,true);return true;}
   return true;
  }
  bossArrivalPanelAt=-1;bossArrivalPanelWarned=false;
  var combat=ReadBossCombat(b);var town=ReadTownTitle(b);string title=BossTitle(b);
  bool inTown=!combat.ChallengeMap&&(town.Town||title=="盟重省");
  bossSceneFrame=traceFrame;
  bossSceneEvidence=town.Detail+"；OCR="+(title.Length>0?title:bossTitleReadDetail)+"；"+combat.Detail;
  // Synchronous full-word evidence does not depend on an async OCR result
  // matching every background pixel. Pending OCR may bridge at most five
  // seconds; a positive other title/challenge frame invalidates it immediately.
  if(fresh){
   if(inTown){bossClearFrames++;bossTownSeenAt=BossNow;}
   else if(combat.ChallengeMap||title.Length>0||bossTownSeenAt<0||BossNow-bossTownSeenAt>5){bossClearFrames=0;bossTownSeenAt=-1;}
  }
  if(bossClearFrames>=2){
   TraceEvent("boss_return_confirmed","evidence_frame",bossSceneFrame,"evidence",bossSceneEvidence,"confirmations",bossClearFrames);
   BossEnd("两张新截图确认已回到盟重；释放BOSS占用，立即恢复普通下图；仅记录回城，不判定击杀结果",b,false,false);return false;
  }
  if(inTown){bossMapFrames=0;bossUnknownSceneAt=-1;BossLog("当前帧已确认盟重省，等待第二张新截图；"+bossSceneEvidence);return true;}
  bool mapGood=bossWasChallengeMap?combat.ChallengeMap||title=="BOSS挑战":title==bossExpected;
  if(fresh)bossMapFrames=mapGood?bossMapFrames+1:0;
  if(mapGood)bossUnknownSceneAt=-1;
  else if(bossUnknownSceneAt<0)bossUnknownSceneAt=BossNow;
  if(bossUnknownSceneAt>=0&&BossNow-bossUnknownSceneAt>=45){
   TraceEvent("boss_scene_timeout","seconds",BossNow-bossUnknownSceneAt,"evidence_frame",bossSceneFrame,"evidence",bossSceneEvidence);
   BossEnd("BOSS场景连续45秒无法确认；释放占用，交回地图识别和下图；保留资源冷却，不判断击杀、不手动回城；"+bossSceneEvidence,b,true,false);
   if(bossSchedule!=null)bossSchedule.Delay(DateTimeOffset.UtcNow,60);return false;
  }
  // Count unknown time even while minimap/popup recovery consumes frames.
  if(CloseFarmPopup(b)||CloseBoxPopup(b)||CloseOpenPanel(b)||EnsureMinimapVisible(b))return true;
  if(bossCombatEvidenceCount<6&&BossNow>=bossCombatEvidenceAt){SaveDiagnostic(b,-1,"boss-combat-observe");bossCombatEvidenceCount++;bossCombatEvidenceAt=BossNow+60;}
  if(bossMapFrames>=2){if(TryRandomEscape(b,4,true))return true;CheckAuto(b,true);}
  if(BossNow-bossCombatAt>600&&!bossWasChallengeMap&&bossMapFrames>=2){if(hellEnabled.Checked&&mapPriority.CurrentLevel>=80){bossResumeMap=bossExpected;bossResumeFlow.Start(BossNow);Log("自然BOSS观察预算结束，安排返回鬼门关；保留拾取时间，不将超时判为击杀；地图="+bossResumeMap);}BossEnd("自然刷新地图观察满10分钟，结束本轮占用；80级按设置恢复鬼门关",b,false,false);return true;}
  if(BossNow-bossCombatAt>600&&bossStage!=BossStage.Hold){BossSet(BossStage.Hold);SaveDiagnostic(b,-1,"boss-wait-system-return");BossLog("战斗观察超过10分钟；继续保持自动，等待游戏系统回城；实际回到盟重后再检查其他BOSS",true);}
  else if(BossNow-bossLogAt>30)BossLog(bossActive+"："+(bossMapFrames>=2?"已在BOSS场景；保持自动；等待游戏系统回城":"场景暂未确认；已等待"+(bossUnknownSceneAt<0?0:BossNow-bossUnknownSceneAt).ToString("0")+"/45秒")+"；证据帧="+bossSceneFrame+"；"+bossSceneEvidence+"；其他BOSS计时保留",true);
  return true;
 }
}



