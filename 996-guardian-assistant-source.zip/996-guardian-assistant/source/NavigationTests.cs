using System;
using System.IO;
using System.Text;
using System.Drawing;

partial class Guardian {
 public void NavigationSmoke(){
  timer.Stop();
  Point target=new Point(312,333),current=new Point(320,333),chosen;
  var walk=new WalkProgress();
  FocusAssert(!WalkProgress.AtGoal(current,target),"320:333不能提前当成312:333到达");
  coordDirDx=new[]{0,1,1,1,0,-1,-1,-1};coordDirDy=new[]{-1,-1,0,1,1,1,0,-1};
  int moves=0;DateTime now=DateTime.Now;
  while(current!=target&&moves<15){
   FocusAssert(walk.SearchTarget(current,target,now,out chosen)&&chosen==target,"未到指定坐标必须继续接近");
   int dir,ms;Point to;string why;
   FocusAssert(SelectWalkingStep(current,chosen,walk,new Point(160,514),out dir,out to,out ms,out why),"应选出已校准的移动方向");
   int dx=(int)Math.Round(coordDirDx[dir]*ms/550.0),dy=(int)Math.Round(coordDirDy[dir]*ms/550.0);
   FocusAssert(dx!=0||dy!=0,"每次模拟移动都应有进展");current=new Point(current.X+dx,current.Y+dy);moves++;
  }
  FocusAssert(current==target,"应真正走到312:333");
  FocusAssert(!walk.SearchTarget(current,target,now,out chosen),"到位短暂观察传送点");
  FocusAssert(walk.SearchTarget(current,target,now.AddSeconds(5),out chosen)&&chosen!=target,"未找到NPC应在附近换位继续找");
  guardRequested=true;engine.Start();engine.Recover("临时识别失败",ClockSeconds(),1);
  StopAll("F8已停止");ResumeGuardIfNeeded();
  FocusAssert(!guardRequested&&!engine.Running,"手动停止后恢复循环不得自启");
  int groups=RouteEngineTests.Run();
  File.WriteAllText(Path.Combine(root,"V4.5重点检查.txt"),
   "通过：320:333继续走到312:333，按实测方向规划；到位后未见NPC会换位寻找。\r\n"+
   "通过：F8清除持续守护意图，恢复循环不会重新启动。\r\n"+
   "持续寻路状态检查通过："+groups+"组（分轮重试、未知地图、回城、回图计数、手动停止）。\r\n"+
   "仅为离线逻辑检查，未执行实机游戏动作。",Encoding.UTF8);
  Close();
 }
}
