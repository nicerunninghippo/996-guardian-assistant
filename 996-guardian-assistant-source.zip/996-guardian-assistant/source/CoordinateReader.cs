using System;
using System.IO;
using System.Drawing;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

// Reads only the minimap coordinate text. No target, direction, or previous position
// is used to change a recognized digit. An ambiguous glyph makes the reading fail.
sealed class CoordinateReader {
 sealed class Sample { public int Digit; public double[] Values; }
 sealed class Glyph { public Rectangle Box; public bool Colon; }
 readonly List<Sample> samples=new List<Sample>();
 const int FeatureWidth=12,FeatureHeight=18;
 public CoordinateReader(string templateDirectory) {
  if(!Directory.Exists(templateDirectory))return;
  foreach(string file in Directory.GetFiles(templateDirectory,"coord-v44-*.png")) {
   string[] parts=Path.GetFileNameWithoutExtension(file).Split('-');
   int digit;
   if(parts.Length<4||!int.TryParse(parts[2],out digit)||digit<0||digit>9)continue;
   using(Bitmap image=new Bitmap(file))samples.Add(new Sample{Digit=digit,Values=Feature(image,new Rectangle(0,0,image.Width,image.Height))});
  }
 }
 static int White(Color pixel) { return Math.Min(pixel.R,Math.Min(pixel.G,pixel.B)); }
 static double Ink(Bitmap image,int x,int y) { return Math.Max(0,Math.Min(1,(White(image.GetPixel(x,y))-75)/140.0)); }
 static double[] Feature(Bitmap image,Rectangle box) {
  double[] result=new double[FeatureWidth*FeatureHeight];
  for(int y=0;y<FeatureHeight;y++)for(int x=0;x<FeatureWidth;x++) {
   double sx=Math.Max(0,Math.Min(box.Width-1,(x+.5)*box.Width/FeatureWidth-.5));
   double sy=Math.Max(0,Math.Min(box.Height-1,(y+.5)*box.Height/FeatureHeight-.5));
   int x0=(int)sx,y0=(int)sy,x1=Math.Min(box.Width-1,x0+1),y1=Math.Min(box.Height-1,y0+1);
   double ax=sx-x0,ay=sy-y0;
   double a=Ink(image,box.X+x0,box.Y+y0)*(1-ax)+Ink(image,box.X+x1,box.Y+y0)*ax;
   double b=Ink(image,box.X+x0,box.Y+y1)*(1-ax)+Ink(image,box.X+x1,box.Y+y1)*ax;
   result[y*FeatureWidth+x]=a*(1-ay)+b*ay;
  }
  return result;
 }
 static double Error(double[] a,double[] b) {
  double error=0;for(int i=0;i<a.Length;i++){double d=a[i]-b[i];error+=d*d;}return error/a.Length;
 }
 public bool TryRead(Bitmap image,int fixedSplit,out int x,out int y,out string detail) {
  x=y=-1;detail="坐标读取未完成";
  if(image==null){detail="坐标截图为空";return false;}
  int offsetX,offsetY;
  if(image.Width==1216&&image.Height==684){offsetX=0;offsetY=0;}
  else if(image.Width==149&&image.Height==180){offsetX=1067;offsetY=31;}
  else {detail="坐标截图尺寸不匹配："+image.Width+"×"+image.Height;return false;}
  if(samples.Count==0){detail="缺少 V4.4 坐标字形模板";return false;}
  Rectangle row=new Rectangle(1140-offsetX,183-offsetY,72,14);
  List<Glyph> glyphs=new List<Glyph>();int start=-1;
  // Project the entire text row onto X. Disconnected parts of a 3/5/0 stay in
  // their complete character cell instead of being merged as separate blobs.
  for(int column=0;column<=row.Width;column++) {
   bool occupied=false;
   if(column<row.Width)for(int yy=0;yy<row.Height;yy++)if(White(image.GetPixel(row.X+column,row.Y+yy))>140){occupied=true;break;}
   if(occupied&&start<0)start=column;
   if(!occupied&&start>=0) {
    int first=row.Height,last=-1,occupiedRows=0;
    for(int yy=0;yy<row.Height;yy++) {
     bool hasInk=false;for(int xx=start;xx<column;xx++)if(White(image.GetPixel(row.X+xx,row.Y+yy))>140){hasInk=true;break;}
     if(hasInk){first=Math.Min(first,yy);last=yy;occupiedRows++;}
    }
    int width=column-start,height=last-first+1;
    bool colon=width<=3&&occupiedRows>=2&&occupiedRows<=6&&height>=5;
    if(!colon&&(width<3||width>10||height<9||height>14||occupiedRows<8)){detail="坐标字格不完整：宽"+width+" 高"+height;return false;}
    glyphs.Add(new Glyph{Box=new Rectangle(row.X+start,row.Y+first,width,height),Colon=colon});start=-1;
   }
  }
  int separator=-1;
  for(int i=0;i<glyphs.Count;i++)if(glyphs[i].Colon){if(separator>=0){detail="坐标出现多个分隔符";return false;}separator=i;}
  if(separator<1||separator>3||glyphs.Count-separator-1<1||glyphs.Count-separator-1>3) {detail="坐标冒号或完整位数未读清";return false;}
  if(fixedSplit==3&&(separator!=3||glyphs.Count!=7)){detail="盟重坐标必须是三位:三位";return false;}
  if(fixedSplit>0&&separator!=fixedSplit){detail="坐标位数与地图不符";return false;}
  StringBuilder number=new StringBuilder(),evidence=new StringBuilder();
  foreach(Glyph glyph in glyphs) {
   if(glyph.Colon){number.Append(':');continue;}
   double[] values=Feature(image,glyph.Box),scores=new double[10];
   for(int i=0;i<10;i++)scores[i]=double.PositiveInfinity;
   foreach(Sample sample in samples)scores[sample.Digit]=Math.Min(scores[sample.Digit],Error(values,sample.Values));
   int best=0;for(int i=1;i<10;i++)if(scores[i]<scores[best])best=i;
   double second=double.PositiveInfinity;for(int i=0;i<10;i++)if(i!=best)second=Math.Min(second,scores[i]);
   double gap=second-scores[best];
   evidence.Append(best).Append("(误差").Append(scores[best].ToString("0.000",CultureInfo.InvariantCulture)).Append("/差距").Append(gap.ToString("0.000",CultureInfo.InvariantCulture)).Append(") ");
   // Require both an absolute fit and a clear lead over a different digit.
   if(scores[best]>.090||gap<.025){detail="坐标字形不确定；"+number+"?；"+evidence;return false;}
   number.Append(best);
  }
  string[] components=number.ToString().Split(':');int ax,ay;
  if(components.Length!=2||!int.TryParse(components[0],out ax)||!int.TryParse(components[1],out ay)){detail="坐标格式异常";return false;}
  x=ax;y=ay;detail="坐标="+number+"；完整字格灰度识别；"+evidence.ToString().Trim();return true;
 }
}
