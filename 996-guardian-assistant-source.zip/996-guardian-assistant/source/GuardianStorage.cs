using System;
using System.IO;

internal static class GuardianStorage {
 internal static string Resolve(string programRoot){
  string root=Path.GetFullPath(programRoot);
  string setting=Path.Combine(root,"data-directory.txt");
  if(!File.Exists(setting))return Path.Combine(root,"data");
  string configured=File.ReadAllText(setting).Trim();
  if(configured.Length==0||configured.IndexOfAny(new[]{'\r','\n'})>=0)throw new IOException("data-directory.txt 必须填写一行有效的数据目录；不会退回 C 盘写日志。");
  return Path.GetFullPath(Path.IsPathRooted(configured)?configured:Path.Combine(root,configured));
 }
}
