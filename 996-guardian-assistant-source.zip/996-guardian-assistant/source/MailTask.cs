using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;

public sealed class MailReading {
 public bool Panel,Notification,CanClose,CanExtract,CanDelete,SingleSelectedRead,AttachmentsEmpty,ListEmpty,HudClear;
 public int AttachmentInk;
 public ulong ListKey,BodyKey;
 public Point NotificationAt,CloseAt,ExtractAt,DeleteAt;
 public string Detail="";
}

// The mail sample is a cropped panel, not a game frame. Search preserved-size
// title/button anchors (1.0 and 1280->1216 scale), never stretch that crop to 1216.
public sealed class MailVision {
 sealed class Pixels {
  public int W,H;public int[] D;
  public Pixels(Bitmap b){W=b.Width;H=b.Height;D=FrameCache.Pixels(b);}
  public int At(int x,int y){return x<0||y<0||x>=W||y>=H?0:D[y*W+x];}
 }
 static bool Ink(int p){int r=(p>>16)&255,g=(p>>8)&255;return r>135&&g>110;}
 static bool ListInk(int p){int r=(p>>16)&255,g=(p>>8)&255;return r>90&&g>75;}
 sealed class Patch {
  public Pixels P;public int Count;public List<Point> Glyph=new List<Point>();
  public Patch(string file,double scale){using(Bitmap b=new Bitmap(file))using(Bitmap c=new Bitmap((int)Math.Round(b.Width*scale),(int)Math.Round(b.Height*scale))){
   using(Graphics g=Graphics.FromImage(c))g.DrawImage(b,new Rectangle(0,0,c.Width,c.Height),0,0,b.Width,b.Height,GraphicsUnit.Pixel);
   P=new Pixels(c);for(int y=0;y<P.H;y++)for(int x=0;x<P.W;x++)if(Ink(P.At(x,y)))Glyph.Add(new Point(x,y));Count=Glyph.Count;
  }}
  public double Score(Pixels f,int l,int t){
   if(l<0||t<0||l+P.W>f.W||t+P.H>f.H||Count<10)return 0;
   int hit=0,actual=0;foreach(Point q in Glyph)if(Ink(f.At(l+q.X,t+q.Y)))hit++;
   if(hit<Count*.68)return 0;
   for(int y=0;y<P.H;y++)for(int x=0;x<P.W;x++)if(Ink(f.At(l+x,t+y)))actual++;
   return 2.0*hit/(Count+actual);
  }
  public double Find(Pixels f,Rectangle area,out Point at){
   at=Point.Empty;double best=0;area=Rectangle.Intersect(area,new Rectangle(0,0,f.W,f.H));
   int stride=1; // Small glyphs must not be missed by odd/even search parity.
   for(int y=area.Top;y<=area.Bottom-P.H;y+=stride)for(int x=area.Left;x<=area.Right-P.W;x+=stride){double s=Score(f,x,y);if(s>best){best=s;at=new Point(x,y);}}
   Point coarse=at;for(int y=coarse.Y-2;y<=coarse.Y+2;y++)for(int x=coarse.X-2;x<=coarse.X+2;x++){double s=Score(f,x,y);if(s>best){best=s;at=new Point(x,y);}}
   return best;
  }
  public double FindEnvelope(Pixels f,Rectangle area,out Point at){
   // The small gold envelope must match its dark fold and gold colors, too.
   // A bright patch of floor/portal may match the binary glyph mask alone.
   at=Point.Empty;double best=0;area=Rectangle.Intersect(area,new Rectangle(0,0,f.W,f.H));
   for(int y=area.Top;y<=area.Bottom-P.H;y++)for(int x=area.Left;x<=area.Right-P.W;x++){
    double shape=Score(f,x,y);if(shape<.87)continue;
    double total=0;int close=0,n=P.W*P.H;
    for(int py=0;py<P.H;py++)for(int px=0;px<P.W;px++){
     int a=P.At(px,py),b=f.At(x+px,y+py);
     int dr=Math.Abs(((a>>16)&255)-((b>>16)&255)),dg=Math.Abs(((a>>8)&255)-((b>>8)&255)),db=Math.Abs((a&255)-(b&255));
     total+=dr+dg+db;if(Math.Max(dr,Math.Max(dg,db))<=55)close++;
    }
    double error=total/(n*3.0);if(error>25||close<n*.80)continue;
    double score=1-error/255.0;if(score>best){best=score;at=new Point(x,y);}
   }return best;
  }
 }
 sealed class Layout {public double Scale;public string Name;public Patch Title,Extract,Delete,Cross;}
 readonly List<Layout> layouts=new List<Layout>();readonly List<Patch> notifications=new List<Patch>();Patch hudDragon;readonly WelfareDetector hudDetector;
 public MailVision(string root){
  hudDetector=new WelfareDetector(root);
  string dir=Directory.Exists(Path.Combine(root,"templates"))?Path.Combine(root,"templates"):root;
  // The original attachment was cropped/resampled. Its synthetic embedding
  // matched itself but not the actual ADB glyphs (title score 0.81). Preserve
  // these native-frame patches; geometry remains the observed 0.95 layout.
  try{layouts.Add(new Layout{Scale=.95,Name="ADB原生",Title=new Patch(Path.Combine(dir,"mail-v414-title.png"),1),Extract=new Patch(Path.Combine(dir,"mail-v414-extract-all.png"),1),Delete=new Patch(Path.Combine(dir,"mail-v414-delete-read.png"),1),Cross=new Patch(Path.Combine(dir,"mail-v414-close.png"),1)});}catch(IOException){}catch(ArgumentException){}
  try{hudDragon=new Patch(Path.Combine(dir,"mail-v414-hud-dragon.png"),1);}catch(IOException){}catch(ArgumentException){}
  foreach(double s in new double[]{.95,1.0})try{
   layouts.Add(new Layout{Scale=s,Name="历史样本"+s,Title=new Patch(Path.Combine(dir,"mail-v413-title.png"),s),Extract=new Patch(Path.Combine(dir,"mail-v413-extract-all.png"),s),Delete=new Patch(Path.Combine(dir,"mail-v413-delete-read.png"),s),Cross=new Patch(Path.Combine(dir,"mail-v413-close.png"),s)});
   notifications.Add(new Patch(Path.Combine(dir,"mail-v413-notification.png"),s));
  }catch(IOException){}catch(ArgumentException){}
 }
 static Rectangle Region(Point origin,double s,int x,int y,int w,int h){return new Rectangle(origin.X+(int)Math.Round(x*s),origin.Y+(int)Math.Round(y*s),(int)Math.Round(w*s),(int)Math.Round(h*s));}
 static Rectangle Nearby(Rectangle r,int pad){r.Inflate(pad,pad);return r;}
 static int Count(Pixels f,Rectangle r,int kind){
  int n=0;r=Rectangle.Intersect(r,new Rectangle(0,0,f.W,f.H));
  for(int y=r.Top;y<r.Bottom;y++)for(int x=r.Left;x<r.Right;x++){
   int p=f.At(x,y),red=(p>>16)&255,g=(p>>8)&255,b=p&255;
   if(kind==0&&Ink(p))n++;
   if(kind==1&&g>130&&g>red*1.5&&g>b*1.5)n++;
   if(kind==2&&Math.Max(red,Math.Max(g,b))>100&&Math.Max(red,Math.Max(g,b))-Math.Min(red,Math.Min(g,b))>55)n++;
   if(kind==3&&ListInk(p))n++;
  }return n;
 }
 static ulong Key(Pixels f,Rectangle r){
  // Only text topology, independent of panel's static brown background.
  ulong h=1469598103934665603UL;
  for(int y=r.Top;y<r.Bottom;y+=2)for(int x=r.Left;x<r.Right;x+=2){h^=ListInk(f.At(x,y))?1UL:0UL;h*=1099511628211UL;}return h;
 }
 static Point Center(Point at,Patch p){return new Point(at.X+p.P.W/2,at.Y+p.P.H/2);}
 static bool CrossRed(Pixels f,Point p,Patch patch){return CountRed(f,new Rectangle(p.X,p.Y,patch.P.W,patch.P.H))>=patch.P.W*patch.P.H*.20;}
 static int CountRed(Pixels f,Rectangle r){int n=0;for(int y=r.Top;y<r.Bottom;y++)for(int x=r.Left;x<r.Right;x++){int p=f.At(x,y),red=(p>>16)&255,g=(p>>8)&255,b=p&255;if(red>80&&red>g*1.8&&red>b*1.8)n++;}return n;}
 public bool HasNotification(Bitmap image){return ReadNotification(image).Notification;}
 public MailReading ReadNotification(Bitmap image){
  if(image==null||image.Width!=1216||image.Height!=684)return new MailReading();return ReadNotification(new Pixels(image));
 }
 MailReading ReadNotification(Pixels f){
  var r=new MailReading();double best=0;
  foreach(Patch p in notifications){Point at;double s=p.FindEnvelope(f,new Rectangle(250,305,230,220),out at);if(s>best){best=s;r.Notification=true;r.NotificationAt=Center(at,p);}}
  return r;
 }
 public MailReading Read(Bitmap image){
  var r=new MailReading();if(image==null||image.Width!=1216||image.Height!=684)return r;var f=new Pixels(image);
  foreach(Layout l in layouts){
   Point title;double ts=l.Title.Find(f,new Rectangle(260,40,150,100),out title);r.Detail+=" "+l.Name+" title="+ts.ToString("0.00")+" @"+title;if(ts<.84)continue;
   Point origin=new Point(title.X-(int)Math.Round(143*l.Scale),title.Y-(int)Math.Round(23*l.Scale));
   Point ep,dp,cp;double es=l.Extract.Find(f,Nearby(Region(origin,l.Scale,94,515,83,29),5),out ep);
   double ds=l.Delete.Find(f,Nearby(Region(origin,l.Scale,222,515,80,29),5),out dp);
   double cs=l.Cross.Find(f,Nearby(Region(origin,l.Scale,866,40,21,34),5),out cp);
   r.Detail+=" extract="+es.ToString("0.00")+" delete="+ds.ToString("0.00")+" cross="+cs.ToString("0.00");if(es<.84||ds<.84||cs<.82||!CrossRed(f,cp,l.Cross))continue;
   r.Panel=true;r.CanExtract=true;r.CanDelete=true;r.CanClose=true;r.ExtractAt=Center(ep,l.Extract);r.DeleteAt=Center(dp,l.Delete);r.CloseAt=Center(cp,l.Cross);
   Rectangle item=Region(origin,l.Scale,86,116,219,31),body=Region(origin,l.Scale,356,86,420,77);
   r.ListKey=Key(f,item);r.BodyKey=Key(f,body);
   // Delete-read is global. With the supplied single-mail example only this
   // completely visible, selected, already-read singleton can be proven safe.
   // Additional rows or a scrollbar are not treated as a successful extraction.
   bool read=Count(f,Region(origin,l.Scale,192,84,48,27),1)>25;
   bool selectedText=Count(f,item,3)>20;
   bool extraRows=Count(f,Region(origin,l.Scale,88,168,218,305),3)>18;
   bool scrollbar=Count(f,Region(origin,l.Scale,315,160,10,315),0)>40;
   r.SingleSelectedRead=read&&selectedText&&!extraRows&&!scrollbar;
   r.ListEmpty=!selectedText&&!extraRows&&!scrollbar&&Count(f,Region(origin,l.Scale,87,82,218,73),3)<12;
   r.AttachmentInk=Count(f,Region(origin,l.Scale,394,428,211,61),2);
   int remainingText=Count(f,Region(origin,l.Scale,398,467,205,23),0);
   r.AttachmentsEmpty=r.AttachmentInk<10&&remainingText<12;
   r.Detail="邮件窗口已确认（"+l.Name+"，标题/提取/删除/红叉="+ts.ToString("0.00")+"/"+es.ToString("0.00")+"/"+ds.ToString("0.00")+"/"+cs.ToString("0.00")+"）；附件彩色像素="+r.AttachmentInk+"；单封已读="+r.SingleSelectedRead+" read="+read+" text="+selectedText+" extras="+extraRows+" scroll="+scrollbar;
   return r;
  }
  var notification=ReadNotification(f);notification.Detail=r.Detail;
  // A negative mail detector is not a successful close. This dragon-head HUD
  // area is covered by the mail window and by other full maintenance panels.
  // Require its actual colors/shape to be restored on two subsequent frames.
  if(hudDragon!=null){Point hud;notification.HudClear=hudDragon.FindEnvelope(f,new Rectangle(400,465,155,85),out hud)>=.90;}
  var clear=hudDetector.Read(image,0,0);
  notification.HudClear=!clear.Panel&&!clear.Blocked&&(notification.HudClear||clear.MainHud);
  return notification;
 }
}

// Bounded task. No device calls; each decision authorizes at most one tap.
// Never repeat extract/delete on an unchanged page, and never infer extraction
// from the 'read' flag or from elapsed time.
public sealed class MailTask:IMaintenanceTask {
 readonly MailVision vision;readonly MailFlow flow=new MailFlow();
 public MailTask(string root){vision=new MailVision(root);}
 public string Name{get{return "邮件奖励";}}public bool Active{get{return flow.Active;}}
 public bool HasNotification(Bitmap frame){return vision.HasNotification(frame);}
 internal bool IsPanelVisible(Bitmap frame){return vision.Read(frame).Panel;}
 public void Begin(double now){flow.Begin(now);}public void Reset(){flow.Reset();}
 public MaintenanceDecision Step(Bitmap frame,double now){return flow.Step(vision.Read(frame),now);}
}

public sealed class MailFlow {
 enum Phase{Idle,Open,Extract,VerifyExtract,VerifyDelete,Close}
 Phase phase;double started,phaseAt,nextTap,lastFrame=-1;int attempts,emptyFrames,cleanFrames;bool ok;string closeReason="";
 ulong listKey,bodyKey;bool singleton;
 public bool Active{get{return phase!=Phase.Idle;}}
 public void Reset(){phase=Phase.Idle;lastFrame=-1;closeReason="";}
 public void Begin(double now){Reset();phase=Phase.Open;started=phaseAt=now;nextTap=now;attempts=emptyFrames=cleanFrames=0;ok=false;singleton=false;}
 MaintenanceDecision Say(string message){return new MaintenanceDecision{Status="邮件："+message};}
 MaintenanceDecision Finish(bool success,string message){phase=Phase.Idle;return new MaintenanceDecision{Done=true,Success=success,Status="邮件："+message};}
 void Set(Phase p,double now){phase=p;phaseAt=now;attempts=0;nextTap=now;emptyFrames=cleanFrames=0;}
 MaintenanceDecision Closing(MailReading r,double now,string why){ok=false;closeReason=why;Set(Phase.Close,now);return Close(r,now,why);}
 MaintenanceDecision Close(MailReading r,double now,string why){
  if(!r.Panel&&r.HudClear){cleanFrames++;if(cleanFrames>=2)return Finish(ok,ok?"已完成并确认邮件窗口关闭":"本轮结束；"+why+"；连续两帧确认游戏界面恢复");return Say("邮件识别已消失，等待第二帧游戏界面恢复证据");}
  cleanFrames=0;
  if(now-started>=120||now-phaseAt>=12)return Finish(false,"关闭未能验证，已释放本任务并冷却；"+why);
  if(!r.Panel)return Say("邮件窗口未识别且游戏界面未恢复，不能确认已关闭；等待新截图");
  if(r.CanClose&&attempts<3&&now>=nextTap){attempts++;nextTap=now+3;return new MaintenanceDecision{Tap=r.CloseAt,Status="邮件："+why+"；关闭邮件窗口（"+attempts+"/3）"};}
  return Say("等待关闭结果，不重复提取或删除");
 }
 public MaintenanceDecision Step(MailReading r,double now){
  if(!Active)return new MaintenanceDecision{Done=true};
  if(now<=lastFrame)return Say("等待新截图");lastFrame=now;
  if(phase!=Phase.Close&&now-started>=100)return Closing(r,now,"本轮超过100秒，保留未确认邮件");
  if(phase==Phase.Close)return Close(r,now,closeReason);
  if(phase==Phase.Open){
   if(r.Panel){Set(Phase.Extract,now);return Say("已打开邮件，准备全部提取");}
   if(now-phaseAt>=12)return Closing(r,now,"12秒内未确认邮件窗口");
   if(r.Notification&&attempts<3&&now>=nextTap){attempts++;nextTap=now+3;return new MaintenanceDecision{Tap=r.NotificationAt,Status="邮件：打开邮件通知（"+attempts+"/3）"};}
   return Say("等待邮件通知或窗口出现");
  }
  if(!r.Panel){if(now-phaseAt>=12)return Closing(r,now,"邮件界面被遮挡，提取结果未确认，禁止删除");return Say("邮件界面被遮挡，等待清晰截图；不猜确认按钮");}
  if(phase==Phase.Extract){
   if(!r.CanExtract){if(now-phaseAt>=12)return Closing(r,now,"未找到全部提取");return Say("等待全部提取按钮");}
   listKey=r.ListKey;bodyKey=r.BodyKey;singleton=r.SingleSelectedRead;Set(Phase.VerifyExtract,now);
   return new MaintenanceDecision{Tap=r.ExtractAt,Status="邮件：点击全部提取一次，等待附件消失验证"};
  }
  if(phase==Phase.VerifyExtract){
   bool same=r.ListKey==listKey&&r.BodyKey==bodyKey;
   if(!same)return Closing(r,now,"邮件上下文改变，无法确认所有附件已取出，保留邮件");
   if(r.AttachmentsEmpty&&singleton&&r.SingleSelectedRead)emptyFrames++;else emptyFrames=0;
   if(emptyFrames>=2&&r.CanDelete){Set(Phase.VerifyDelete,now);return new MaintenanceDecision{Tap=r.DeleteAt,Status="邮件：连续两帧确认唯一已读邮件无附件，点击删除已读一次"};}
   if(now-phaseAt>=12)return Closing(r,now,!singleton?"已点全部提取，多封邮件或列表不完整，附件状态无法逐封验证，跳过删除":"全部提取未确认附件消失，保留邮件，不点击删除已读");
   return Say("等待附件消失；已读状态不等于提取成功");
  }
  if(phase==Phase.VerifyDelete){
   // A changed list alone may be a different message. Require the known
   // singleton to disappear AND no attachments; otherwise do not claim success.
   if(r.ListKey!=listKey&&r.ListEmpty&&r.AttachmentsEmpty){cleanFrames++;if(cleanFrames>=2){ok=true;closeReason="提取及删除已验证";Set(Phase.Close,now);return Close(r,now,closeReason);}}
   else cleanFrames=0;
   if(now-phaseAt>=12)return Closing(r,now,"删除结果未确认，不再次提交删除");
   return Say("等待已读邮件消失验证");
  }
  return Closing(r,now,"未知邮件状态");
 }
}
