using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Text;

static class Native {
 [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
 public delegate bool EnumProc(IntPtr h, IntPtr p);
 [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb,IntPtr p);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int key);

}
class WindowItem {public IntPtr H; public string Title; public override string ToString(){return Title+" ["+H+"]";}}
class Mask {
 sealed class Data {
  internal bool[] Bits;internal List<Point> Pos=new List<Point>();internal int[] Summed;
  internal int Count(int width,int height,int x,int y,int w,int h){
   int stride=width+1;
   if(Summed==null){Summed=new int[stride*(height+1)];for(int yy=1;yy<=height;yy++){int row=0;for(int xx=1;xx<=width;xx++){if(Bits[(yy-1)*width+xx-1])row++;Summed[yy*stride+xx]=Summed[(yy-1)*stride+xx]+row;}}}
   return Summed[(y+h)*stride+x+w]-Summed[y*stride+x+w]-Summed[(y+h)*stride+x]+Summed[y*stride+x];
  }
 }
 public int W,H;public bool[] Bits;public List<Point> Pos;
 readonly Data data;
 public Mask(Bitmap b,bool green,bool warm=false){
  W=b.Width;H=b.Height;int mode=green?1:warm?2:0;
  data=FrameCache.Get<Data>(b,typeof(Mask),"mask-"+mode,delegate{return Build(b,mode);});Bits=data.Bits;Pos=data.Pos;
 }
 static Data Build(Bitmap b,int mode){
  int width=b.Width,height=b.Height;int[] pixels=FrameCache.Pixels(b);Data result=new Data();result.Bits=new bool[width*height];
  for(int y=0;y<height;y++)for(int x=0;x<width;x++){int index=y*width+x,p=pixels[index],r=(p>>16)&255,g=(p>>8)&255,blue=p&255;
   bool value=mode==1?g>100&&g>r*1.35&&g>blue*1.25:mode==2?r>180&&g>95&&blue<150:r>155&&g>155&&blue>155&&Math.Abs(r-g)<45&&Math.Abs(g-blue)<45;
   result.Bits[index]=value;if(value)result.Pos.Add(new Point(x,y));
  }return result;
 }
 double ScoreAbove(Mask frame,int x,int y,double minimum){
  if(Pos.Count<15||x<0||y<0||x+W>frame.W||y+H>frame.H)return 0;
  int n=frame.data.Count(frame.W,frame.H,x,y,W,H);
  // These are mathematical upper bounds, not looser recognition thresholds.
  // A candidate skipped here cannot pass the original 62% rule or beat the
  // first best match already seen in the original row-major search order.
  if(n<Pos.Count*.62||2.0*Math.Min(n,Pos.Count)/(Pos.Count+n)<=minimum)return 0;
  int hit=0;foreach(Point p in Pos)if(frame.Bits[(y+p.Y)*frame.W+x+p.X])hit++;
  if(hit<Pos.Count*.62)return 0;return 2.0*hit/(Pos.Count+n);
 }
 public double Score(Mask frame,int x,int y){return ScoreAbove(frame,x,y,-1);}
 public double Find(Mask f,Rectangle area,out Point best){double score=0;best=Point.Empty;for(int y=Math.Max(0,area.Top);y<=Math.Min(f.H-H,area.Bottom-H);y++)for(int x=Math.Max(0,area.Left);x<=Math.Min(f.W-W,area.Right-W);x++){double s=ScoreAbove(f,x,y,score);if(s>score){score=s;best=new Point(x+W/2,y+H/2);}}return score;}
}
class SelectRect:Form {
 public Rectangle Selection; Point start; Bitmap frame;
 public SelectRect(Bitmap b,string title){frame=b;Text=title;ClientSize=new Size(Math.Min(1216,b.Width),Math.Min(720,b.Height));StartPosition=FormStartPosition.CenterScreen;DoubleBuffered=true;Cursor=Cursors.Cross;KeyPreview=true;KeyDown+=(s,e)=>{if(e.KeyCode==Keys.Escape)Close();};MouseDown+=(s,e)=>{start=e.Location;};MouseMove+=(s,e)=>{if(e.Button==MouseButtons.Left){Selection=Rectangle.FromLTRB(Math.Min(start.X,e.X),Math.Min(start.Y,e.Y),Math.Max(start.X,e.X),Math.Max(start.Y,e.Y));Invalidate();}};MouseUp+=(s,e)=>{if(Selection.Width>12&&Selection.Height>8){Selection=new Rectangle(Selection.X*b.Width/ClientSize.Width,Selection.Y*b.Height/ClientSize.Height,Selection.Width*b.Width/ClientSize.Width,Selection.Height*b.Height/ClientSize.Height);DialogResult=DialogResult.OK;Close();}};}
 protected override void OnPaint(PaintEventArgs e){e.Graphics.DrawImage(frame,ClientRectangle);e.Graphics.DrawRectangle(Pens.Red,Selection);}
}
class CoordDigit { public char Ch; public bool[] Bits=new bool[9*13]; public static bool Bright(Color c){int min=Math.Min(c.R,Math.Min(c.G,c.B));return min>110;} public CoordDigit(char ch,Bitmap b){Ch=ch;Load(b);} void Load(Bitmap b){for(int y=0;y<13;y++)for(int x=0;x<9;x++){int sx=Math.Min(b.Width-1,x*b.Width/9);int sy=Math.Min(b.Height-1,y*b.Height/13);Bits[y*9+x]=Bright(b.GetPixel(sx,sy));}} public double Match(Bitmap b){bool[] o=new bool[9*13];for(int y=0;y<13;y++)for(int x=0;x<9;x++){int sx=Math.Min(b.Width-1,x*b.Width/9);int sy=Math.Min(b.Height-1,y*b.Height/13);o[y*9+x]=Bright(b.GetPixel(sx,sy));}int hit=0,tot=0;for(int i=0;i<o.Length;i++){if(Bits[i]||o[i])tot++;if(Bits[i]&&o[i])hit++;}return tot==0?0:(double)hit/tot;} }partial class Guardian:Form {
 string root=AppDomain.CurrentDomain.BaseDirectory, data;
 ComboBox windows=new ComboBox(); Label state=new Label(),counts=new Label(); TextBox logs=new TextBox(); PictureBox preview=new PictureBox(); Engine engine=new Engine(); Timer timer=new Timer();
 CheckBox randomEnabled=new CheckBox(); NumericUpDown randomCooldown=new NumericUpDown(); bool randomSettingsLoaded,randomPointSet; Point randomPoint;
 bool backgroundConnected; BackgroundDevice backend=new BackgroundDevice(); string consolePath=BackgroundDevice.Discover(); RecycleVision recycleVision; RecycleFlow recycle=new RecycleFlow(); CheckBox recycleEnabled=new CheckBox(); NumericUpDown recycleMinutes=new NumericUpDown(); DateTime nextRecycle=DateTime.MaxValue; bool recycleSettingsLoaded; double lastMap4Score,lastAutoFightScore,lastRouteFirst,lastRouteSecond,lastMengSign,lastMengHeal,lastMengSvc,lastMengCross,lastShenlongDensity,lastPortalZhanScore,lastPortalLongScore; string lastRecognizeReason=""; DateTime lastDiag=DateTime.MinValue; List<Mask> targetMaps=new List<Mask>(); IntPtr hwnd; RectangleF region; bool calibrated; Mask[] maps=new Mask[5]; Mask npc,portal,autoOff,autoOn,autoFight,welfareButton,enterMapButton,dialogZhanqian,mengzhongSign,mengzhongHeal,mengzhongService,mengzhongCross,shenlongZhanqian,shenlongLongzhao,ciyuanTransferLabel; Rectangle offRect,onRect; DateTime lastTargetPortalClick=DateTime.MinValue; string lastTargetPortalName=""; bool autoWaiting; int autoTries; DateTime pausedSince=DateTime.MinValue; DateTime lastMzMove=DateTime.MinValue; int mzMoveTries; DateTime mzCoordReadyUntil=DateTime.MinValue; int mzLastCoordX=-1,mzLastCoordY=-1; DateTime mzLastCoordAt=DateTime.MinValue; bool mzStickSet; Point mzStickCenter; DateTime lastShenlongMove=DateTime.MinValue; int shenlongMoveTries; string lastCoord=""; List<CoordDigit> coordDigits=new List<CoordDigit>(); Point[] coordDirOffsets=new Point[]{new Point(0,-62),new Point(44,-44),new Point(62,0),new Point(44,44),new Point(0,62),new Point(-44,44),new Point(-62,0),new Point(-44,-44)}; string[] coordDirNames=new[]{"上","右上","右","右下","下","左下","左","左上"}; int[] coordDirDx=new int[8],coordDirDy=new int[8]; bool coordDirReady; string last="";
 readonly DatedLogWriter datedLog = new DatedLogWriter();
 public Guardian():this(null,null){}
 internal Guardian(string codeRoot,string diagnosticData){if(codeRoot!=null)root=codeRoot;data=diagnosticData??GuardianStorage.Resolve(root);Text="996传奇挂机守护助手 "+DatedLogWriter.Release;Font=new Font("Microsoft YaHei UI",10);ClientSize=new Size(900,740);MinimumSize=new Size(820,700);StartPosition=FormStartPosition.CenterScreen;Directory.CreateDirectory(data);
  var top=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Padding=new Padding(10),WrapContents=true,AutoScroll=true,MaximumSize=new Size(0,400)};windows.Width=310;windows.DropDownStyle=ComboBoxStyle.DropDownList;top.Controls.Add(windows);Add(top,"刷新窗口",RefreshWindows);Add(top,"连接",Connect);Add(top,"选择雷电目录",ChooseEmulator);Add(top,"更新目标图样（可选）",Target);Add(top,"开始守护",Start);Add(top,"停止（F8）",()=>{StopAll("已停止");Log(engine.Status);});Add(top,"截图回放自检",Replay); InitMaintenance(top); InitRecycle(top); InitRandom(top); Add(top,"校准随机石位置",CalRandom); Add(top,"校准跑/走摇杆",CalMzStick); Add(top,"校准坐标方向",CalCoordDirections);InitNavigationSettings(top);priorityInfo.AutoSize=true;priorityInfo.MaximumSize=new Size(835,0);priorityInfo.Padding=new Padding(0,6,0,0);top.Controls.Add(priorityInfo);InitAutoBattle(top);InitHellRoute(top);InitBoss(top);
  var bottom=new Panel{Dock=DockStyle.Bottom,Width=ClientSize.Width,Height=220};state.SetBounds(12,5,865,30);counts.SetBounds(12,35,865,25);logs.SetBounds(12,65,865,145);logs.Multiline=true;logs.ReadOnly=true;logs.ScrollBars=ScrollBars.Vertical;logs.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right|AnchorStyles.Bottom;bottom.Controls.AddRange(new Control[]{state,counts,logs});InitLogCopy(bottom);preview.Dock=DockStyle.Fill;preview.SizeMode=PictureBoxSizeMode.Zoom;preview.BackColor=Color.FromArgb(25,30,38);Controls.Add(preview);Controls.Add(bottom);Controls.Add(top);
  state.Text="未连接 ｜ 待机：连接雷电后即可开始，无需框选画面";counts.Text="回图次数：0    失败次数：0";
  InitPriorityCatalog();Log("程序启动："+DatedLogWriter.Release+"；日志使用本机日期和时间；程序目录="+root+"；数据目录="+data);Log("诊断截图目录="+Path.Combine(data,"diagnostics-current")+"；新截图最多512MiB/7天；历史diagnostics完整保留；BOSS等待游戏系统回城");
  for(int i=0;i<4;i++)maps[i]=Load("map"+i+".png",false,false);npc=Load("npc.png",true,false);portal=Load("portal.png",true,false);autoFight=Load("auto-fighting-adb.png",false,false);welfareButton=Load("popup-welfare-button.png",false,false);enterMapButton=Load("enter-map-button.png",false,false);dialogZhanqian=Load("dialog-zhanqian-c.png",false,false);mengzhongSign=Load("mengzhong-sign.png",false,false);mengzhongHeal=Load("mengzhong-heal.png",true,false);mengzhongService=Load("mengzhong-service.png",true,false);mengzhongCross=Load("mengzhong-cross.png",true,false);shenlongZhanqian=Load("shenlong-zhanqian.png",true,false);shenlongLongzhao=Load("shenlong-longzhao.png",true,false);ciyuanTransferLabel=Load("ciyuan-transfer-label.png",true,false);LoadCoordDigits();LoadConfig();LoadTargetMaps();if(File.Exists(Path.Combine(data,"console-path.txt")))consolePath=File.ReadAllText(Path.Combine(data,"console-path.txt"));RefreshWindows();timer.Interval=900;timer.Tick+=(s,e)=>Tick();timer.Start();FormClosing+=(s,e)=>{StopAll("已关闭");timer.Stop();if(strictMapTitleReader!=null)strictMapTitleReader.Dispose();DisposeBoss();DisposeHellRoute();CloseDiagnostics();};Log("后台模式：可切换其他软件，不占用鼠标；雷电需保持运行。F8停止。");}
 void Add(Control p,string text,Action a){var b=new Button{Text=text,AutoSize=true,Height=32};b.Click+=(s,e)=>{if(coordCalibration.Active&&text!="停止（F8）"){Log("方向校准进行中；请等待完成，或点击停止");return;}userActionBusy=true;try{a();}catch(Exception ex){if(guardRequested){RetryGuard(ex.Message,3);}else{engine.Stop("操作未完成");Log(ex.Message);MessageBox.Show(ex.Message,"提示");}}finally{userActionBusy=false;}};p.Controls.Add(b);}
 new Mask Load(string n,bool green,bool user){string f=Path.Combine(user?data:Path.Combine(root,"templates"),n);if(!File.Exists(f))return null;using(var b=new Bitmap(f))return new Mask(b,green,n=="auto-on.png"||n=="enter-map-button.png"||n=="mengzhong-sign.png");}
 void Log(string s){if(datedLog.Write(data,s,DateTime.Now,AppendVisibleLog,TraceContextText()))TraceLog(s);}
 void RefreshWindows(){windows.Items.Clear();Native.EnumWindows((h,p)=>{var s=new StringBuilder(500);Native.GetWindowText(h,s,500);string t=s.ToString();if(Native.IsWindowVisible(h)&&(t.Contains("雷电模拟器")||t.Contains("996传奇盒子")))windows.Items.Add(new WindowItem{H=h,Title=t});return true;},IntPtr.Zero);if(windows.Items.Count>0)windows.SelectedIndex=0;}
 void Connect(){StopAll("连接检查中");backgroundConnected=false;ResetPriorityConnection();ResetHellRoute(true);if(windows.SelectedItem==null)throw new Exception("未找到雷电窗口，请先启动模拟器。");backend=new BackgroundDevice();backend.Report=Log;hwnd=((WindowItem)windows.SelectedItem).H;backend.Connect(hwnd,consolePath);Log("连接检查：开始读取首帧；实例="+backend.Serial);using(Bitmap raw=TraceCapture())using(Bitmap b=Normalize(raw)){if(preview.Image!=null)preview.Image.Dispose();preview.Image=new Bitmap(b);}backgroundConnected=true;LoadNavigationSettings(backend.Serial);engine.Status="已连接，待开始";TraceSettings("connected");Log("后台已连接："+windows.SelectedItem+" / "+backend.Serial+"；首帧="+backend.Width+"x"+backend.Height);}
 void Ready(){if(hwnd==IntPtr.Zero||!Native.IsWindow(hwnd))throw new Exception("请先连接雷电窗口");}
 Bitmap Raw(){Ready();return TraceCapture();}
 void ChooseEmulator(){engine.Stop("已停止");using(var pick=new OpenFileDialog{Title="选择雷电安装目录中的ldconsole.exe",Filter="雷电接口|ldconsole.exe;dnconsole.exe"}){if(pick.ShowDialog()==DialogResult.OK){consolePath=pick.FileName;File.WriteAllText(Path.Combine(data,"console-path.txt"),consolePath);Log("雷电接口路径已保存，请重新连接");}}}
 Bitmap Normalize(Bitmap raw){Bitmap b=new Bitmap(1216,684);using(Graphics g=Graphics.FromImage(b))g.DrawImage(raw,new Rectangle(0,0,1216,684));return b;} void Target(){engine.Stop("校准中");using(Bitmap raw=Raw())using(Bitmap b=Normalize(raw))using(Bitmap patch=b.Clone(new Rectangle(1068,34,147,28).IntersectSafe(b),b.PixelFormat)){if(MessageBox.Show("请确认游戏右上角地图名当前明确为最终刷怪地图，并且未被弹窗遮挡。保存后将以此图样判断到达。是否保存？","目标地图校准",MessageBoxButtons.YesNo)!=DialogResult.Yes)return;Mask m=new Mask(patch,false);if(m.Pos.Count<45)throw new Exception("地图文字不清晰，请确认目标地图显示完整");maps[4]=m;targetMaps.Clear();targetMaps.Add(m);patch.Save(Path.Combine(data,"map4-custom.png"));try{patch.Save(Path.Combine(root,"templates","map4-custom.png"));}catch{}LoadTargetMaps();Log("最终刷怪地图图样已保存");}}
 void AutoCal(bool on){engine.Stop("校准中");using(Bitmap raw=Raw())using(Bitmap b=Normalize(raw))using(var pick=new SelectRect(b,on?"自动已开启时：框选橙色『自动战斗中』文字，避开人物和背景":"自动关闭时：框选右侧自动按钮的状态文字；请先手动关闭自动")){if(pick.ShowDialog()!=DialogResult.OK)return;Rectangle r=pick.Selection;using(Bitmap p=b.Clone(r,b.PixelFormat)){Mask m=new Mask(p,false,on);if(m.Pos.Count<20)throw new Exception("图样文字太少，请框选完整状态标志");p.Save(Path.Combine(data,on?"auto-on.png":"auto-off.png"));if(on){autoOn=m;onRect=r;}else{autoOff=m;offRect=r;}SaveConfig();Log("自动"+(on?"开启":"关闭")+"图样已保存；开始前请恢复游戏自动挂机。");}}}
 void Start(){Ready();if(System.Diagnostics.Process.GetProcessesByName(System.Diagnostics.Process.GetCurrentProcess().ProcessName).Length>1)throw new Exception("请先关闭旧版或其他助手窗口，避免两个程序同时操作同一游戏");if(!backgroundConnected)throw new Exception("请先连接雷电后台接口");if(targetMaps.Count==0)throw new Exception("目标图样缺失，请在最终刷怪地图更新目标图样");engine.Start();ResetAutoBattle();ResetMinimapRecovery();ResetHealthEvidence();ResetBoxPopup();ResetMapPriorityCycle();ResetHellRoute(false);guardRequested=true;StartMaintenance();StartBoss();guardResumeAt=DateTime.MinValue;autoCalRetryAt=DateTime.MinValue;mengWalk=new WalkProgress();shenWalk=new WalkProgress();lastWalkMap=-9;recycle.Reset();nextRecycle=DateTime.Now.AddMinutes((double)recycleMinutes.Value);autoWaiting=false;autoTries=0;pausedSince=DateTime.MinValue;lastMzMove=DateTime.MinValue;mzMoveTries=0;lastShenlongMove=DateTime.MinValue;shenlongMoveTries=0;TraceSettings("guard_start");Log("后台守护已启动，可以正常使用其他软件");}
 void SaveConfig(){File.WriteAllLines(Path.Combine(data,"config.txt"),new[]{region.X.ToString(System.Globalization.CultureInfo.InvariantCulture),region.Y.ToString(System.Globalization.CultureInfo.InvariantCulture),region.Width.ToString(System.Globalization.CultureInfo.InvariantCulture),region.Height.ToString(System.Globalization.CultureInfo.InvariantCulture),RectString(offRect),RectString(onRect)});}
 string RectString(Rectangle r){return r.X+","+r.Y+","+r.Width+","+r.Height;}
 Rectangle ParseRect(string s){int[] a=s.Split(',').Select(int.Parse).ToArray();return new Rectangle(a[0],a[1],a[2],a[3]);}
 void LoadConfig(){try{string[] a=File.ReadAllLines(Path.Combine(data,"config.txt"));float[] n=a.Take(4).Select(x=>float.Parse(x,System.Globalization.CultureInfo.InvariantCulture)).ToArray();region=new RectangleF(n[0],n[1],n[2],n[3]);calibrated=region.X>=0&&region.Y>=0&&region.Width>0&&region.Height>0&&region.Right<=1.001&&region.Bottom<=1.001;offRect=ParseRect(a[4]);onRect=ParseRect(a[5]);LoadTargetMaps();autoOff=Load("auto-off.png",false,true);autoOn=Load("auto-on.png",false,true);}catch{calibrated=false;}try{string[] m=File.ReadAllLines(Path.Combine(data,"mz-stick.txt"));mzStickCenter=new Point(int.Parse(m[0]),int.Parse(m[1]));mzStickSet=true;}catch{mzStickCenter=new Point(82,497);mzStickSet=false;}LoadCoordDirections();}
void AddTargetMap(string n,bool user){Mask m=Load(n,false,user);if(m!=null)targetMaps.Add(m);} void LoadTargetMaps(){targetMaps.Clear();AddTargetMap("map4-adb.png",true);AddTargetMap("map4-custom.png",true);AddTargetMap("map4.png",true);AddTargetMap("map4-adb.png",false);AddTargetMap("map4-custom.png",false);AddTargetMap("map4.png",false);maps[4]=targetMaps.Count>0?targetMaps[0]:null;} public int Recognize(Bitmap b){if(ReadMinimap(b).State==MinimapState.Collapsed){lastRecognizeReason="小地图已收起，地图名/坐标不可见；先展开再识别";return -1;}var currentTown=ReadTownTitle(b);if(currentTown.Town){lastRecognizeReason=currentTown.Detail;return 0;}int hellMap=ReadHellMap(b);if(hellMap==5){lastRecognizeReason="冥界：完整标题确认";return 5;}if(hellMap==4){lastRecognizeReason="鬼门关：完整标题确认";return 4;}string priorityReason;if(TryRecognizePriorityTarget(b,out priorityReason)){lastRecognizeReason=priorityReason;return 4;}if(priorityOcrCount==1&&priorityOcrCandidate.Length>0){lastRecognizeReason=priorityReason;return -1;}using(Bitmap p=b.Clone(new Rectangle(1067,31,149,34).IntersectSafe(b),b.PixelFormat)){Mask f=new Mask(p,false);int best=-1;double first=0,second=0;lastMap4Score=0;lastAutoFightScore=0;lastRouteFirst=0;lastRouteSecond=0;lastRecognizeReason="";foreach(Mask target in targetMaps){Point q;double s=target.Find(f,new Rectangle(0,0,p.Width,p.Height),out q);if(s>lastMap4Score)lastMap4Score=s;}if(!priorityTitleBlocksLegacy&&lastMap4Score>=.76){lastRecognizeReason="目标地图：右上地图名="+lastMap4Score.ToString("0.00");return 4;}
for(int i=0;i<4;i++){if(maps[i]==null)continue;Point q;double s=maps[i].Find(f,new Rectangle(0,0,p.Width,p.Height),out q);if(s>first){second=first;first=s;best=i;}else if(s>second)second=s;}lastRouteFirst=first;lastRouteSecond=second;if(first>=.74&&first-second>=.04){lastRecognizeReason="右上地图名："+new[]{"盟重省","次元大陆","蛟龙领地","神龙帝国"}[best]+"="+first.ToString("0.00");return best;}
// 盟重省有稳定的场景元素。只有右上角标题没有足够把握时才使用这些元素兜底，
// 避免单个绿色文字在神龙大厅里抢过明确的地图标题。
if(IsMengzhongScene(b)){lastRecognizeReason="盟重省：元素识别 天道会="+lastMengSign.ToString("0.00")+" 一键满血="+lastMengHeal.ToString("0.00")+" 综合服务="+lastMengSvc.ToString("0.00")+" 跨服集合点="+lastMengCross.ToString("0.00");return 0;}
// 传送点候选只用于已经确认的神龙帝国分支（Tick 中的 map==3），不能单独决定地图名。
// 否则盟重省里相似的绿色传送点/文字会把地图误报成神龙帝国。
if(IsShenlongPortalHall(b)){lastRecognizeReason="神龙帝国：传送大厅特征 密度="+lastShenlongDensity.ToString("0.000")+" 战场="+lastPortalZhanScore.ToString("0.00")+" 龙爪="+lastPortalLongScore.ToString("0.00");return 3;}lastAutoFightScore=AutoFightScore(b);/* 战斗特效只作诊断，不能证明已经进入指定刷怪地图。 */lastRecognizeReason="未识别：目标="+lastMap4Score.ToString("0.00")+" 路线="+lastRouteFirst.ToString("0.00")+"/"+lastRouteSecond.ToString("0.00")+" 盟重元素="+lastMengHeal.ToString("0.00")+","+lastMengSvc.ToString("0.00")+","+lastMengCross.ToString("0.00")+" 神龙密度="+lastShenlongDensity.ToString("0.000")+" 橙色特效(仅诊断)="+lastAutoFightScore.ToString("0.00");return -1;}}
 bool IsMengzhongScene(Bitmap b){int real=0;Point p;lastMengSign=lastMengHeal=lastMengSvc=lastMengCross=0;if(mengzhongSign!=null){Mask warm=new Mask(b,false,true);lastMengSign=mengzhongSign.Find(warm,new Rectangle(35,80,360,340).IntersectSafe(b),out p);}Mask green=new Mask(b,true);if(mengzhongHeal!=null){lastMengHeal=mengzhongHeal.Find(green,new Rectangle(430,40,420,180).IntersectSafe(b),out p);if(lastMengHeal>=.46)real++;}if(mengzhongService!=null){lastMengSvc=mengzhongService.Find(green,new Rectangle(650,120,420,260).IntersectSafe(b),out p);if(lastMengSvc>=.46)real++;}if(mengzhongCross!=null){lastMengCross=mengzhongCross.Find(green,new Rectangle(760,35,430,220).IntersectSafe(b),out p);if(lastMengCross>=.46)real++;}return real>=1;}
 bool FindTargetPortal(Bitmap b,out Point point,out string reason){if(bossResumeFlow.Active){point=Point.Empty;reason="BOSS后必须恢复鬼门关，禁止普通地图入口";return false;}return FindPriorityPortal(b,out point,out reason);}
 bool IsShenlongPortalHall(Bitmap b){Rectangle r=new Rectangle(0,80,1120,520).IntersectSafe(b);int portal=0,total=0,greenLabels=0;for(int y=r.Top;y<r.Bottom;y+=2)for(int x=r.Left;x<r.Right;x+=2){Color c=b.GetPixel(x,y);bool blue=c.B>145&&c.G>95&&c.R<140;bool purple=c.B>145&&c.R>90&&c.G<150;bool cyan=c.B>130&&c.G>150&&c.R<135;bool green=c.G>120&&c.G>c.R*1.35&&c.G>c.B*1.15;if(blue||purple||cyan)portal++;if(green)greenLabels++;total++;}lastShenlongDensity=total==0?0:(double)portal/total;double gd=total==0?0:(double)greenLabels/total;return lastShenlongDensity>.060&&gd>.006;} void LoadCoordDigits(){coordDigits.Clear();for(char c='0';c<='9';c++){string f=Path.Combine(root,"templates","coord-"+c+".png");if(File.Exists(f))using(Bitmap b=new Bitmap(f))coordDigits.Add(new CoordDigit(c,b));}}
 CoordinateReader coordinateReader;
 bool TryReadCoord(Bitmap b,out int cx,out int cy,out string detail){return TryReadCoordDigits(b,0,out cx,out cy,out detail);}
 bool TryReadCoordDigits(Bitmap b,int fixedSplit,out int cx,out int cy,out string detail){
  if(coordinateReader==null)coordinateReader=new CoordinateReader(Path.Combine(root,"templates"));
  bool ok=coordinateReader.TryRead(b,fixedSplit,out cx,out cy,out detail);
  lastCoord=ok?cx+":"+cy:"";return ok;
 }
 void AddCoordBox(bool[,] white,List<Rectangle> boxes,int x1,int x2,int h){int minY=h,maxY=-1;for(int x=x1;x<=x2;x++)for(int y=0;y<h;y++)if(white[x,y]){if(y<minY)minY=y;if(y>maxY)maxY=y;}if(maxY>=minY)boxes.Add(new Rectangle(x1,minY,x2-x1+1,maxY-minY+1));}bool IsShenlongCoordReady(Bitmap b,out string detail){int x,y;string d;if(!ReadCoordForCalibration(b,3,out x,out y,out d)){detail="坐标未读清";return false;}detail=d+"；目标="+GoalText(navigationSettings.Shenlong);return navigationSettings.Shenlong.IsReady(new Point(x,y),shenWalk);}  double AutoFightScore(Bitmap b){
  Rectangle r=new Rectangle(610,455,250,80).IntersectSafe(b);int warm=0,total=0;
  for(int y=r.Top;y<r.Bottom;y++)for(int x=r.Left;x<r.Right;x++){Color c=b.GetPixel(x,y);bool v=c.R>185&&c.G>70&&c.G<210&&c.B<80;if(v)warm++;total++;}
  double density=total==0?0:(double)warm/total;
  double template=0;if(autoFight!=null){Mask m=new Mask(b,false,true);Point p;template=autoFight.Find(m,new Rectangle(560,430,360,115),out p);}
  return Math.Max(template,Math.Min(1.0,density/0.018));
 }
 DiagnosticRetention diagnosticRetention;
 DateTime lastDiagnosticLimitLog=DateTime.MinValue;
 void SaveDiagnostic(Bitmap b,int map,string reason){string baseName=null;try{if((DateTime.Now-lastDiag).TotalSeconds<15)return;lastDiag=DateTime.Now;if(diagnosticRetention==null)diagnosticRetention=new DiagnosticRetention(Path.Combine(data,"diagnostics-current"));string limitReason;
 if(!diagnosticRetention.ReadyToSave(out limitReason)){if((DateTime.Now-lastDiagnosticLimitLog).TotalSeconds>=60){lastDiagnosticLimitLog=DateTime.Now;Log(limitReason);}return;}
 string dir=diagnosticRetention.DirectoryPath;string stamp=DateTime.Now.ToString("yyyyMMdd-HHmmss-fff")+"-f"+traceFrame;string safe=DiagnosticRetention.SafeReason(reason);baseName=Path.Combine(dir,stamp+"-"+safe);b.Save(baseName+".png");using(Bitmap title=b.Clone(new Rectangle(1067,31,149,34).IntersectSafe(b),b.PixelFormat))title.Save(baseName+"-title.png");string[] lines={"context="+TraceContextText(),"time="+DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss.fff zzz"),"reason="+reason,"map="+map,"recognize="+lastRecognizeReason,"playerLevel="+mapPriority.CurrentLevel,"playerLevelEvidence="+priorityLevelReason,"expectedMap="+prioritySelectedName,"titleOcr="+priorityOcrReason,"targetScore="+lastMap4Score.ToString("0.000"),"routeScore="+lastRouteFirst.ToString("0.000")+"/"+lastRouteSecond.ToString("0.000"),"mengzhong="+lastMengSign.ToString("0.000")+","+lastMengHeal.ToString("0.000")+","+lastMengSvc.ToString("0.000")+","+lastMengCross.ToString("0.000"),"shenlong="+lastShenlongDensity.ToString("0.000")+",zhan="+lastPortalZhanScore.ToString("0.000")+",long="+lastPortalLongScore.ToString("0.000"),"autoFightScore="+lastAutoFightScore.ToString("0.000"),"rightAutoButton="+ReadAutoBattle(b).Detail,"cachedObservationWarning=recognize/titleOcr/scores为最近一次对应检查缓存，BOSS提前返回时可能来自旧帧；rightAutoButton/currentTownTitle为本截图实时检查","currentTownTitle="+ReadTownTitle(b).Detail,"bossStage="+bossStage,"bossSceneEvidenceFrame="+bossSceneFrame,"bossSceneEvidence="+bossSceneEvidence,"engine="+engine.Status,"stable="+engine.Stable,"count="+engine.Count,"pending="+engine.Pending,"recycleStage="+recycle.Stage};File.WriteAllLines(baseName+".txt",lines,Encoding.UTF8);TraceEvent("evidence","image",baseName+".png","title",baseName+"-title.png","note",baseName+".txt","reason",reason);Log("已保存诊断："+Path.GetFileName(baseName));}catch(Exception ex){Log("保存诊断失败："+ex.Message);}finally{if(baseName!=null&&diagnosticRetention!=null)diagnosticRetention.AfterSave(baseName);}}
 internal Func<Point,bool> inputTapOverride=null; internal Func<Point,Point,int,bool> inputSwipeOverride=null;
 new bool Click(Point p){return TraceInput("tap",p,p,0,engine.Running&&Native.GetAsyncKeyState(0x77)>=0,delegate{return inputTapOverride!=null?inputTapOverride(p):backend.Tap(p);});} bool Swipe(Point a,Point b,int ms){return TraceInput("swipe",a,b,ms,engine.Running&&Native.GetAsyncKeyState(0x77)>=0,delegate{return inputSwipeOverride!=null?inputSwipeOverride(a,b,ms):backend.Swipe(a,b,ms);});}
 void Tick(){if(!engine.Running&&!coordCalibration.Active){TickCore();TraceHeartbeat();TracePerformance(false);return;}using(new TraceSpan(this))TickCore();}
 void TickCore(){if(Native.GetAsyncKeyState(0x77)!=0)StopAll("F8已停止");ResumeGuardIfNeeded();if(coordCalibration.Active){TickCoordCalibration();return;}counts.Text="回图："+engine.Returns+"    失败："+engine.Failures+"    回收操作："+recycle.Completed+"    "+(recycleEnabled.Checked?"下次回收："+(nextRecycle==DateTime.MaxValue?"开始后计时":nextRecycle.ToString("HH:mm:ss")):"定时回收已关闭");state.Text=(hwnd!=IntPtr.Zero&&Native.IsWindow(hwnd)?"已连接":"未连接")+" ｜ "+engine.Status;if(!engine.Running||ClockSeconds()<engine.RetryAt)return;
  try{
   using(Bitmap raw=TraceCapture())using(Bitmap b=Normalize(raw))using(FrameCache.Begin(b)){if(preview.Image!=null)preview.Image.Dispose();preview.Image=(Bitmap)b.Clone();ObservePlayerLevel(b);if(TraceStage("known_welfare_close",delegate{return CloseKnownWelfarePopup(b);}))return;if(TraceStage("reward_popup",delegate{return HandleRewardPopup(b);}))return;if(TraceStage("low_fps",delegate{return HandleLowFpsPrompt(b);}))return;if(TraceStage("boss_resume_ghost",delegate{return ResumeGhostAfterBoss(b);}))return;if(TraceStage("hell_route",delegate{return HandleHellRoute(b);}))return;if(TraceStage("boss",delegate{return HandleBoss(b);}))return;if(TraceStage("maintenance",delegate{return HandleMaintenance(b);}))return;if(TraceStage("farm_popup",delegate{return CloseFarmPopup(b);}))return;if(TraceStage("owned_recycle",delegate{return HandleOwnedRecyclePanel(b);}))return;if(TraceStage("box_popup",delegate{return CloseBoxPopup(b);})){ResetHealthEvidence();return;}if(TraceStage("minimap_recovery",delegate{return EnsureMinimapVisible(b);}))return;if(TraceStage("map_detail",delegate{return ClickPriorityMapDialog(b);})){ResetHealthEvidence();return;}if(TraceStage("legacy_welfare",delegate{return CloseWelfarePopup(b);})){ResetHealthEvidence();return;}if(TraceStage("other_panel",delegate{return CloseOpenPanel(b);})){ResetHealthEvidence();return;}if(TraceStage("popup_recovery",delegate{return VerifyFarmPopupRecovery(b);}))return;int map=TraceRecognize(b);ObservePriorityMap(map,b);if(priorityEntryDeadline>DateTime.Now&&map!=4){engine.Status="进入指令已提交，等待实际地图名；暂不移动或点击其他入口";return;}ObserveWalkMap(map);if(map<0)SaveDiagnostic(b,map,"unknown-map");if(TraceStage("health_escape",delegate{return TryRandomEscape(b,map);}))return;if(TraceStage("recycle",delegate{return HandleRecycle(b,map);})){ResetHealthEvidence();return;}string[] names={"盟重省","次元大陆","蛟龙领地","神龙帝国","目标地图","冥界"};Point point=Point.Empty;bool found=false;double routeNpcScore=0;string actionReason="";if(map>=0&&map<4){if(map==3){string coordDetail;if(IsShenlongCoordReady(b,out coordDetail)){found=FindTargetPortal(b,out point,out actionReason);actionReason=actionReason+"；"+coordDetail;}else{found=false;actionReason="神龙坐标未到"+GoalText(navigationSettings.Shenlong)+"，先按坐标走到目标，禁止提前点击传送点；"+coordDetail;}}else{Mask f=new Mask(b,true);double ns=npc==null?0:npc.Find(f,new Rectangle(50,100,925,445).IntersectSafe(b),out point);routeNpcScore=ns;double cs=0;Point cp=Point.Empty;if(map==1&&ciyuanTransferLabel!=null)cs=ciyuanTransferLabel.Find(f,new Rectangle(360,160,420,260).IntersectSafe(b),out cp);if(map==0){string mzCoord;bool ready=IsMengzhongCoordReady(b,out mzCoord);bool latched=ready;found=ns>=.72&&latched;actionReason=(found?"盟重坐标到位且看到大陆传送，点击；":(ns>=.65&&!latched?"疑似大陆传送但坐标未到，不点；":"盟重未看到可靠大陆传送，继续扫描；"))+"NPC分="+ns.ToString("0.00")+"；"+(latched?"已到指定坐标或其换位范围；":"坐标未到；")+mzCoord;}else if(map==1&&cs>=.42&&cs>=ns){point=new Point(cp.X,Math.Max(0,cp.Y-42));found=true;actionReason="次元大陆传送文字分="+cs.ToString("0.00")+" 点="+point.X+","+point.Y;}else{found=ns>=.74;actionReason="大陆传送NPC分="+ns.ToString("0.00")+(map==1?" 次元文字分="+cs.ToString("0.00"):"");}}}
    bool verifiedJiaolongNpc=found&&RouteTapGuard.ConfirmJiaolongNpc(b,map,point,routeNpcScore);if(verifiedJiaolongNpc)actionReason+="；已确认蛟龙场景内大陆传送，中心单点("+point.X+","+point.Y+")";bool verifiedTargetPortal=found&&map==3&&mapPriority.Selected>=0&&RouteTapGuard.ConfirmTargetPortal(b,map,point,priorityPortalScores[mapPriority.Selected]);string protectReason;if(found&&IsRouteTapProtected(point,out protectReason,verifiedJiaolongNpc,verifiedTargetPortal)){found=false;actionReason=actionReason+"；"+protectReason+((map==0||map==3)?"，继续坐标寻路":"，继续截图扫描（本帧未发出移动）");}if(map==0&&!found&&engine.Stable==map&&engine.Count>=3&&engine.Pending<0&&engine.Running){if(TraceStage("walk_mengzhong",delegate{return TryMoveMengzhongByCoord(b);}))return;}else if(map!=0||found){mzMoveTries=0;lastMzMove=DateTime.MinValue;if(map!=0)mzCoordReadyUntil=DateTime.MinValue;}if(map==3&&!found&&engine.Stable==map&&engine.Count>=3&&engine.Pending<0&&engine.Running){if(TraceStage("walk_shenlong",delegate{return TryMoveShenlongByCoord(b);}))return;}else if(map!=3||found){shenlongMoveTries=0;lastShenlongMove=DateTime.MinValue;}if(engine.Step(map,found,(DateTime.UtcNow-new DateTime(2020,1,1)).TotalSeconds)){TraceBeforeAction(b,"传送："+actionReason);bool clicked=ClickSmart(map,point,verifiedJiaolongNpc,verifiedTargetPortal);if(!clicked)RetryGuard("本次传送点击未发出，重新识别目标",3);else{if(map==3){RecordPriorityPortalClick();}else{lastTargetPortalClick=DateTime.MinValue;lastTargetPortalName="";}Log("已尝试点击"+(map==3?"目标传送点":"大陆传送")+"；"+actionReason+"；等待下一地图");}}
    if(map==4&&engine.Count>=3&&engine.Running)CheckAuto(b);if(map!=4)SuspendAutoBattle();
    if(map==3){int cx,cy;string cd;if(TryReadCoord(b,out cx,out cy,out cd))actionReason=actionReason+"；"+cd;}Log((map<0?lastRecognizeReason:names[map]+"（"+lastRecognizeReason+"；"+actionReason+"）")+" ｜ "+engine.Status);
   }
  }catch(Exception ex){TraceEvent("tick_exception","exception",ex.ToString());engine.Failures++;RetryGuard("后台读取或操作失败："+ex.Message,5);Log(engine.Status);}
 }
 bool IsRouteTapProtected(Point p,out string why,bool verifiedJiaolongNpc=false,bool verifiedTargetPortal=false){return RouteTapGuard.IsProtected(p,verifiedJiaolongNpc,verifiedTargetPortal,out why);}
 bool ClickSmart(int map,Point p,bool verifiedJiaolongNpc=false,bool verifiedTargetPortal=false){
  if(p==Point.Empty)return false;
  // One verified target, one tap, then let the existing state machine verify the new map.
  if(map==2||map==3){string why;if(IsRouteTapProtected(p,out why,verifiedJiaolongNpc,verifiedTargetPortal)){Log(why);return false;}return Click(p);}
  List<Point> pts=new List<Point>();pts.Add(p);
  if(map==3){pts.Add(new Point(p.X,Math.Max(10,p.Y-28)));pts.Add(new Point(p.X,Math.Min(675,p.Y+28)));pts.Add(new Point(Math.Max(10,p.X-28),p.Y));pts.Add(new Point(Math.Min(1210,p.X+28),p.Y));}
  else{pts.Add(new Point(p.X,Math.Max(10,p.Y-35)));pts.Add(new Point(p.X,Math.Min(675,p.Y+35)));pts.Add(new Point(Math.Max(10,p.X-30),p.Y));pts.Add(new Point(Math.Min(1210,p.X+30),p.Y));}
  bool ok=false,blocked=false;
  foreach(Point candidate in pts){if(!engine.Running)return ok;string why;if(IsRouteTapProtected(candidate,out why)){blocked=true;continue;}if(Click(candidate))ok=true;}
  if(!ok&&blocked)Log("已拦截风险点击：目标点在聊天/跑走保护区");return ok;
 }
 void CalMzStick(){engine.Stop("摇杆校准中");Ready();using(Bitmap raw=Raw())using(Bitmap b=Normalize(raw))using(var pick=new SelectRect(b,"框选左下角『跑/走』摇杆按钮，框中整个圆圈即可")){if(pick.ShowDialog()!=DialogResult.OK)return;Rectangle r=pick.Selection;mzStickCenter=new Point(r.X+r.Width/2,r.Y+r.Height/2);mzStickSet=true;coordDirReady=false;Log("摇杆已更改，请重新校准坐标方向");File.WriteAllLines(Path.Combine(data,"mz-stick.txt"),new[]{mzStickCenter.X.ToString(),mzStickCenter.Y.ToString()});Log("盟重左走摇杆已保存："+mzStickCenter.X+","+mzStickCenter.Y);}}
 bool CloseSkillPopup(Bitmap b){Rectangle r=new Rectangle(835,55,45,55).IntersectSafe(b);int red=0,total=0;for(int y=r.Top;y<r.Bottom;y++)for(int x=r.Left;x<r.Right;x++){Color c=b.GetPixel(x,y);if(c.R>150&&c.G<80&&c.B<80)red++;total++;}if(total>0&&(double)red/total>.03){engine.Status="检测到技能弹窗，先关闭";Log(engine.Status);Click(new Point(855,92));engine.Count=0;engine.Stable=-9;engine.UnknownSince=-1;return true;}return false;} bool ClickEnterMapDialog(Bitmap b){return ClickPriorityMapDialog(b);} bool CanEnterMapDialog(Bitmap b,out string reason){return CanEnterPriorityMapDialog(b,out reason);} bool ReadMengzhongCoord(Bitmap b,out int x,out int y,out string detail){
  // Never present an old coordinate as a successful reading of the current frame.
  return TryReadCoordDigits(b,3,out x,out y,out detail)&&x>=0&&x<=600&&y>=0&&y<=600;
 }
  void InitRecycle(Control top){
  recycleVision=new RecycleVision(root);recycleEnabled.Text="定时一键回收";recycleEnabled.AutoSize=true;recycleEnabled.Checked=true;
  recycleMinutes.Minimum=1;recycleMinutes.Maximum=1440;recycleMinutes.Value=3;recycleMinutes.Width=70;
  try{string[] a=File.ReadAllLines(Path.Combine(data,"recycle.txt"));recycleEnabled.Checked=bool.Parse(a[0]);recycleMinutes.Value=Math.Max(1,Math.Min(1440,decimal.Parse(a[1])));}catch{}
  top.Controls.Add(recycleEnabled);top.Controls.Add(new Label{Text="每",AutoSize=true,Padding=new Padding(0,6,0,0)});top.Controls.Add(recycleMinutes);top.Controls.Add(new Label{Text="分钟（自动保存）",AutoSize=true,Padding=new Padding(0,6,0,0)});
  recycleSettingsLoaded=true;recycleEnabled.CheckedChanged+=(s,e)=>SaveRecycle();recycleMinutes.ValueChanged+=(s,e)=>SaveRecycle();
 }
 void SaveRecycle(){if(!recycleSettingsLoaded)return;try{File.WriteAllLines(Path.Combine(data,"recycle.txt"),new[]{recycleEnabled.Checked.ToString(),recycleMinutes.Value.ToString()});nextRecycle=DateTime.Now.AddMinutes((double)recycleMinutes.Value);if(recycle.Stage!=0){RetryGuard("回收设置已更改，恢复页面后继续",2);recycle.Reset();}Log("回收设置已保存："+(recycleEnabled.Checked?"每 "+recycleMinutes.Value+" 分钟":"关闭"));}catch(Exception ex){RetryGuard("保存回收设置失败，继续守护",3);Log(ex.Message);}}
 // V4.9 handles and verifies these prompts before minimap recovery.
 bool CloseWelfarePopup(Bitmap b){return false;}
 bool CloseOpenPanel(Bitmap b){
  if(recycle.Stage!=0)return false;
  var v=recycleVision.Read(b);
  if(v.Page&&v.OneKey){engine.Status="检测到回收页面，先关闭后再守护";Log(engine.Status);Click(new Point(v.PageAt.X+411,v.PageAt.Y+10));engine.Count=0;engine.Stable=-9;return true;}
  if(v.Bag){engine.Status="检测到背包已打开，先关闭后再守护";Log(engine.Status);Click(new Point(v.BagAt.X+275,v.BagAt.Y-22));engine.Count=0;engine.Stable=-9;return true;}
  return false;
 }
 bool HandleRecycle(Bitmap b,int map){
  if(recycle.Stage!=0)map=ReadStrictTitleMap(b);
  if(recycle.Stage==0){if(!recycleEnabled.Checked||DateTime.Now<nextRecycle||map!=4||engine.Stable!=4||engine.Count<3||engine.Pending>=0||autoWaiting||!AutoBattleAllowsMaintenance(b))return false;recycle.Begin((DateTime.UtcNow-new DateTime(2020,1,1)).TotalSeconds);Log("开始定时一键回收：保留现有装备类别选择");}
  Point? p=recycle.Step(recycleVision.Read(b),map,(DateTime.UtcNow-new DateTime(2020,1,1)).TotalSeconds);
  if(p.HasValue&&!Click(p.Value)){engine.Failures++;nextRecycle=DateTime.Now.AddMinutes((double)recycleMinutes.Value);RetryGuard("本轮回收点击失败，继续守护，下一周期再回收",3);recycle.Reset();Log(engine.Status);return true;}
  if(recycle.Failed){SaveDiagnostic(b,map,"recycle-failed");engine.Failures++;string why=recycle.Status;recycle.Reset();nextRecycle=DateTime.Now.AddMinutes((double)recycleMinutes.Value);RetryGuard("本轮回收结束："+why+"；继续守护",3);Log(engine.Status);return true;}
  engine.Status=recycle.Status;Log(engine.Status);
  if(recycle.JustDone){nextRecycle=DateTime.Now.AddMinutes((double)recycleMinutes.Value);engine.Count=0;engine.Stable=-9;engine.UnknownSince=-1;}
  return true;
 }
 void InitRandom(Control top){
  randomEnabled.Text="低血量飞随机石";randomEnabled.AutoSize=true;randomEnabled.Checked=false;randomCooldown.Minimum=5;randomCooldown.Maximum=300;randomCooldown.Value=20;randomCooldown.Width=70;
  string[] randomSettings=new string[0];try{string[] a=File.ReadAllLines(Path.Combine(data,"random.txt"));randomSettings=a;randomEnabled.Checked=bool.Parse(a[0]);randomCooldown.Value=Math.Max(5,Math.Min(300,decimal.Parse(a[1])));randomPoint=new Point(int.Parse(a[2]),int.Parse(a[3]));randomPointSet=true;}catch{}
  top.Controls.Add(randomEnabled);top.Controls.Add(new Label{Text="冷却",AutoSize=true,Padding=new Padding(0,6,0,0)});top.Controls.Add(randomCooldown);top.Controls.Add(new Label{Text="秒",AutoSize=true,Padding=new Padding(0,6,0,0)});
  InitHealthThreshold(top,randomSettings);randomSettingsLoaded=true;randomEnabled.CheckedChanged+=(s,e)=>SaveRandom();randomCooldown.ValueChanged+=(s,e)=>SaveRandom();
 }
 void SaveRandom(){if(!randomSettingsLoaded)return;try{File.WriteAllLines(Path.Combine(data,"random.txt"),new[]{randomEnabled.Checked.ToString(),randomCooldown.Value.ToString(),randomPoint.X.ToString(),randomPoint.Y.ToString(),randomHpThreshold.Value.ToString()});ResetHealthEvidence();Log("随机石设置已保存：自身血量≤"+randomHpThreshold.Value+"%，连续2帧确认；冷却"+randomCooldown.Value+"秒"+(randomPointSet?"：已校准":"：未校准位置"));}catch(Exception ex){Log("随机石设置保存失败："+ex.Message);}}
 void CalRandom(){Ready();using(Bitmap raw=Raw())using(Bitmap b=Normalize(raw))using(var pick=new SelectRect(b,"框选快捷栏里的随机石按钮，框中它即可")){if(pick.ShowDialog()!=DialogResult.OK)return;randomPoint=new Point(pick.Selection.X+pick.Selection.Width/2,pick.Selection.Y+pick.Selection.Height/2);randomPointSet=true;SaveRandom();Log("随机石位置已保存："+randomPoint.X+","+randomPoint.Y);}}
 void Replay(){string result=Tests.Run(this,root)+Environment.NewLine+RecycleTests.Run(root)+Environment.NewLine+CalibrationTests.Run();Log(result);MessageBox.Show(result,"回放自检");}
 public void Smoke(){Show();Application.DoEvents();using(Bitmap b=new Bitmap(Width,Height)){DrawToBitmap(b,new Rectangle(0,0,Width,Height));b.Save(Path.Combine(root,"界面测试.png"));}File.WriteAllText(Path.Combine(root,"启动测试.txt"),Tests.Run(this,root)+Environment.NewLine+RecycleTests.Run(root)+Environment.NewLine+CalibrationTests.Run(),Encoding.UTF8);Close();}
}
static class RectExt {public static Rectangle IntersectSafe(this Rectangle r,Bitmap b){return Rectangle.Intersect(r,new Rectangle(0,0,b.Width,b.Height));}}
static class Tests {
 static void Assert(bool b,string m){if(!b)throw new Exception("自检失败："+m);}
 public static string Run(Guardian ui,string root){int n=0;for(int i=0;i<4;i++){string path=Path.Combine(root,"tests","route"+i+".png");if(File.Exists(path))using(Bitmap b=new Bitmap(path)){Assert(ui.Recognize(b)==i,"路线截图"+i);n++;}}
  Engine e=new Engine();e.Start();double t=0;for(int m=0;m<4;m++){Assert(!e.Step(m,true,t++),"首帧不得点击");Assert(!e.Step(m,true,t++),"双帧不得点击");Assert(e.Step(m,true,t++),"连续识别应点击");Assert(!e.Step(m,true,t++),"等待不得连点");}for(int j=0;j<3;j++)e.Step(4,false,t++);Assert(e.Returns==1&&e.Running,"回图计数");n++;
  foreach(int route in new[]{0,1,3}){e=new Engine();e.Start();e.Step(route,true,0);e.Step(route,true,1);Assert(e.Step(route,true,2),"首次传送");int limit=route==0?6:(route==3?8:3);double interval=route==3?5:16;for(int attempt=1;attempt<limit;attempt++)Assert(e.Step(route,true,2+attempt*interval),"有限重试中的允许次数 地图="+route);Assert(!e.Step(route,true,2+limit*interval)&&e.Running&&e.Failures==1,"本轮达到重试上限后仍持续守护 地图="+route);n++;}
  e=new Engine();e.Start();e.Step(-1,false,0);e.Step(-1,false,46);Assert(e.Running,"未知地图继续守护");n++;
  e=new Engine();e.Start();e.Step(0,true,0);e.Step(0,true,1);e.Step(0,true,2);e.Step(2,true,3);e.Step(2,true,4);e.Step(2,true,5);Assert(e.Running,"允许前进跳图");n++;
  e=new Engine();e.Start();e.Stop("stop");Assert(!e.Step(0,true,100),"停止无点击");n++;
  for(int i=0;i<4;i++){string path=Path.Combine(root,"tests","route"+i+".png");if(!File.Exists(path))continue;using(Bitmap b=new Bitmap(path))using(Bitmap tpl=new Bitmap(Path.Combine(root,"templates",i==3?"portal.png":"npc.png"))){Point q;double score=new Mask(tpl,true).Find(new Mask(b,true),new Rectangle(50,100,925,445),out q);Assert(score>=.77,"NPC/传送门识别 "+i+" 分数="+score);n++;}}
  using(Bitmap blank=new Bitmap(1216,684)){Assert(ui.Recognize(blank)==-1,"黑屏不得认作地图");n++;}
  return "通过 "+n+" 项：四张地图与NPC/传送门、完整回图、分轮重试、未知地图持续识别、顺序验证、停止保护、黑屏保护。";
 }
}
static class Program {[STAThread]static void Main(string[] args){Native.SetProcessDPIAware();Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);try{if(args.Contains("--background-probe")||args.Contains("--background-tap-test")){BackgroundProbe.Run(AppDomain.CurrentDomain.BaseDirectory,args.Contains("--background-tap-test"));return;}var f=new Guardian();if(args.Contains("--minimap-test")){f.MinimapSmoke();return;}if(args.Contains("--v47-test")){f.V47Smoke();return;}if(args.Contains("--route-guard-test")){f.RouteGuardSmoke();return;}if(args.Contains("--navigation-test")){f.NavigationSmoke();return;}if(args.Contains("--focus-test")){f.FocusSmoke();return;}if(args.Contains("--self-test")){f.Smoke();return;}Application.Run(f);}catch(Exception ex){if(args.Contains("--minimap-test")||args.Contains("--v47-test")||args.Contains("--route-guard-test")||args.Contains("--navigation-test")||args.Contains("--focus-test")||args.Contains("--self-test")||args.Contains("--background-probe")||args.Contains("--background-tap-test"))File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"测试失败.txt"),ex.ToString());else MessageBox.Show(ex.ToString(),"启动失败");Environment.ExitCode=1;}}}












































