using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;

public enum BossRowStatus { Unknown, Countdown, Ready, Challenge }
public sealed class BossRow {
 public string Name="",Detail="";
 public BossRowStatus Status;
 public Point? Button;
 public Rectangle CountdownRect;
}
public sealed class BossView {
 public Point? Entry,Close,ChallengeButton,ChallengeActionPoint;
 // A row click can open a native confirmation before the list shell or
 // challenge detail changes.  The confirm point is an input target only when
 // both controls have been read from the same current frame.
 public Point? TeleportConfirm,TeleportCancel;
 public Rectangle TeleportMessageRect;
 public bool TeleportPrompt;
 public Rectangle ChallengeNameRect,ChallengeLevelRect;
 // List authorizes row interpretation. ListShell grants only its verified
 // close control; SuspectedList grants ownership/waiting but no click target.
 public bool List,ListShell,SuspectedList,Challenge,ChallengeLevelGreen,ChallengeCostsVisible;
 public int ChallengeRequiredLevel;
 public string ChallengeName="",Detail="";
 public Rectangle NameSearchRect;public Point RowHeader;public string RowProfile="";
 public readonly List<BossRow> Rows=new List<BossRow>();
}

// Screenshot-only observation. All points refer to an actual game capture
// normalized to 1216x684. No clicks, timers, process memory, or desktop capture.
public sealed class BossVision {
 enum Ink { Gold,Magenta,Green,Cyan,Color,Red,Header }
 static readonly string[] Names=BossTargets.Names;
 readonly Dictionary<string,Patch> patches=new Dictionary<string,Patch>();
 readonly Patch[] names=new Patch[Names.Length];
 readonly Patch[] nativeNames=new Patch[Names.Length];
 static bool Green(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return g>100&&g>r*1.4&&g>b*1.3;}
 static bool Red(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return r>135&&r>g*1.75&&r>b*1.65;}
 static bool On(int p,Ink kind){
  int r=(p>>16)&255,g=(p>>8)&255,b=p&255;
  if(kind==Ink.Green)return Green(p);
  if(kind==Ink.Header)return r>90&&g>90&&b>80&&Math.Max(r,Math.Max(g,b))-Math.Min(r,Math.Min(g,b))<45;
  if(kind==Ink.Red)return Red(p);
  if(kind==Ink.Magenta)return r>120&&b>100&&r>g*1.7&&b>g*1.5;
  if(kind==Ink.Cyan)return g>105&&b>110&&g>r*1.45&&b>r*1.45;
  if(kind==Ink.Color)return Green(p)||On(p,Ink.Magenta)||On(p,Ink.Cyan)||(r>150&&g>130&&b>120)||(r>145&&g>85&&g>b*1.25);
  return r>125&&g>105&&r>=g*.9&&g>=b*.95;
 }
 sealed class Region {
  internal readonly Rectangle Area;internal readonly bool[] Bits;readonly int[] sums;readonly int stride;
  internal Region(int[] pixels,Rectangle area,Ink kind){Area=area;Bits=new bool[area.Width*area.Height];stride=area.Width+1;sums=new int[stride*(area.Height+1)];
   for(int y=0;y<area.Height;y++){int row=0;for(int x=0;x<area.Width;x++){bool on=On(pixels[(area.Y+y)*1216+area.X+x],kind);Bits[y*area.Width+x]=on;if(on)row++;sums[(y+1)*stride+x+1]=sums[y*stride+x+1]+row;}}
  }
  internal int Count(int x,int y,int w,int h){return sums[(y+h)*stride+x+w]-sums[y*stride+x+w]-sums[(y+h)*stride+x]+sums[y*stride+x];}
 }
 sealed class Patch {
  internal readonly int W,H,Count,Left,Top;readonly Point[] points;readonly int[] portions=new int[4];
  internal Patch(string file,Ink kind){using(Bitmap b=new Bitmap(file)){
   int[] px=FrameCache.Pixels(b);int left=b.Width,top=b.Height,right=-1,bottom=-1;
   for(int y=0;y<b.Height;y++)for(int x=0;x<b.Width;x++)if(On(px[y*b.Width+x],kind)){left=Math.Min(left,x);top=Math.Min(top,y);right=Math.Max(right,x);bottom=Math.Max(bottom,y);}
   Left=left;Top=top;W=Math.Max(0,right-left+1);H=Math.Max(0,bottom-top+1);var list=new List<Point>();
   for(int y=top;y<=bottom;y++)for(int x=left;x<=right;x++)if(On(px[y*b.Width+x],kind)){Point p=new Point(x-left,y-top);list.Add(p);portions[Math.Min(3,p.X*4/W)]++;}
   var ordered=new List<Point>();for(int k=0;k<23;k++)for(int i=k;i<list.Count;i+=23)ordered.Add(list[i]);points=ordered.ToArray();Count=points.Length;
  }}
  internal double At(int[] pixels,int cropX,int cropY,Ink kind){
   int x=cropX+Left,y=cropY+Top;if(Count<14||x<0||y<0||x+W>1216||y+H>684)return 0;
   int actual=0,hit=0;for(int yy=0;yy<H;yy++)for(int xx=0;xx<W;xx++)if(On(pixels[(y+yy)*1216+x+xx],kind))actual++;
   foreach(Point p in points)if(On(pixels[(y+p.Y)*1216+x+p.X],kind))hit++;
   return 2.0*hit/(Count+actual);
  }
  internal double Find(Region frame,out Point center,double part){center=Point.Empty;if(Count<14||W==0||H==0)return 0;double best=0;int width=frame.Area.Width;
   for(int y=0;y<=frame.Area.Height-H;y++)for(int x=0;x<=width-W;x++){
    int actual=frame.Count(x,y,W,H);if(actual<Count*.60||actual>Count*1.65||2.0*Math.Min(actual,Count)/(actual+Count)<=best)continue;
    int hit=0,n=0,a=0,b=0,c=0,d=0;
    for(;n<points.Length;n++){Point p=points[n];if(frame.Bits[(y+p.Y)*width+x+p.X]){hit++;int q=Math.Min(3,p.X*4/W);if(q==0)a++;else if(q==1)b++;else if(q==2)c++;else d++;}if(n==47&&hit<27)break;}
    if(n<points.Length||a<portions[0]*part||b<portions[1]*part||c<portions[2]*part||d<portions[3]*part)continue;
    double score=2.0*hit/(Count+actual);if(score>best){best=score;center=new Point(frame.Area.X+x+W/2,frame.Area.Y+y+H/2);}
   }return best;
  }
 }
 public BossVision(string root){string dir=Directory.Exists(Path.Combine(root,"templates"))?Path.Combine(root,"templates"):root;
  foreach(string key in new[]{"entry-label","entry-icon","list-title","list-close","list-column-name","list-column-status","action-challenge","challenge-title","challenge-close","challenge-cost-heading","challenge-button"})Load(dir,key,Ink.Gold);
  Load(dir,"status-ready",Ink.Cyan);Load(dir,"status-challenge",Ink.Color);Load(dir,"action-kill",Ink.Green);
  for(int i=0;i<8;i++)Load(dir,"challenge-price-"+i,Ink.Gold);
  Load(dir,"challenge-level-78",Ink.Green);Load(dir,"challenge-name-stone",Ink.Green);Load(dir,"challenge-costs",Ink.Color);
  string[] ids={"outpost","overlord","stone","fortress","chief","ghost"};for(int i=0;i<ids.Length;i++){Load(dir,"name-"+ids[i],Ink.Magenta);patches.TryGetValue("name-"+ids[i],out names[i]);}
  foreach(string key in new[]{"list-title","list-close","list-column-name","list-column-status","action-challenge"})LoadNative(dir,key,Ink.Gold);
  LoadNative(dir,"status-ready",Ink.Cyan);LoadNative(dir,"status-challenge",Ink.Color);LoadNative(dir,"status-challenge-alt",Ink.Color);LoadNative(dir,"action-kill",Ink.Green);
  foreach(string key in new[]{"list-column-name","list-column-status"}){string file=Path.Combine(dir,"boss-v41910-"+key+".png");if(File.Exists(file))patches["native-"+key+"-alt"]=new Patch(file,Ink.Header);}
  for(int i=0;i<ids.Length;i++){LoadNative(dir,"name-"+ids[i],Ink.Magenta);patches.TryGetValue("native-name-"+ids[i],out nativeNames[i]);}
  if(names[4]==null)names[4]=nativeNames[4];
  LoadEntryNative(dir,"entry-label");LoadEntryNative(dir,"entry-icon");
  // Native V4.19.3 prompt crops are deliberately limited to the message and
  // the two controls.  The dimmed panel behind them is not an input gate.
  LoadNative4193(dir,"teleport-confirm-message",Ink.Gold);
  LoadNative4193(dir,"teleport-confirm-ok",Ink.Gold);
  LoadNative4193(dir,"teleport-confirm-cancel",Ink.Gold);
  // The challenge detail uses a different raster from the older challenge
  // fixture.  Keep it as a separate profile so a list heading or a dimmed
  // confirmation frame can never authorize a challenge click.
  foreach(string key in new[]{"challenge-title","challenge-close","challenge-cost-heading","challenge-button"})LoadNative4193(dir,key,Ink.Gold);
  LoadNative4193(dir,"challenge-costs",Ink.Color);
  LoadNative4193(dir,"challenge-name-fortress",Ink.Green);
  LoadNative4193(dir,"challenge-level-75",Ink.Green);
  for(int i=0;i<8;i++)LoadNative4193(dir,"challenge-price-"+i,Ink.Color);
 }
 void Load(string dir,string key,Ink ink){string path=Path.Combine(dir,"boss-v419-"+key+".png");if(!File.Exists(path))return;try{patches[key]=new Patch(path,ink);}catch(ArgumentException){}catch(IOException){}}
 void LoadNative(string dir,string key,Ink ink){string path=Path.Combine(dir,"boss-v4191-"+key+".png");if(!File.Exists(path))return;try{patches["native-"+key]=new Patch(path,ink);}catch(ArgumentException){}catch(IOException){}}
 void LoadNative4193(string dir,string key,Ink ink){string path=Path.Combine(dir,"boss-v4193-"+key+".png");if(!File.Exists(path))return;try{patches["native-"+key]=new Patch(path,ink);}catch(ArgumentException){}catch(IOException){}}
 void LoadEntryNative(string dir,string key){string path=Path.Combine(dir,"boss-v4193-"+key+".png");if(!File.Exists(path))return;try{patches["native-"+key]=new Patch(path,Ink.Gold);}catch(ArgumentException){}catch(IOException){}}
 static Rectangle Box(int x,int y,int w,int h){return Rectangle.Intersect(new Rectangle(x,y,w,h),new Rectangle(0,0,1216,684));}
 static string F(double score){return score.ToString("0.00",System.Globalization.CultureInfo.InvariantCulture);}
 double Find(string key,int[] pixels,Rectangle area,Ink kind,out Point point){Patch patch;point=Point.Empty;return patches.TryGetValue(key,out patch)?patch.Find(new Region(pixels,area,kind),out point,.65):0;}
 static int Count(int[] pixels,Rectangle area,Ink kind){int n=0;for(int y=area.Top;y<area.Bottom;y++)for(int x=area.Left;x<area.Right;x++)if(On(pixels[y*1216+x],kind))n++;return n;}
 public BossView Read(Bitmap image){if(image==null||image.Width!=1216||image.Height!=684)return new BossView{Detail="BOSS识别需要1216x684游戏画面"};return FrameCache.Get<BossView>(image,this,"boss-view",delegate{return ReadFrame(image);});}
 BossView ReadFrame(Bitmap image){var result=new BossView();int[] pixels=FrameCache.Pixels(image);Point header,close,col1,col2;
  // The teleport confirmation is drawn over the list and darkens row text.
  // Own it before list-shell recognition so an obscured row can never be
  // interpreted as a new candidate or cause another row click.
  if(ReadTeleportPrompt(result,pixels))return result;
  double title=Find("list-title",pixels,Box(470,45,270,100),Ink.Gold,out header);
  Point nativeHeader;double nativeTitle=Find("native-list-title",pixels,Box(470,45,270,100),Ink.Gold,out nativeHeader);
  // The older fixture was enlarged from an 853px desktop crop. Native game
  // captures have a different glyph raster: select a complete observed
  // profile, keeping the same confidence gates rather than lowering them.
  string profile="";if(nativeTitle>title){title=nativeTitle;header=nativeHeader;profile="native-";}
  double cs=Find(profile+"list-close",pixels,Box(header.X+385,header.Y-35,80,80),Ink.Gold,out close);
  double c1=Find(profile+"list-column-name",pixels,Box(header.X-368,header.Y+105,130,45),Ink.Gold,out col1);
  double c2=Find(profile+"list-column-status",pixels,Box(header.X-55,header.Y+105,125,45),Ink.Gold,out col2);
  if(profile.Length>0){Point alternate;c1=Math.Max(c1,Find("native-list-column-name-alt",pixels,Box(header.X-368,header.Y+105,130,45),Ink.Header,out alternate));c2=Math.Max(c2,Find("native-list-column-status-alt",pixels,Box(header.X-55,header.Y+105,125,45),Ink.Header,out alternate));}
  result.SuspectedList=title>=.80;
  result.ListShell=result.SuspectedList&&cs>=.84&&Count(pixels,Box(close.X-7,close.Y-12,14,24),Ink.Red)>=55;
  if(result.ListShell){
   result.Close=close;result.List=c1>=.78&&c2>=.78;result.Detail="BOSS奖励"+(result.List?"列表":"外框，列头待确认")+"：图样="+(profile.Length==0?"旧截图":"原生截图")+"，完整标题="+F(title)+"，关闭="+F(cs)+"，双列头="+F(c1)+"/"+F(c2);
   if(result.List)ReadRows(result,pixels,header,profile);return result;
  }
  Point challengeHeader;double ch=Find("challenge-title",pixels,Box(480,145,255,100),Ink.Gold,out challengeHeader);
  Point nativeChallengeHeader;double nativeCh=Find("native-challenge-title",pixels,Box(480,145,255,100),Ink.Gold,out nativeChallengeHeader);
  string challengeProfile="";
  if(nativeCh>ch){ch=nativeCh;challengeHeader=nativeChallengeHeader;challengeProfile="native-";}
  double cc=Find(challengeProfile+"challenge-close",pixels,Box(challengeHeader.X+275,challengeHeader.Y-35,75,85),Ink.Gold,out close);
  Point costsHeading;double co=Find(challengeProfile+"challenge-cost-heading",pixels,Box(challengeHeader.X-120,challengeHeader.Y+60,240,90),Ink.Gold,out costsHeading);
  if(ch>=.82&&cc>=.84&&co>=.80&&Count(pixels,Box(close.X-7,close.Y-12,14,24),Ink.Red)>=55){
   result.Challenge=true;result.Close=close;ReadChallenge(result,pixels,challengeHeader,challengeProfile);result.Detail="BOSS挑战：完整标题="+F(ch)+"，关闭="+F(cc)+"；"+result.Detail;return result;
  }
  double el,ei,nativeEl,nativeEi;Point? legacyEntry=ReadEntry(pixels,"",out el,out ei);
  Point? nativeEntry=ReadEntry(pixels,"native-",out nativeEl,out nativeEi);
  // Each observed raster profile must independently match the whole label
  // and icon in the same spatial pair. Never combine one profile's label
  // with another profile's icon or infer an input from the search region.
  result.Entry=nativeEntry.HasValue?nativeEntry:legacyEntry;
  result.Detail="BOSS入口="+F(el)+"/"+F(ei)+"；原生入口="+F(nativeEl)+"/"+F(nativeEi)+"；列表="+F(title)+"/"+F(cs)+"/"+F(c1)+"/"+F(c2)+"；挑战="+F(ch)+"/"+F(cc)+"/"+F(co)+"；挑战图样="+(challengeProfile.Length>0?"原生":"旧截图");return result;
 }
 bool ReadTeleportPrompt(BossView result,int[] pixels){
  Point message,confirm,cancel;
  // Keep these search areas around the observed native modal.  Narrow button
  // regions also prevent the two similar text controls from cross-matching.
  double ms=Find("native-teleport-confirm-message",pixels,Box(365,245,305,90),Ink.Gold,out message);
  if(ms<.82)return false;
  double os=Find("native-teleport-confirm-ok",pixels,Box(585,345,145,75),Ink.Gold,out confirm);
  double cs=Find("native-teleport-confirm-cancel",pixels,Box(700,345,145,75),Ink.Gold,out cancel);
  result.TeleportPrompt=true;
  result.TeleportMessageRect=Box(message.X-115,message.Y-15,230,31);
  bool controls=os>=.84&&cs>=.84&&confirm.X<cancel.X&&cancel.X-confirm.X>=55&&cancel.X-confirm.X<=180&&Math.Abs(confirm.Y-cancel.Y)<=10;
  if(controls){result.TeleportConfirm=confirm;result.TeleportCancel=cancel;}
  result.Detail="BOSS传送确认提示：消息="+F(ms)+"；确定="+F(os)+"；取消="+F(cs)+(controls?"；控件成对确认":"；控件待确认");
  return true;
 }
 Point? ReadEntry(int[] pixels,string profile,out double labelScore,out double iconScore){
  Point label,icon;labelScore=Find(profile+"entry-label",pixels,Box(650,78,105,42),Ink.Gold,out label);iconScore=0;
  if(labelScore<.83)return null;
  iconScore=Find(profile+"entry-icon",pixels,Box(label.X-42,label.Y-70,85,63),Ink.Gold,out icon);
  if(iconScore>=.81&&Math.Abs(icon.X-label.X)<=8&&label.Y-icon.Y>=21&&label.Y-icon.Y<=48)return new Point(icon.X,(icon.Y+label.Y)/2);
  return null;
 }
 void ReadRows(BossView result,int[] pixels,Point header,string profile){
  Region region=new Region(pixels,Box(header.X-372,header.Y+154,177,365),Ink.Magenta);result.NameSearchRect=region.Area;result.RowHeader=header;result.RowProfile=profile;
  var rowNames=profile.Length==0?names:nativeNames;
  for(int i=0;i<Names.Length;i++){if(rowNames[i]==null)continue;Point name;double ns=rowNames[i].Find(region,out name,.72);if(i==5)result.Detail+="；游荡鬼王名称候选="+F(ns);if(ns<.82)continue;
   // The action and timer are anchored to this complete name's observed Y.
   // Scrolling changes the row Y freely; no saved list index is used.
   var row=new BossRow{Name=Names[i],CountdownRect=Box(header.X-55,name.Y-12,128,25)};
   Point kill,challenge,status;double ks=Find(profile+"action-kill",pixels,Box(header.X+260,name.Y-15,130,33),Ink.Green,out kill);
   double bs=Find(profile+"action-challenge",pixels,Box(header.X+260,name.Y-15,130,33),Ink.Gold,out challenge);
   double rs=Find(profile+"status-ready",pixels,Box(header.X-40,name.Y-15,100,33),Ink.Cyan,out status);
   double qs=Find(profile+"status-challenge",pixels,Box(header.X-73,name.Y-15,170,33),Ink.Color,out status);
   // The two real challenge rows have different vertical sampling phases.
   // Both complete status glyphs were observed; neither is synthesized.
   if(profile.Length>0){Point alternate;qs=Math.Max(qs,Find(profile+"status-challenge-alt",pixels,Box(header.X-73,name.Y-15,170,33),Ink.Color,out alternate));}
   int reds=Count(pixels,row.CountdownRect,Ink.Red);
   if(ks>=.83&&rs>=.82&&Math.Abs(kill.Y-name.Y)<=5){row.Status=BossRowStatus.Ready;row.Button=kill;}
   else if(bs>=.83&&qs>=.81&&Math.Abs(challenge.Y-name.Y)<=5){row.Status=BossRowStatus.Challenge;row.Button=challenge;}
   else if(ks>=.83&&reds>=15&&Math.Abs(kill.Y-name.Y)<=5)row.Status=BossRowStatus.Countdown;
   row.Detail=Names[i]+"完整名="+F(ns)+"；击杀="+F(ks)+"；已刷新="+F(rs)+"；挑战="+F(bs)+"/"+F(qs)+"；红字="+reds;
   result.Rows.Add(row);result.Detail+="；"+row.Detail;
  }
 }
 public void ReadGhostRow(Bitmap frame,BossView result,Point name){
  if(!result.List||!result.NameSearchRect.Contains(name)||result.Rows.Exists(r=>r.Name=="游荡鬼王"))return;
  int[] pixels=FrameCache.Pixels(frame);Point header=result.RowHeader;string profile=result.RowProfile;
  var row=new BossRow{Name="游荡鬼王",CountdownRect=Box(header.X-55,name.Y-12,128,25)};Point kill,challenge,status;
  double ks=Find(profile+"action-kill",pixels,Box(header.X+260,name.Y-15,130,33),Ink.Green,out kill);
  double bs=Find(profile+"action-challenge",pixels,Box(header.X+260,name.Y-15,130,33),Ink.Gold,out challenge);
  double rs=Find(profile+"status-ready",pixels,Box(header.X-40,name.Y-15,100,33),Ink.Cyan,out status);
  double qs=Find(profile+"status-challenge",pixels,Box(header.X-73,name.Y-15,170,33),Ink.Color,out status);
  if(profile.Length>0){Point other;qs=Math.Max(qs,Find(profile+"status-challenge-alt",pixels,Box(header.X-73,name.Y-15,170,33),Ink.Color,out other));}
  if(ks>=.83&&rs>=.82&&Math.Abs(kill.Y-name.Y)<=5){row.Status=BossRowStatus.Ready;row.Button=kill;}
  else if(bs>=.83&&qs>=.81&&Math.Abs(challenge.Y-name.Y)<=5){row.Status=BossRowStatus.Challenge;row.Button=challenge;}
  else if(ks>=.83&&Count(pixels,row.CountdownRect,Ink.Red)>=15)row.Status=BossRowStatus.Countdown;
  row.Detail="游荡鬼王完整名称OCR定位；同一行状态与动作核对";result.Rows.Add(row);
 }
 void ReadChallenge(BossView result,int[] pixels,Point header,string profile=""){
  result.ChallengeNameRect=Box(header.X-100,header.Y+37,210,43);
  Region region=new Region(pixels,result.ChallengeNameRect,Ink.Green);double best=0,runner=0;int winner=-1;
  for(int i=0;i<names.Length;i++){Point p;double score=names[i]==null?0:names[i].Find(region,out p,.68);if(i==3){score=Math.Max(score,Find("native-challenge-name-fortress",pixels,region.Area,Ink.Green,out p));}if(i==2){double native=Find("challenge-name-stone",pixels,region.Area,Ink.Green,out p);score=Math.Max(score,native);}if(score>best){runner=best;best=score;winner=i;}else runner=Math.Max(runner,score);}
  if(winner>=0&&best>=.79&&best-runner>=.08)result.ChallengeName=Names[winner];
  Point costs;double cost=Find(profile+"challenge-costs",pixels,Box(header.X-165,header.Y+120,340,65),Ink.Color,out costs);
  result.ChallengeCostsVisible=cost>=.90;
  int[] priceDx={-95,-86,-76,-66,-58,5,14,141};double priceMin=1;
  if(profile.Length==0){
   for(int d=0;d<priceDx.Length;d++){Point price;double ps=Find("challenge-price-"+d,pixels,Box(costs.X+priceDx[d]-8,costs.Y-10,18,23),Ink.Gold,out price);priceMin=Math.Min(priceMin,ps);if(ps<.88)result.ChallengeCostsVisible=false;}
  }else{
   // Verify each price at its exact location relative to the observed line.
   // A broad line score alone can hide a changed final ticket count.
   Patch line;int[] digitX={514,523,533,542,552,614,623,750};
   if(!patches.TryGetValue(profile+"challenge-costs",out line)){result.ChallengeCostsVisible=false;priceMin=0;}
   else for(int d=0;d<digitX.Length;d++){
    Patch digit;double ps=patches.TryGetValue(profile+"challenge-price-"+d,out digit)?digit.At(pixels,costs.X-line.W/2-line.Left+digitX[d]-465,costs.Y-line.H/2-line.Top+2,Ink.Color):0;
    priceMin=Math.Min(priceMin,ps);if(ps<.92)result.ChallengeCostsVisible=false;
   }
  }
  Point level;Rectangle levelArea=Box(header.X-85,header.Y+215,180,35);result.ChallengeLevelRect=levelArea;double ls=Find(profile+"challenge-level-75",pixels,levelArea,Ink.Green,out level);
  if(ls>=.83)result.ChallengeRequiredLevel=75;
  if(ls<.83){ls=Find("challenge-level-78",pixels,levelArea,Ink.Green,out level);if(ls>=.83)result.ChallengeRequiredLevel=78;}
  // Complete observed green conditions are accepted; other levels use the
  // bounded local OCR in BossUi. Red or unreadable conditions veto.
  int green=Count(pixels,levelArea,Ink.Green),red=Count(pixels,levelArea,Ink.Red);
  result.ChallengeLevelGreen=ls>=.83&&green>=100&&red<8;
  Point button;double buttonScore=Find(profile+"challenge-button",pixels,Box(header.X-100,header.Y+225,220,100),Ink.Gold,out button);
  if(buttonScore<.84)buttonScore=Find("challenge-button",pixels,Box(header.X-100,header.Y+225,220,100),Ink.Gold,out button);
  if(buttonScore>=.84)result.ChallengeActionPoint=button;
  // Unknown name, condition, cost, or action leaves no fully gated point.
  if(result.ChallengeName.Length>0&&result.ChallengeLevelGreen&&result.ChallengeCostsVisible&&buttonScore>=.84)result.ChallengeButton=button;
  result.Detail="完整BOSS="+(result.ChallengeName.Length==0?"未知":result.ChallengeName)+" "+F(best)+"/"+F(runner)+"；消耗="+F(cost)+"/逐位="+F(priceMin)+"；绿色等级="+F(ls)+" "+green+"/"+red+"；我要挑战="+F(buttonScore);
 }
}




