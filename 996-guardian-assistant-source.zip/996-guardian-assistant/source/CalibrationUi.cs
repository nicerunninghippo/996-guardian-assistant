using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Drawing;

partial class Guardian {
 DirectionCalibration coordCalibration=new DirectionCalibration();
 int coordCalWidth,coordCalHeight,coordTableWidth,coordTableHeight,coordMoveDuration=550,coordFrameNo;
 Point coordTableCenter;
 string coordCalDir;

 void StopAll(string reason) { TraceEvent("guard_stop","reason",reason,"was_running",engine.Running,"was_requested",guardRequested);ResetMaintenance();ResetMinimapRecovery();ResetBoxPopup();ResetHealthEvidence();ResetAutoBattle();ResetBoss();ResetHellRoute(false);guardRequested=false;guardResumeAt=DateTime.MaxValue;
  if(coordCalibration.Active){coordCalibration.Cancel(reason+"；方向校准已取消，本次数据未保存");Log(coordCalibration.Status);}
  engine.Stop(reason);
 }
 void LoadCoordDirections() {
  coordDirReady=false;
  try {
   string f=Path.Combine(data,"coord-directions.txt");if(!File.Exists(f))return;
   string[] lines=File.ReadAllLines(f,Encoding.UTF8);
   // V4.2 saved even all-zero/partial tables and omitted geometry. Do not trust those files.
   if(lines.Length!=9 || !lines[0].StartsWith("v4.4,")){Log("坐标识别已更新，请重新校准方向；旧表不参与走路");return;}
   string[] head=lines[0].Split(',');if(head.Length!=5)return;
   coordTableCenter=new Point(int.Parse(head[1]),int.Parse(head[2]));
   coordTableWidth=int.Parse(head[3]);coordTableHeight=int.Parse(head[4]);
   if(!mzStickSet||coordTableCenter!=mzStickCenter)return;
   int[] dx=new int[8],dy=new int[8];
   for(int i=0;i<8;i++) {
    string[] a=lines[i+1].Split(',');if(a.Length!=5||int.Parse(a[0])!=coordDirOffsets[i].X||int.Parse(a[1])!=coordDirOffsets[i].Y)return;
    dx[i]=int.Parse(a[2]);dy[i]=int.Parse(a[3]);
   }
   string reason;if(!DirectionCalibration.ValidTable(dx,dy,out reason)){Log("方向表未通过校验："+reason);return;}
   coordDirDx=dx;coordDirDy=dy;coordDirReady=true;Log("有效方向表已加载；连接后核对游戏分辨率");
  } catch(Exception ex){Log("方向表读取失败："+ex.Message);}
 }
 int CalibrationMap(Bitmap b) {
  if(ReadTownTitle(b).Town)return 0;if(ReadHellMap(b)==5)return 5;
  using(Bitmap title=b.Clone(new Rectangle(1067,31,149,34).IntersectSafe(b),b.PixelFormat)) {
   Mask frame=new Mask(title,false);double best=0,second=0;int map=-1;
   for(int i=0;i<4;i++){if(maps[i]==null)continue;Point p;double score=maps[i].Find(frame,new Rectangle(0,0,title.Width,title.Height),out p);
    if(score>best){second=best;best=score;map=i;}else if(score>second)second=score;
   }
   return best>=.74&&best-second>=.04?map:-1;
  }
 }
 bool ReadCoordForCalibration(Bitmap b,int map,out int x,out int y,out string detail) {
  x=y=-1;detail="地图名未确认";if(map<0||map>5||map==4)return false;
  // Mengzhong is 3+3; Shenlong must never be tried as 3+1 first.
  if(!TryReadCoordDigits(b,map==0?3:0,out x,out y,out detail))return false;
  if((map==3||map==5)&&(x>99||y>99)){detail+="；神龙坐标位数异常";return false;}
  return x>=0&&x<=600&&y>=0&&y<=600;
 }
 void CalCoordDirections() {
  Ready();if(!backgroundConnected)throw new Exception("请先连接雷电后台接口");
  if(System.Diagnostics.Process.GetProcessesByName(System.Diagnostics.Process.GetCurrentProcess().ProcessName).Length>1)throw new Exception("请先关闭其他助手窗口，避免校准时被另一版本同时操作");
  if(!mzStickSet)throw new Exception("请先用校准跑/走摇杆框中左下角一个完整圆形按钮");
  if(mzStickCenter.X<62||mzStickCenter.X>270||mzStickCenter.Y<390||mzStickCenter.Y>621)throw new Exception("摇杆位置不在左下跑/走区域，请重新框选一个圆形按钮");
  guardResumeAt=DateTime.Now.AddSeconds(10);engine.Stop("校准准备中");recycle.Reset();autoWaiting=false;
  using(Bitmap raw=Raw())using(Bitmap b=Normalize(raw)) {
   int map=CalibrationMap(b),x,y;string detail;
   if(!ReadCoordForCalibration(b,map,out x,out y,out detail))throw new Exception("校准起点地图或坐标未读清；请露出右上角地图与坐标。"+detail);
   coordCalWidth=backend.Width;coordCalHeight=backend.Height;coordFrameNo=0;
   coordCalDir=Path.Combine(data,"diagnostics","coord-cal-"+DateTime.Now.ToString("yyyyMMdd-HHmmss-fff"));
   Directory.CreateDirectory(coordCalDir);b.Save(Path.Combine(coordCalDir,"start.png"));
   coordCalibration.Begin(map,mzStickCenter);engine.Status=coordCalibration.Status;
   Log("V4.7 方向校准开始；地图="+new[]{"盟重省","次元大陆","蛟龙领地","神龙帝国","目标地图","冥界"}[map]+"；起点="+x+":"+y+"；摇杆="+mzStickCenter+"；截图="+coordCalWidth+"×"+coordCalHeight+"；诊断目录="+coordCalDir);
  }
 }
 bool CalibrationSwipe(Point from,Point to,int ms) {
  return CalibrationInput.Send(coordCalibration.Active,engine.Running,backgroundConnected,Native.GetAsyncKeyState(0x77)!=0,from,to,ms,delegate(Point a,Point b,int duration){return TraceInput("calibration_swipe",a,b,duration,true,delegate{return backend.Swipe(a,b,duration);});});
 }
 void TickCoordCalibration() {
  try {
   double now=(DateTime.UtcNow-new DateTime(2020,1,1)).TotalSeconds;
   if(now<coordCalibration.NextAt)return;
   using(Bitmap raw=Raw())using(Bitmap b=Normalize(raw)) {
    if(backend.Width!=coordCalWidth||backend.Height!=coordCalHeight){coordCalibration.Cancel("校准期间游戏分辨率变化，已中止；请固定分辨率后重试");}
    else {
     if(preview.Image!=null)preview.Image.Dispose();preview.Image=new Bitmap(b);
     int map=CalibrationMap(b),x,y;string detail;
     bool read=ReadCoordForCalibration(b,map,out x,out y,out detail);
     using(Bitmap crop=b.Clone(new Rectangle(1067,31,149,180),b.PixelFormat))crop.Save(Path.Combine(coordCalDir,(++coordFrameNo).ToString("D3")+"-coordinate.png"));
     Log("校准采样 "+coordFrameNo+" 地图="+map+" "+(read?"读数="+x+":"+y:"读数无效")+"；"+detail);
     coordCalibration.Step(read?(Point?)new Point(x,y):null,map,now,CalibrationSwipe,Log);
    }
    engine.Status=coordCalibration.Status;
    if(!coordCalibration.Active) {
     b.Save(Path.Combine(coordCalDir,"end.png"));
     if(coordCalibration.Success)SaveCoordDirections();
     else {guardResumeAt=DateTime.Now.AddSeconds(8);Log(coordCalibration.Status+(guardRequested?"；守护仍开启，8秒后继续识别并重试":"；本次未保存"));}
    }
   }
  } catch(Exception ex){coordCalibration.Cancel("方向校准异常："+ex.Message+"；本次数据未保存");guardResumeAt=DateTime.Now.AddSeconds(8);engine.Stop(coordCalibration.Status);Log(engine.Status);}
  state.Text="已连接 ｜ "+engine.Status;
 }
 void SaveCoordDirections() {
  string reason;if(!DirectionCalibration.ValidTable(coordCalibration.Dx,coordCalibration.Dy,out reason))throw new Exception(reason);
  string[] lines=new string[9];lines[0]="v4.4,"+mzStickCenter.X+","+mzStickCenter.Y+","+coordCalWidth+","+coordCalHeight;
  for(int i=0;i<8;i++)lines[i+1]=coordDirOffsets[i].X+","+coordDirOffsets[i].Y+","+coordCalibration.Dx[i]+","+coordCalibration.Dy[i]+","+coordDirNames[i];
  string path=Path.Combine(data,"coord-directions.txt"),temp=path+".pending";
  File.WriteAllLines(temp,lines,Encoding.UTF8);
  if(File.Exists(path))File.Replace(temp,path,path+".previous");else File.Move(temp,path);
  coordDirDx=(int[])coordCalibration.Dx.Clone();coordDirDy=(int[])coordCalibration.Dy.Clone();coordDirReady=true;
  coordTableCenter=mzStickCenter;coordTableWidth=coordCalWidth;coordTableHeight=coordCalHeight;
  if(guardRequested){engine.Start();Log("坐标方向校准成功，已保存；自动继续寻路");}else{engine.Stop("坐标方向校准成功，已保存；可点击开始守护");Log(engine.Status);}
 }
 bool RequireCoordDirections() {
  if(coordDirReady&&mzStickSet&&coordTableCenter==mzStickCenter&&coordTableWidth==backend.Width&&coordTableHeight==backend.Height)return true;
  coordDirReady=false;
  if(!mzStickSet){engine.Status="守护持续监测中：等待校准跑/走摇杆位置";Log(engine.Status);return false;}
  if(DateTime.Now<autoCalRetryAt){engine.Status="守护持续监测中：等待重新尝试方向校准";return false;}
  autoCalRetryAt=DateTime.Now.AddSeconds(10);
  try{Log("缺少当前画面有效方向表，自动开始方向校准");CalCoordDirections();}
  catch(Exception ex){RetryGuard("方向校准暂未开始："+ex.Message,5);}
  return false;
 }
 bool TryGetCalibratedStep(int x,int y,int txTarget,int tyTarget,Point center,out Point to,out string why) {
  to=Point.Empty;why="";if(!coordDirReady)return false;
  double current=Math.Abs(txTarget-x)+Math.Abs(tyTarget-y),bestDist=current;
  int best=-1;double bestScale=1;
  for(int i=0;i<8;i++)foreach(double scale in new[]{1.0,.5,.25}) {
   double dist=Math.Abs(txTarget-x-coordDirDx[i]*scale)+Math.Abs(tyTarget-y-coordDirDy[i]*scale);
   if(dist<bestDist){bestDist=dist;best=i;bestScale=scale;}
  }
  if(best<0)return false;
  to=new Point(center.X+coordDirOffsets[best].X,center.Y+coordDirOffsets[best].Y);
  coordMoveDuration=(int)Math.Round(DirectionCalibration.Duration*bestScale);
  why="方向表"+coordDirNames[best]+" "+coordMoveDuration+"ms 预计距离"+current+"→"+bestDist.ToString("0.0");return true;
 }
}

