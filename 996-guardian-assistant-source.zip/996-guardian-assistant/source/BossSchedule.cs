using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;

// Reservations are durable before input. A timestamp is an observation, never
// proof that a BOSS is alive, dead, or that this player received its drops.
public sealed class BossRecord {
 public string Name="",Status="Unknown",Reason="";
 public long ObservedTicks,DueTicks,LastAttemptTicks,PaidUntilTicks,RetryUntilTicks;
}
public sealed class BossSchedule {
 public static readonly string[] Names=BossTargets.Names;
 public readonly List<BossRecord> Records=new List<BossRecord>();
 public DateTimeOffset NextPollUtc {get;private set;}
 public string LastError {get;private set;}
 readonly string file; readonly int paidMinutes;string historyError; readonly List<BossTarget> targets; public int TargetCount {get{return Records.Count;}}
 public BossSchedule(string directory,string serial,int paidCooldownMinutes=60,List<BossTarget> configuredTargets=null) {
  if(String.IsNullOrWhiteSpace(serial))throw new ArgumentException("实例标识为空");
  paidMinutes=Math.Max(1,paidCooldownMinutes);targets=configuredTargets??BossTargets.Load(directory);
  string id;using(var hash=SHA256.Create())id=BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(serial))).Replace("-","").Substring(0,16);
  file=Path.Combine(directory,"boss-schedule-"+id+".json");
  foreach(var t in targets)if(t.enabled)Records.Add(new BossRecord{Name=t.name});
  if(File.Exists(file+".blocked"))historyError=LastError="BOSS记录曾损坏，资源挑战暂停；需核对历史后移除对应blocked文件";
  if(File.Exists(file))try {
   var loaded=new JavaScriptSerializer().Deserialize<List<BossRecord>>(File.ReadAllText(file));
   if(loaded==null)throw new InvalidDataException("BOSS记录为空");
   foreach(var item in loaded){var r=Find(item.Name);if(r==null)continue;foreach(long ticks in new[]{item.ObservedTicks,item.DueTicks,item.LastAttemptTicks,item.PaidUntilTicks,item.RetryUntilTicks})if(ticks<0||ticks>DateTime.MaxValue.Ticks)throw new InvalidDataException("BOSS时间记录越界");r.Status=item.Status;r.ObservedTicks=item.ObservedTicks;r.DueTicks=item.DueTicks;r.LastAttemptTicks=item.LastAttemptTicks;r.PaidUntilTicks=item.PaidUntilTicks;r.RetryUntilTicks=item.RetryUntilTicks;r.Reason=item.Reason;}
  }catch(Exception ex){historyError=LastError="BOSS历史记录损坏，暂停资源挑战："+ex.Message;Records.Clear();foreach(var t in targets)if(t.enabled)Records.Add(new BossRecord{Name=t.name});try{File.WriteAllText(file+".blocked",LastError);}catch{}}
  NextPollUtc=DateTimeOffset.MinValue;
 }
 public BossRecord Find(string name){return Records.Find(delegate(BossRecord r){return r.Name==name;});}
 public bool Due(DateTimeOffset now){return now>=NextPollUtc;}
 public bool Observe(string name,BossRowStatus status,DateTimeOffset observedAt,int? seconds,DateTimeOffset now) {
  var r=Find(name);if(r==null||(now-observedAt).TotalSeconds>5||observedAt>now.AddSeconds(1)||observedAt.UtcTicks<=r.ObservedTicks)return false;
  if(status==BossRowStatus.Countdown&&(!seconds.HasValue||seconds.Value<0||seconds.Value>86400))return false;
  if(status==BossRowStatus.Unknown)return false;
  r.ObservedTicks=observedAt.UtcTicks;r.Status=status.ToString();r.DueTicks=status==BossRowStatus.Countdown?observedAt.AddSeconds(seconds.Value).UtcTicks:0;
  return true;
 }
 public BossRow Select(IList<BossRow> rows,DateTimeOffset now,bool allowPaid,int playerLevel=-1) {
  BossRow best=null;long oldest=Int64.MaxValue;int rank=9;
  foreach(var row in rows){var r=Find(row.Name);if(r==null||!row.Button.HasValue||r.RetryUntilTicks>now.UtcTicks||(BossTargets.MinLevel(row.Name)>0&&playerLevel<BossTargets.MinLevel(row.Name)))continue;
   int p=row.Status==BossRowStatus.Challenge&&allowPaid&&AllowsPaid(row.Name)&&String.IsNullOrEmpty(LastError)&&now.UtcTicks>=r.PaidUntilTicks?0:row.Status==BossRowStatus.Ready?1:9;
   if(p>=9)continue;if(p<rank||(p==rank&&r.LastAttemptTicks<oldest)){best=row;rank=p;oldest=r.LastAttemptTicks;}
  }return best;
 }
 public bool AllowsPaid(string name){return targets.Exists(t=>t.name==name&&t.enabled&&t.allow_resource_challenge);}
 public bool Reserve(string name,bool paid,DateTimeOffset now) {
  var r=Find(name);if(r==null||r.RetryUntilTicks>now.UtcTicks||(paid&&(!AllowsPaid(name)||!String.IsNullOrEmpty(LastError)||r.PaidUntilTicks>now.UtcTicks)))return false;
  r.LastAttemptTicks=now.UtcTicks;r.RetryUntilTicks=now.AddSeconds(120).UtcTicks;
  if(paid)r.PaidUntilTicks=now.AddMinutes(paidMinutes).UtcTicks;
  r.Reason=paid?"已预留一次资源挑战；等待反馈":"已预留一次前往击杀；等待反馈";
  return Save();
 }
 public void MarkAttemptEnded(string name,DateTimeOffset now,string reason){var r=Find(name);if(r!=null){r.Reason=reason;r.RetryUntilTicks=Math.Max(r.RetryUntilTicks,now.AddSeconds(120).UtcTicks);}NextPollUtc=now.AddSeconds(10);Save();}
 public void MarkScanComplete(DateTimeOffset now) {
  // Periodic refresh catches kills by other players and changes made while the
  // assistant was offline. Within 15s of a due time, poll every 3s.
  double wait=60;
  foreach(var r in Records)if(r.DueTicks>0){double remaining=(new DateTimeOffset(r.DueTicks,TimeSpan.Zero)-now).TotalSeconds;if(remaining>15)wait=Math.Min(wait,remaining-15);else if(remaining>-120)wait=Math.Min(wait,3);}
  NextPollUtc=now.AddSeconds(Math.Max(3,wait));Save();
 }
 public void Delay(DateTimeOffset now,int seconds){NextPollUtc=now.AddSeconds(Math.Max(3,seconds));}
 bool Save(){try {
  Directory.CreateDirectory(Path.GetDirectoryName(file));string temp=file+".tmp";
  byte[] bytes=Encoding.UTF8.GetBytes(new JavaScriptSerializer().Serialize(Records));
  using(var stream=new FileStream(temp,FileMode.Create,FileAccess.Write,FileShare.None)){stream.Write(bytes,0,bytes.Length);stream.Flush(true);}
  if(File.Exists(file))File.Replace(temp,file,null);else File.Move(temp,file);
  // Successful I/O clears a transient write error. A damaged input file's
  // persistent veto is separate and must not be silently cleared by a save.
  LastError=historyError;
  return true;
 }catch(Exception ex){LastError="BOSS记录写入失败，禁止提交进入："+ex.Message;return false;}}
}


