using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Windows.Globalization;
using Windows.Graphics.Imaging;
using Windows.Media.Ocr;
using Windows.Storage.Streams;

// The caller must confirm the current BOSS panel and the complete row name before
// every call. Only red timer ink inside that validated row is passed to local OCR.
// A result belongs to its original observation, never to the current poll time.
sealed class BossCountdownReader : IDisposable {
 const int Scale=3, Padding=8, TimeoutMilliseconds=1200, MaximumContexts=8;
 public const double MaximumResultAgeSeconds=3.0;
 const double RetryIntervalSeconds=.9;
 sealed class Reading {
  public int Seconds;
  public DateTimeOffset ObservedAt;
  public long ObservedTicks;
  public string Detail;
 }
 sealed class Context {
  public string Identity;
  public long Version,LastStarted;
  public Reading Result;
  public string Detail="BOSS倒计时尚未识别";
 }
 sealed class Job {
  public Context Context;
  public long Generation,Version,ObservedTicks;
  public DateTimeOffset ObservedAt;
  public byte[] Mask;
  public int Width,Height;
 }
 readonly object gate=new object();
 readonly Dictionary<string,Context> contexts=new Dictionary<string,Context>(StringComparer.Ordinal);
 readonly List<Job> waiting=new List<Job>();
 long generation;
 bool disposed;
 Job active;

 // Prefer the timestamp overload for scheduling. This overload is suitable only
 // for displaying the originally observed duration.
 public bool TryRead(Bitmap normalized,string bossKey,Rectangle roi,out int seconds,out string detail) {
  DateTimeOffset observedAt;
  return TryRead(normalized,bossKey,roi,out seconds,out observedAt,out detail);
 }

 public bool TryRead(Bitmap normalized,string bossKey,Rectangle roi,out int seconds,out DateTimeOffset observedAt,out string detail) {
  seconds=0;observedAt=DateTimeOffset.MinValue;detail="BOSS倒计时尚未识别";
  long callGeneration;
  lock(gate){if(disposed){detail="BOSS计时读取器已释放";return false;}callGeneration=generation;}
  if(normalized==null||normalized.Width!=1216||normalized.Height!=684){detail="BOSS计时截图必须归一化为1216×684";return false;}
  if(String.IsNullOrWhiteSpace(bossKey)){detail="BOSS完整行名尚未确认";return false;}
  if(roi.Width<16||roi.Height<8||roi.Width>300||roi.Height>80||roi.X<0||roi.Y<0||roi.Right>normalized.Width||roi.Bottom>normalized.Height){detail="BOSS倒计时区域越界或尺寸异常";return false;}
  string identity=bossKey+"\n"+roi.X+","+roi.Y+","+roi.Width+","+roi.Height;
  long observedTicks=Stopwatch.GetTimestamp();
  DateTimeOffset capturedAt=DateTimeOffset.UtcNow;
  byte[] mask=null;
  bool hasRed;
  try {
   byte[] pixels;
   using(Bitmap crop=normalized.Clone(roi,PixelFormat.Format32bppArgb))pixels=CopyPixels(crop);
   hasRed=TryMakeRedMask(pixels,roi.Width,roi.Height,out mask,out detail);
  }catch(Exception ex){detail="BOSS倒计时区域读取失败："+ex.GetType().Name;return false;}
  lock(gate) {
   if(disposed){detail="BOSS计时读取器已释放";return false;}
   if(callGeneration!=generation){detail="连接已切换，本次BOSS计时截图已失效";return false;}
   Context context;
   if(!contexts.TryGetValue(identity,out context)) {
    if(!hasRed)return false;
    if(contexts.Count>=MaximumContexts){detail="BOSS计时目标数超限，需重新确认列表";return false;}
    context=new Context{Identity=identity};contexts.Add(identity,context);
   }
   if(!hasRed) {
    // A green ready label or a disappeared timer cannot inherit an earlier value,
    // including an OCR operation which is still finishing on the native worker.
    context.Version++;context.Result=null;context.Detail=detail;
    for(int i=waiting.Count-1;i>=0;i--)if(waiting[i].Context==context)waiting.RemoveAt(i);
    return false;
   }
   long now=Stopwatch.GetTimestamp();
   bool sameActive=active!=null&&active.Context==context&&active.Version==context.Version&&active.Generation==generation;
   if(!sameActive&&(context.LastStarted==0||Age(now,context.LastStarted)>=RetryIntervalSeconds)) {
    Job job=new Job{Context=context,Generation=generation,Version=context.Version,ObservedAt=capturedAt,ObservedTicks=observedTicks,Mask=mask,Width=roi.Width,Height=roi.Height};
    int queued=-1;
    for(int i=0;i<waiting.Count;i++)if(waiting[i].Context==context){queued=i;break;}
    // Replace a queued snapshot with current pixels without moving its place in
    // the queue. A busy first row must not starve the remaining BOSS rows.
    if(queued>=0)waiting[queued]=job;else waiting.Add(job);
    StartNextLocked();
   }
   Reading result=context.Result;
   if(result!=null&&Age(now,result.ObservedTicks)<=MaximumResultAgeSeconds) {
    seconds=result.Seconds;observedAt=result.ObservedAt;
    detail=result.Detail+"；原始观测="+observedAt.ToString("HH:mm:ss.fff",CultureInfo.InvariantCulture)+" UTC；观测龄="+Age(now,result.ObservedTicks).ToString("0.0",CultureInfo.InvariantCulture)+"秒";
    return true;
   }
   detail=context.Detail;
   if(sameActive||HasWaiting(context))detail="BOSS倒计时本地OCR处理中（按完整行名及区域排队）";
   else if(result!=null)detail="BOSS倒计时观测已超过3秒，等待重新识别";
   return false;
  }
 }

 bool HasWaiting(Context context){foreach(Job job in waiting)if(job.Context==context)return true;return false;}
 static double Age(long now,long then){return Math.Max(0,(now-then)/(double)Stopwatch.Frequency);}

 public void Reset() {
  lock(gate){generation++;contexts.Clear();waiting.Clear();}
  // Keep active occupied until the old native call actually finishes. Reset is
  // an identity barrier, not permission to overlap native OCR operations.
 }
 public void Dispose(){lock(gate){if(disposed)return;disposed=true;generation++;contexts.Clear();waiting.Clear();}}

 void StartNextLocked() {
  if(disposed||active!=null)return;
  while(waiting.Count>0) {
   Job job=waiting[0];waiting.RemoveAt(0);
   if(job.Generation!=generation||job.Version!=job.Context.Version||Age(Stopwatch.GetTimestamp(),job.ObservedTicks)>MaximumResultAgeSeconds)continue;
   active=job;job.Context.LastStarted=Stopwatch.GetTimestamp();job.Context.Detail="BOSS倒计时本地OCR处理中";
   try {ThreadPool.QueueUserWorkItem(delegate {RunJob(job);});return;}
   catch(Exception ex){active=null;job.Context.Detail="BOSS计时OCR启动失败："+ex.GetType().Name;}
  }
 }

 void RunJob(Job job) {
  try {Recognize(job);}
  catch(Exception ex){Finish(job,null,"BOSS倒计时未识别：本地OCR不可用（"+ex.GetType().Name+"）");}
 }

 [MethodImpl(MethodImplOptions.NoInlining)]
 void Recognize(Job job) {
  OcrEngine engine=OcrEngine.TryCreateFromLanguage(new Language("zh-Hans-CN"));
  if(engine==null){Finish(job,null,"BOSS倒计时未识别：未安装Windows简体中文OCR组件");return;}
  byte[] enlarged;
  int width=job.Width*Scale+Padding*2,height=job.Height*Scale+Padding*2;
  using(Bitmap input=new Bitmap(job.Width,job.Height,PixelFormat.Format32bppArgb)) {
   BitmapData data=input.LockBits(new Rectangle(0,0,input.Width,input.Height),ImageLockMode.WriteOnly,PixelFormat.Format32bppArgb);
   try {for(int y=0;y<input.Height;y++)Marshal.Copy(job.Mask,y*input.Width*4,IntPtr.Add(data.Scan0,y*data.Stride),input.Width*4);}
   finally {input.UnlockBits(data);}
   using(Bitmap scaled=new Bitmap(width,height,PixelFormat.Format32bppArgb)) {
    using(Graphics graphics=Graphics.FromImage(scaled)) {
     graphics.Clear(Color.White);graphics.InterpolationMode=InterpolationMode.NearestNeighbor;graphics.PixelOffsetMode=PixelOffsetMode.Half;
     graphics.DrawImage(input,new Rectangle(Padding,Padding,job.Width*Scale,job.Height*Scale),new Rectangle(0,0,input.Width,input.Height),GraphicsUnit.Pixel);
    }
    enlarged=CopyPixels(scaled);
   }
  }
  SoftwareBitmap bitmap;
  using(DataWriter writer=new DataWriter()){writer.WriteBytes(enlarged);bitmap=SoftwareBitmap.CreateCopyFromBuffer(writer.DetachBuffer(),BitmapPixelFormat.Bgra8,width,height,BitmapAlphaMode.Ignore);}
  Windows.Foundation.IAsyncOperation<OcrResult> operation=null;
  bool handedOff=false;
  Reading reading=null;
  string detail="BOSS倒计时未识别";
  try {
   operation=engine.RecognizeAsync(bitmap);
   TaskCompletionSource<OcrResult> completion=new TaskCompletionSource<OcrResult>();
   operation.Completed=delegate(Windows.Foundation.IAsyncOperation<OcrResult> completed,Windows.Foundation.AsyncStatus status) {
    try {
     if(status==Windows.Foundation.AsyncStatus.Canceled)completion.TrySetCanceled();
     else if(status==Windows.Foundation.AsyncStatus.Error)completion.TrySetException(completed.ErrorCode);
     else completion.TrySetResult(completed.GetResults());
    }catch(Exception ex){completion.TrySetException(ex);}
   };
   Task<OcrResult> task=completion.Task;
   if(!task.Wait(TimeoutMilliseconds)) {
    lock(gate){if(!disposed&&job.Generation==generation&&job.Version==job.Context.Version)job.Context.Detail="BOSS倒计时未识别：本地OCR超时，等待取消完成";}
    try {operation.Cancel();}catch { }
    Windows.Foundation.IAsyncOperation<OcrResult> pendingOperation=operation;
    task.ContinueWith(delegate(Task<OcrResult> ended) {
     try {if(ended.IsFaulted){AggregateException observed=ended.Exception;}}
     finally {
      try {pendingOperation.Close();}catch { }
      bitmap.Dispose();GC.KeepAlive(engine);
      Finish(job,null,"BOSS倒计时未识别：本地OCR超时");
     }
    },TaskScheduler.Default);
    handedOff=true;return;
   }
   string raw=Compact(task.Result.Text);
   int seconds;
   if(TryParseCountdown(raw,out seconds)) {
    detail="BOSS倒计时OCR原文="+raw+"；完整行名区域内红字；本机Windows OCR";
    reading=new Reading{Seconds=seconds,ObservedAt=job.ObservedAt,ObservedTicks=job.ObservedTicks,Detail=detail};
   }else detail="BOSS倒计时未识别：完整计时格式无效（OCR="+raw+"）";
  } finally {
   if(!handedOff){if(operation!=null)try {operation.Close();}catch { }bitmap.Dispose();GC.KeepAlive(engine);}
  }
  Finish(job,reading,detail);
 }

 void Finish(Job job,Reading reading,string detail) {
  lock(gate) {
   // Only the owner of the single worker can release it.
   if(active!=job)return;
   active=null;
   if(!disposed&&job.Generation==generation&&job.Version==job.Context.Version) {
    job.Context.Result=reading;job.Context.Detail=detail;
   }
   StartNextLocked();
  }
 }

 internal static bool TryParseCountdown(string text,out int seconds) {
  seconds=0;
  string value=Compact(text).ToLowerInvariant();
  if(value.Length==0||value.Length>32)return false;
  Match colon=Regex.Match(value,@"\A(?<h>[0-9]{1,2}):(?<m>[0-9]{2}):(?<s>[0-9]{2})\z",RegexOptions.CultureInvariant);
  Match units=colon.Success?colon:Regex.Match(value,@"\A(?:(?<h>[0-9]{1,2})(?:小时|时|h))?(?:(?<m>[0-9]{1,4})(?:分|m))?(?:(?<s>[0-9]{1,5})(?:秒|s))?\z",RegexOptions.CultureInvariant);
  if(!units.Success||(!units.Groups["h"].Success&&!units.Groups["m"].Success&&!units.Groups["s"].Success))return false;
  int h=units.Groups["h"].Success?Int32.Parse(units.Groups["h"].Value,CultureInfo.InvariantCulture):0;
  int m=units.Groups["m"].Success?Int32.Parse(units.Groups["m"].Value,CultureInfo.InvariantCulture):0;
  int s=units.Groups["s"].Success?Int32.Parse(units.Groups["s"].Value,CultureInfo.InvariantCulture):0;
  if(units.Groups["h"].Success&&m>=60)return false;
  if((units.Groups["h"].Success||units.Groups["m"].Success)&&s>=60)return false;
  int total=h*3600+m*60+s;
  if(total<0||total>24*3600)return false;
  seconds=total;return true;
 }

 static string Compact(string value) {
  StringBuilder result=new StringBuilder();
  if(value!=null)foreach(char ch in value) {
   if(Char.IsWhiteSpace(ch))continue;
   if(ch>='０'&&ch<='９')result.Append((char)('0'+ch-'０'));
   else result.Append(ch=='：'?':':ch);
  }
  return result.ToString();
 }

 internal static bool TryMakeRedMask(byte[] pixels,int width,int height,out byte[] mask,out string detail) {
  mask=null;detail="BOSS倒计时区域没有完整红色计时文字";
  if(pixels==null||width<=0||height<=0||pixels.Length!=width*height*4)return false;
  byte[] output=new byte[pixels.Length];
  int count=0,left=width,top=height,right=-1,bottom=-1;
  for(int y=0;y<height;y++)for(int x=0;x<width;x++) {
   int i=(y*width+x)*4,b=pixels[i],g=pixels[i+1],r=pixels[i+2];
   // The challenge-token label is orange. Its large green-minus-blue channel
   // difference must not be treated as the timer's red ink.
   bool red=r>=105&&r-g>=48&&r-b>=40&&g-b<=35&&g<175&&b<175;
   byte shade=red?(byte)0:(byte)255;
   output[i]=output[i+1]=output[i+2]=shade;output[i+3]=255;
   if(red){count++;left=Math.Min(left,x);right=Math.Max(right,x);top=Math.Min(top,y);bottom=Math.Max(bottom,y);}
  }
  if(count<12||count>width*height*.7||right-left<8||bottom-top<5)return false;
  if(left==0||top==0||right==width-1||bottom==height-1){detail="BOSS红色倒计时触及区域边缘，完整文字未确认";return false;}
  mask=output;detail="已提取BOSS倒计时红字";return true;
 }

 static byte[] CopyPixels(Bitmap bitmap) {
  byte[] pixels=new byte[bitmap.Width*bitmap.Height*4];
  BitmapData data=bitmap.LockBits(new Rectangle(0,0,bitmap.Width,bitmap.Height),ImageLockMode.ReadOnly,PixelFormat.Format32bppArgb);
  try {for(int y=0;y<bitmap.Height;y++)Marshal.Copy(IntPtr.Add(data.Scan0,y*data.Stride),pixels,y*bitmap.Width*4,bitmap.Width*4);}
  finally {bitmap.UnlockBits(data);}
  return pixels;
 }
}
