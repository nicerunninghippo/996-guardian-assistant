using System;
using System.Drawing;
using System.IO;

public sealed class BossCombatView {
 public bool ChallengeMap;
 public Point? ReturnStone;
 public string Detail="";
}
// Arrival and return-item evidence only. Neither observation proves death or
// completion of pickup. The ordinary target/hero percentage is not BOSS HP.
public sealed class BossCombatVision {
 readonly Mask map;
 readonly double[] nativeTitle;
 readonly bool[] stone=new bool[25*24];int count;
 static bool Purple(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return r>95&&b>110&&b>g*1.35&&r>g*1.15;}
 public BossCombatVision(string root){
  string nativeFile=Path.Combine(root,"templates","boss-v4195-combat-title.png");if(File.Exists(nativeFile))using(var b=new Bitmap(nativeFile)){if(b.Width==90&&b.Height==25){var pixels=FrameCache.Pixels(b);nativeTitle=new double[pixels.Length];for(int i=0;i<pixels.Length;i++)nativeTitle[i]=Light(pixels[i]);}}
  string file=Path.Combine(root,"templates","boss-v419-combat-map.png");if(File.Exists(file))using(var b=new Bitmap(file))map=new Mask(b,false);
  file=Path.Combine(root,"templates","boss-v419-combat-stone.png");if(File.Exists(file))using(var b=new Bitmap(file)){var p=FrameCache.Pixels(b);for(int i=0;i<stone.Length&&i<p.Length;i++)if(Purple(p[i])){stone[i]=true;count++;}}
 }
 public BossCombatView Read(Bitmap b){return FrameCache.Get<BossCombatView>(b,this,"boss-combat",delegate {
  var v=new BossCombatView();if(b.Width!=1216||b.Height!=684)return v;Point q;double ms=0;
  if(map!=null)using(var title=b.Clone(new Rectangle(1067,31,149,34),b.PixelFormat))ms=map.Find(new Mask(title,false),new Rectangle(0,0,149,34),out q);v.ChallengeMap=ms>=.88;
  var px=FrameCache.Pixels(b);double nativeScore=0;
  if(nativeTitle!=null)for(int dy=-3;dy<=3;dy++)for(int dx=-3;dx<=3;dx++){double score=TitleCorrelation(px,1098+dx,36+dy,0,90);if(score>=.93&&TitleCorrelation(px,1098+dx,36+dy,0,45)>=.88&&TitleCorrelation(px,1098+dx,36+dy,45,45)>=.88)nativeScore=Math.Max(nativeScore,score);}
  v.ChallengeMap=v.ChallengeMap||nativeScore>=.93;
  double best=0;Point at=Point.Empty;
  if(count>=20)for(int y=489;y<=499;y++)for(int x=624;x<=637;x++){int total=0,hit=0;for(int dy=0;dy<24;dy++)for(int dx=0;dx<25;dx++)if(Purple(px[(y+dy)*1216+x+dx])){total++;if(stone[dy*25+dx])hit++;}double score=2.0*hit/Math.Max(1,count+total);if(score>best){best=score;at=new Point(x+12,y+12);}}
  if(best>=.85)v.ReturnStone=at;v.Detail="BOSS挑战地图="+ms.ToString("0.00")+"；原生完整标题="+nativeScore.ToString("0.00")+"；盟重石头="+best.ToString("0.00");return v;
 });}
 static double Light(int p){return (((p>>16)&255)+((p>>8)&255)+(p&255))/3.0;}
 double TitleCorrelation(int[] pixels,int x,int y,int left,int width){double a=0,b=0,aa=0,bb=0,ab=0,low=255,high=0;int n=width*25;for(int yy=0;yy<25;yy++)for(int xx=left;xx<left+width;xx++){double p=nativeTitle[yy*90+xx],q=Light(pixels[(y+yy)*1216+x+xx]);a+=p;b+=q;aa+=p*p;bb+=q*q;ab+=p*q;low=Math.Min(low,q);high=Math.Max(high,q);}double va=aa-a*a/n,vb=bb-b*b/n;if(high-low<30||va<1||vb<1)return 0;return (ab-a*b/n)/Math.Sqrt(va*vb);}
}
