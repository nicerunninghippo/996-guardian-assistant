using System;
using System.Drawing;

public sealed class AutoBattleAction {
 public Point? Tap;
 public bool ConfirmedOn,Waiting,Diagnostic;
 public string Status="";
}

// A visual toggle needs feedback, not a timed double-click. Attempts are
// reserved before dispatch; even a transport timeout must respect this budget.
public sealed class AutoBattleFlow {
 public bool Waiting {get;private set;}
 public int Attempts {get;private set;}
 public double CooldownUntil {get;private set;}
 double deadline,lastAt=-1,unknownSince=-1,nextUnknownDiagnostic;
 long lastFrame=-1;int onFrames,offFrames;Point lastButton;
 public void Reset(){Waiting=false;Attempts=0;CooldownUntil=0;deadline=0;lastAt=-1;unknownSince=-1;nextUnknownDiagnostic=0;lastFrame=-1;onFrames=offFrames=0;lastButton=Point.Empty;}
 public void Suspend(double now){onFrames=offFrames=0;lastFrame=-1;lastAt=-1;unknownSince=-1;if(Waiting&&now>=deadline){Waiting=false;if(Attempts>=3&&CooldownUntil<=0)CooldownUntil=now+60;}}
 public AutoBattleAction Step(AutoBattleReading r,double now,long frame,bool eligible){
  var a=new AutoBattleAction();
  if(!eligible){Suspend(now);a.Status="自动战斗检查等待：刷怪地图/主画面未确认";a.Waiting=Waiting;return a;}
  bool fresh=frame!=lastFrame;
  if(fresh){
   if(lastAt<0||now-lastAt>5||frame!=lastFrame+1)onFrames=offFrames=0;
   lastFrame=frame;lastAt=now;
   if(r.State==AutoBattleState.On){onFrames=Math.Min(2,onFrames+1);offFrames=0;}
   else if(r.State==AutoBattleState.Off&&r.Button.HasValue){
    onFrames=0;Point p=r.Button.Value;if(Math.Abs(p.X-lastButton.X)>8||Math.Abs(p.Y-lastButton.Y)>8)offFrames=0;
    lastButton=p;offFrames=Math.Min(2,offFrames+1);
   }else onFrames=offFrames=0;
  }
  if(r.State!=AutoBattleState.Unknown)unknownSince=-1;
  if(onFrames>=2&&r.State==AutoBattleState.On){Waiting=false;Attempts=0;CooldownUntil=0;a.ConfirmedOn=true;a.Status="刷怪地图：右侧连续两帧显示“自动”，开启状态已确认";return a;}
  if(Waiting){
   if(now<deadline){a.Waiting=true;a.Status="已单击自动按钮，等待变为“自动”（最多12秒，不连点）";return a;}
   Waiting=false;
   if(Attempts>=3){CooldownUntil=now+60;offFrames=onFrames=0;a.Diagnostic=true;a.Status="自动开启3次仍未确认，冷却60秒后重新核对；守护继续";return a;}
  }
  if(now<CooldownUntil){offFrames=0;a.Status="自动战斗恢复冷却中，还需"+Math.Ceiling(CooldownUntil-now)+"秒";return a;}
  if(CooldownUntil>0){CooldownUntil=0;Attempts=0;offFrames=0;}
  if(r.State==AutoBattleState.On){a.Status="右侧首次显示“自动”，等待第二帧确认";return a;}
  if(r.State==AutoBattleState.Unknown){
   if(unknownSince<0)unknownSince=now;
   a.Status="右侧“挂机/自动”未读清，继续识别；不按橙色文字或站立状态猜测";
   if(now-unknownSince>=30&&now>=nextUnknownDiagnostic){a.Diagnostic=true;nextUnknownDiagnostic=now+60;}
   return a;
  }
  if(!fresh||offFrames<2){a.Status="右侧显示“挂机”，等待第二张新截图确认";return a;}
  Attempts++;Waiting=true;deadline=now+12;offFrames=onFrames=0;
  a.Tap=r.Button;a.Waiting=true;a.Status="右侧连续两帧显示“挂机”，单击开启自动（本轮"+Attempts+"/3），等待画面验证";return a;
 }
}
