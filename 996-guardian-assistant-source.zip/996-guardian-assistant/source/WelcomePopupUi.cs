using System;
using System.Drawing;
using System.IO;

partial class Guardian {
 DateTime welfareNextClick=DateTime.MinValue;
 DateTime welfareLastFrame=DateTime.MinValue;
 int welfareCleanFrames;
 bool welfarePending;
 Mask welcomeButtonWarm;
 Mask welcomeCloseWarm;
 Mask welfareTitleWarm,welfareCloseWarm;
 bool welcomeClosing;
 DateTime welcomeFollowupUntil=DateTime.MinValue;

 void ResetWelcomePopup(){
  welfareNextClick=DateTime.MinValue;welfareLastFrame=DateTime.MinValue;
  welfareCleanFrames=0;welfarePending=false;welcomeClosing=false;welcomeFollowupUntil=DateTime.MinValue;
 }

 static double PopupDarkRatio(Bitmap image,Rectangle area){
  area=Rectangle.Intersect(area,new Rectangle(0,0,image.Width,image.Height));int dark=0,total=0;
  for(int y=area.Top;y<area.Bottom;y+=4)for(int x=area.Left;x<area.Right;x+=4){
   Color c=image.GetPixel(x,y);if(Math.Max(c.R,Math.Max(c.G,c.B))<125)dark++;total++;
  }
  return total==0?0:(double)dark/total;
 }
 bool FindWelcomeFollowupClose(Bitmap image,Mask warm,out Point point){
  point=Point.Empty;
  if(welcomeCloseWarm==null){string file=Path.Combine(root,"templates","box-cross-v47.png");if(File.Exists(file))using(Bitmap template=new Bitmap(file))welcomeCloseWarm=new Mask(template,false,true);}
  if(welcomeCloseWarm==null)return false;
  double score=welcomeCloseWarm.Find(warm,new Rectangle(620,35,510,290).IntersectSafe(image),out point);
  if(score<.88)return false;
  Rectangle button=new Rectangle(point.X-welcomeCloseWarm.W/2,point.Y-welcomeCloseWarm.H/2,welcomeCloseWarm.W,welcomeCloseWarm.H).IntersectSafe(image);
  int red=0,total=0;for(int y=button.Top;y<button.Bottom;y++)for(int x=button.Left;x<button.Right;x++){
   Color c=image.GetPixel(x,y);if(c.R>70&&c.R>c.G*1.6&&c.R>c.B*1.4)red++;total++;
  }
  return total>0&&(double)red/total>.25&&PopupDarkRatio(image,new Rectangle(point.X-350,point.Y+50,300,250))>.55;
 }

 bool FindKnownWelfareClose(Bitmap image,Mask warm,out Point point){
  point=Point.Empty;
  if(welfareTitleWarm==null){
   string title=Path.Combine(root,"templates","welfare-title-v49.png"),close=Path.Combine(root,"templates","welfare-close-v49.png");
   if(!File.Exists(title)||!File.Exists(close))return false;
   using(Bitmap b=new Bitmap(title))welfareTitleWarm=new Mask(b,false,true);
   using(Bitmap b=new Bitmap(close))welfareCloseWarm=new Mask(b,false,true);
  }
  Point titlePoint;
  if(welfareTitleWarm.Find(warm,new Rectangle(535,64,160,51),out titlePoint)<.82)return false;
  if(welfareCloseWarm.Find(warm,new Rectangle(1007,70,44,59),out point)<.84)return false;
  int red=0;
  for(int y=point.Y-18;y<point.Y+18;y++)for(int x=point.X-10;x<point.X+10;x++){
   Color c=image.GetPixel(x,y);if(c.R>70&&c.R>c.G*1.6&&c.R>c.B*1.4)red++;
  }
  return red>180&&PopupDarkRatio(image,new Rectangle(215,210,130,360))>.6;
 }

 void InvalidatePopupObservations(){
  engine.ResetObservation();engine.ResetPending();ResetHealthEvidence();autoWaiting=false;
  mengWalk.Pending=false;shenWalk.Pending=false;mzCoordReadyUntil=DateTime.MinValue;
  if(recycle.Stage!=0){recycle.Reset();nextRecycle=DateTime.Now.AddMinutes((double)recycleMinutes.Value);}
 }

 // The button is a complete, fixed game control.  A yellow pixel or the
 // word 温馨提示 alone is never enough to authorize a click.
 bool HandleWelcomePopup(Bitmap image){
  if(!guardRequested||!engine.Running||Native.GetAsyncKeyState(0x77)!=0){ResetWelcomePopup();return false;}
  if(welcomeButtonWarm==null){
   try{string file=Path.Combine(root,"templates","popup-welfare-button.png");if(File.Exists(file))using(Bitmap template=new Bitmap(file))welcomeButtonWarm=new Mask(template,false,true);}catch{}
  }
  if(welcomeButtonWarm==null)return false;
  Mask warm=new Mask(image,false,true);Point point;
  double score=welcomeButtonWarm.Find(warm,new Rectangle(240,285,370,180).IntersectSafe(image),out point);
  DateTime now=DateTime.Now;
  Point knownClose;
  if(FindKnownWelfareClose(image,warm,out knownClose)){
   InvalidatePopupObservations();welfarePending=true;welcomeClosing=true;welfareCleanFrames=0;welfareLastFrame=now;
   engine.Status="识别到合区福利窗口，准备关闭并验证";
   if(now>=welfareNextClick){welfareNextClick=now.AddSeconds(2.5);if(Click(knownClose))Log("已点击合区福利红色关闭叉；等待窗口消失验证");}
   return true;
  }
  bool buttonSeen=score>=.70&&PopupDarkRatio(image,new Rectangle(point.X-80,point.Y-110,190,125))>.50;
  if(!buttonSeen){
   Point close;
   // A generic close is authorized only by a recent click on this prompt,
   // and needs an actual gold X on a red button plus a dark modal body.
   if(now<welcomeFollowupUntil&&FindWelcomeFollowupClose(image,warm,out close)){
    InvalidatePopupObservations();welfarePending=true;welcomeClosing=true;welfareCleanFrames=0;welfareLastFrame=now;
    engine.Status="已识别提示后续窗口和关闭叉，等待关闭验证";
    if(now>=welfareNextClick){
     welfareNextClick=now.AddSeconds(2.5);
     if(Click(close)){welcomeFollowupUntil=now.AddSeconds(15);Log("已点击提示后续窗口关闭叉；等待新截图验证");}
    }
    return true;
   }
   if(!welfarePending)return false;
   InvalidatePopupObservations();
   if(now>welfareLastFrame){welfareLastFrame=now;welfareCleanFrames++;}
   if(welfareCleanFrames>=2){welfarePending=false;Log(welcomeClosing?"已确认提示后续窗口关闭，继续恢复小地图和下图":"温馨提示已消失；继续检查后续窗口和小地图");welcomeClosing=false;return true;}
   engine.Status="温馨提示已点击，等待弹窗消失确认";return true;
  }
  InvalidatePopupObservations();
  welfarePending=true;welcomeClosing=false;welfareCleanFrames=0;welfareLastFrame=now;
  if(now<welfareNextClick){engine.Status="温馨提示仍在关闭验证，暂不重复点击";return true;}
  welfareNextClick=now.AddSeconds(2.5);
  engine.Status="检测到温馨提示/立即了解，点击处理弹窗";
  if(Click(point))welcomeFollowupUntil=now.AddSeconds(15);
  else engine.Status="温馨提示点击未发出；下一帧重新确认";
  Log(engine.Status+"；分="+score.ToString("0.00"));
  return true;
 }

 public void WelcomePopupSmoke(){
  timer.Stop();
  using(Bitmap prompt=new Bitmap(Path.Combine(root,"tests","minimap-v49","collapsed-popup.png"))) {
   if(welcomeButtonWarm==null){using(Bitmap template=new Bitmap(Path.Combine(root,"templates","popup-welfare-button.png")))welcomeButtonWarm=new Mask(template,false,true);}
   Mask warm=new Mask(prompt,false,true);Point p;
   double score=welcomeButtonWarm.Find(warm,new Rectangle(240,285,370,180),out p);
   FocusAssert(score>=.70,"温馨提示/立即了解按钮识别，分="+score.ToString("0.00"));
   Point promptPoint=p;
   FocusAssert(PopupDarkRatio(prompt,new Rectangle(p.X-80,p.Y-110,190,125))>.50,"立即了解背后的弹窗主体");
   using(Bitmap normal=new Bitmap(Path.Combine(root,"tests","route0.png"))){
    double falseScore=welcomeButtonWarm.Find(new Mask(normal,false,true),new Rectangle(240,285,370,180),out p);
    FocusAssert(falseScore<.70,"正常地图不得误识别立即了解按钮，分="+falseScore.ToString("0.00"));
    File.WriteAllText(Path.Combine(root,"V4.9弹窗重点测试.txt"),"通过：温馨提示/立即了解按钮分="+score.ToString("0.00")+"，点击点="+promptPoint.X+","+promptPoint.Y+"；正常地图分="+falseScore.ToString("0.00")+Environment.NewLine);
   }
  }
  using(Bitmap raw=new Bitmap(Path.Combine(root,"tests","box-v47","popup.png")))using(Bitmap popup=Normalize(raw)){
   Point close;FocusAssert(FindWelcomeFollowupClose(popup,new Mask(popup,false,true),out close),"提示后续窗口红底金色关闭叉");
   FocusAssert(Math.Abs(close.X-1034)<8&&Math.Abs(close.Y-206)<8,"关闭点在实际叉上");
  }
  using(Bitmap normal=new Bitmap(Path.Combine(root,"tests","route0.png"))){
   Point close;FocusAssert(!FindWelcomeFollowupClose(normal,new Mask(normal,false,true),out close),"正常地图红点不能当关闭叉");
   FocusAssert(!FindKnownWelfareClose(normal,new Mask(normal,false,true),out close),"正常地图不是合区福利窗口");
  }
  using(Bitmap followup=new Bitmap(Path.Combine(root,"tests","minimap-v49","welfare-followup.png"))){
   Point close;FocusAssert(FindKnownWelfareClose(followup,new Mask(followup,false,true),out close),"真实合区福利标题与关闭按钮");
   FocusAssert(Math.Abs(close.X-1028)<5&&Math.Abs(close.Y-100)<5,"合区福利关闭点正确");
  }
  File.AppendAllText(Path.Combine(root,"V4.9弹窗重点测试.txt"),"通过：提示后续窗口红底金色关闭叉；正常地图红点不会触发关闭。"+Environment.NewLine);
  File.AppendAllText(Path.Combine(root,"V4.9弹窗重点测试.txt"),"通过：真实合区福利窗口标题与红色关闭叉，关闭点1028:100附近。"+Environment.NewLine);
 }
}
