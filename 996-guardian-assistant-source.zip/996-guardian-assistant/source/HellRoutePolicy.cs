using System;

public enum HellRouteStage { Idle, Npc, Destination, Travel, Walk, Portal, Detail, Arrival, ReturnNpc, ReturnMenu, ReturnTravel, Hold }
public sealed class HellRoutePolicy {
 public HellRouteStage Stage; public double StageAt,Started,LastTap=-100,RetryAt; public int Taps; public bool EntryIssued;
 public bool CanStart(int level,double now){return level>=80&&Stage==HellRouteStage.Idle&&now>=RetryAt&&!EntryIssued;}
 public bool CanAcceptHellArrival(int level){return level>=80&&!EntryIssued&&(Stage==HellRouteStage.Npc||Stage==HellRouteStage.Destination||Stage==HellRouteStage.Travel);}
 public void Begin(bool inHell,double now){Started=now;Set(inHell?HellRouteStage.Walk:HellRouteStage.Npc,now);}
 public void Set(HellRouteStage stage,double now){Stage=stage;StageAt=now;Taps=0;}
 public double Limit {get{switch(Stage){case HellRouteStage.Walk:return 90;case HellRouteStage.Npc:case HellRouteStage.ReturnNpc:return 60;case HellRouteStage.Travel:case HellRouteStage.Arrival:case HellRouteStage.ReturnTravel:return 25;case HellRouteStage.Portal:return 12;default:return 20;}}}
 public bool Expired(double now){return Stage!=HellRouteStage.Idle&&Stage!=HellRouteStage.Hold&&(now-StageAt>=Limit||now-Started>=240&&Stage<HellRouteStage.ReturnNpc);}
 public bool CanTap(double now,int maximum){return Taps<maximum&&now-LastTap>=2;}
 public void Tapped(double now){Taps++;LastTap=now;}
 public void Fail(bool inHell,double now){RetryAt=now+300;Set(inHell?HellRouteStage.ReturnNpc:HellRouteStage.Hold,now);}
 public void Reset(bool clearBudget){Stage=HellRouteStage.Idle;Taps=0;LastTap=-100;if(clearBudget){EntryIssued=false;RetryAt=0;}}
}
