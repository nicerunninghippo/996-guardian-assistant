﻿using System;
using System.Drawing;

partial class Guardian {
 RewardPopupDetector rewardPopupDetector;
 readonly RewardPopupFlow rewardPopupFlow=new RewardPopupFlow();
 string rewardPopupLast="";double rewardPopupLogged;
 void ResetRewardPopup(){rewardPopupFlow.Reset();rewardPopupLast="";rewardPopupLogged=0;}
 bool RewardUnderlyingClear(Bitmap frame){
  // Positive evidence is required: an unknown/black frame is not a closed popup.
  if(BossOwnsWindow){var boss=ReadBoss(frame);if(boss.TeleportPrompt||boss.List||boss.ListShell||boss.SuspectedList||boss.Challenge)return true;}
  RecycleView view=recycleVision.Read(frame);
  if(view.Bag||view.Page)return true;
  if(view.Icon&&ReadMinimap(frame).State==MinimapState.Expanded)return true;
  if(farmPopupDetector==null)farmPopupDetector=new FarmPopupDetector(System.IO.Path.Combine(root,"templates"));
  var popup=farmPopupDetector.Read(frame,true);
  if(popup.CanClose||popup.MapDetail)return true;
  return maintenanceSchedule.Active=="mail"&&mailTask!=null&&mailTask.IsPanelVisible(frame);
 }
 bool HandleRewardPopup(Bitmap frame){
  if(rewardPopupDetector==null)rewardPopupDetector=new RewardPopupDetector(root);
  RewardPopupReading seen=rewardPopupDetector.Read(frame);double now=ClockSeconds();
  bool clear=!seen.Present&&!seen.Suspected&&rewardPopupFlow.Active&&RewardUnderlyingClear(frame);
  RewardPopupAction action=rewardPopupFlow.Step(seen,clear,now,guardRequested&&engine.Running);
  if(!action.Handled)return false;
  // Keep the owning task's pending claim/use. Dismissing this overlay alone
  // never acknowledges a reward or replays the previous claim button.
  InvalidateMaintenanceObservation();maintenanceAdmission.Reset();
  if(maintenanceTask!=null&&maintenanceSchedule.Expired(now))FinishMaintenance(now,false,"奖励弹窗遮挡超过维护总时限，本轮结束；关闭后再恢复守护");
  if(action.Diagnostic)SaveDiagnostic(frame,-1,"reward-popup-recovery");
  if(action.Tap.HasValue){
   TraceBeforeAction(frame,action.Status+"；"+seen.Detail);
   TraceEvent("reward_popup_close","point",action.Tap.Value,"evidence",seen.Detail);
   if(!Click(action.Tap.Value))action.Status="奖励弹窗：空白处点击未发出，等待下一帧重新确认";
  }
  engine.Status=action.Status;
  if(action.Tap.HasValue||action.Recovered||action.Diagnostic||action.Status!=rewardPopupLast||now-rewardPopupLogged>=30){Log(action.Status+((seen.Present||seen.Suspected)?"；"+seen.Detail:""));rewardPopupLast=action.Status;rewardPopupLogged=now;}
  return true;
 }
}
