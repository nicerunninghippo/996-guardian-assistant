﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Windows.Globalization;
using Windows.Graphics.Imaging;
using Windows.Media.Ocr;
using Windows.Storage.Streams;

// Local Windows OCR of the complete title only. This class knows no destination
// names and never completes/corrects a partial name. Compare the returned text by
// exact equality in the route controller. Call Reset on every connection change.
sealed class BossTextReader : IDisposable {
 readonly Rectangle TitleRectangle; public BossTextReader(Rectangle region){if(region.Width<5||region.Height<5||!new Rectangle(0,0,1216,684).Contains(region))throw new ArgumentException("OCR区域越界");TitleRectangle=region;}
 const int Scale=3, OcrTimeoutMilliseconds=1200;
 readonly object gate=new object();
 long generation,lastStarted;
 bool busy,disposed;
 string resultFingerprint,resultText,resultDetail="文字区域尚未识别";
 long resultGeneration=-1;
 string pendingFingerprint;
 long pendingGeneration;

 public bool TryRead(Bitmap normalized,out string text,out string detail) {
  text="";detail="文字区域尚未识别";
  long callGeneration;
  lock(gate){if(disposed){detail="文字区域读取器已释放";return false;}callGeneration=generation;}
  if(normalized==null){detail="文字区域截图为空";return false;}
  if(normalized.Width!=1216||normalized.Height!=684){detail="文字区域截图必须归一化为1216×684";return false;}
  byte[] pixels;string fingerprint;
  try {
   using(Bitmap roi=normalized.Clone(TitleRectangle,PixelFormat.Format32bppArgb))pixels=CopyPixels(roi);
   using(SHA256 hash=SHA256.Create())fingerprint=Convert.ToBase64String(hash.ComputeHash(pixels));
  } catch(Exception ex){detail="文字区域截图读取失败："+ex.GetType().Name;return false;}
  lock(gate) {
   if(disposed){detail="文字区域读取器已释放";return false;}
   if(callGeneration!=generation){detail="连接已切换，本次文字区域截图已失效";return false;}
   if(resultGeneration==generation&&resultFingerprint==fingerprint&&!String.IsNullOrEmpty(resultText)) {
    text=resultText;detail=resultDetail;return true;
   }
   if(busy) {
    detail=pendingGeneration==generation&&pendingFingerprint==fingerprint?"文字区域本地OCR处理中":"文字区域画面已变化，等待前次OCR结束";
    if(resultGeneration==generation&&resultFingerprint==fingerprint)detail=resultDetail;
    return false;
   }
   long now=Stopwatch.GetTimestamp();
   if(lastStarted!=0&&(now-lastStarted)/(double)Stopwatch.Frequency<2.0) {
    detail=resultGeneration==generation&&resultFingerprint==fingerprint?resultDetail:"文字区域等待下一次本地OCR（最短间隔2秒）";
    return false;
   }
   busy=true;lastStarted=now;pendingFingerprint=fingerprint;pendingGeneration=generation;
   long jobGeneration=generation;
   try { ThreadPool.QueueUserWorkItem(delegate { RunJob(pixels,fingerprint,jobGeneration); }); }
   catch(Exception ex){busy=false;detail="文字区域OCR启动失败："+ex.GetType().Name;return false;}
   detail="文字区域本地OCR处理中";return false;
  }
 }

 public void Reset() {
  lock(gate){generation++;resultGeneration=-1;resultFingerprint=null;resultText=null;resultDetail="连接已切换，文字区域尚未识别";}
  // An old job keeps its resources until Windows has finished/cancelled it.
  // Do not start a second job while the old one is still alive.
 }

 public void Dispose() {
  lock(gate){if(disposed)return;disposed=true;generation++;resultGeneration=-1;resultFingerprint=null;resultText=null;}
 }

 void RunJob(byte[] pixels,string fingerprint,long jobGeneration) {
  try { Recognize(pixels,fingerprint,jobGeneration); }
  catch(Exception ex){Complete(fingerprint,jobGeneration,"","文字区域未识别：本地OCR不可用（"+ex.GetType().Name+"）");}
 }

 // Keep WinRT activation outside TryRead so a missing OCR component is caught
 // on the worker and cannot crash the UI or trigger a destination guess.
 [MethodImpl(MethodImplOptions.NoInlining)]
 void Recognize(byte[] pixels,string fingerprint,long jobGeneration) {
  OcrEngine engine=OcrEngine.TryCreateFromLanguage(new Language("zh-Hans-CN"));
  if(engine==null){Complete(fingerprint,jobGeneration,"","文字区域未识别：未安装Windows简体中文OCR组件");return;}
  byte[] enlarged;
  using(Bitmap input=new Bitmap(TitleRectangle.Width,TitleRectangle.Height,PixelFormat.Format32bppArgb)) {
   BitmapData data=input.LockBits(new Rectangle(0,0,input.Width,input.Height),ImageLockMode.WriteOnly,PixelFormat.Format32bppArgb);
   try { for(int y=0;y<input.Height;y++)Marshal.Copy(pixels,y*input.Width*4,IntPtr.Add(data.Scan0,y*data.Stride),input.Width*4); }
   finally {input.UnlockBits(data);}
   using(Bitmap scaled=new Bitmap(input.Width*Scale,input.Height*Scale,PixelFormat.Format32bppArgb)) {
    using(Graphics graphics=Graphics.FromImage(scaled)) {
     graphics.Clear(Color.Black);graphics.InterpolationMode=InterpolationMode.HighQualityBicubic;
     graphics.DrawImage(input,new Rectangle(0,0,scaled.Width,scaled.Height),new Rectangle(0,0,input.Width,input.Height),GraphicsUnit.Pixel);
    }
    enlarged=CopyPixels(scaled);
   }
  }
  SoftwareBitmap bitmap;
  using(DataWriter writer=new DataWriter()) {
   writer.WriteBytes(enlarged);
   bitmap=SoftwareBitmap.CreateCopyFromBuffer(writer.DetachBuffer(),BitmapPixelFormat.Bgra8,TitleRectangle.Width*Scale,TitleRectangle.Height*Scale,BitmapAlphaMode.Ignore);
  }
  Windows.Foundation.IAsyncOperation<OcrResult> operation=null;
  bool handedOff=false;
  try {
   operation=engine.RecognizeAsync(bitmap);
   TaskCompletionSource<OcrResult> completion=new TaskCompletionSource<OcrResult>();
   operation.Completed=delegate(Windows.Foundation.IAsyncOperation<OcrResult> completed,Windows.Foundation.AsyncStatus status) {
    try {
     if(status==Windows.Foundation.AsyncStatus.Canceled)completion.TrySetCanceled();
     else if(status==Windows.Foundation.AsyncStatus.Error)completion.TrySetException(completed.ErrorCode);
     else completion.TrySetResult(completed.GetResults());
    }catch(Exception ex){completion.TrySetException(ex);}
   };
   Task<OcrResult> task=completion.Task;
   if(!task.Wait(OcrTimeoutMilliseconds)) {
    lock(gate){if(!disposed&&generation==jobGeneration){resultFingerprint=fingerprint;resultGeneration=jobGeneration;resultText="";resultDetail="文字区域未识别：本地OCR超时，等待取消完成";}}
    try {operation.Cancel();}catch { }
    Windows.Foundation.IAsyncOperation<OcrResult> pendingOperation=operation;
    // Never release the bitmap while native OCR may still be reading it, and
    // never set busy=false until the same operation has actually terminated.
    task.ContinueWith(delegate(Task<OcrResult> ended) {
     try {if(ended.IsFaulted){AggregateException observed=ended.Exception;}}
     finally {
      try {pendingOperation.Close();}catch { }
      bitmap.Dispose();GC.KeepAlive(engine);
      Complete(fingerprint,jobGeneration,"","文字区域未识别：本地OCR超时");
     }
    },TaskScheduler.Default);
    handedOff=true;return;
   }
   string value=RemoveWhitespace(task.Result.Text);
   Complete(fingerprint,jobGeneration,value,String.IsNullOrEmpty(value)?"文字区域未识别：本地OCR未读到文字":"文字区域OCR原文="+value+"；仅右上标题区域；当前标题像素及连接校验");
  } finally {
   if(!handedOff){if(operation!=null)try {operation.Close();}catch { }bitmap.Dispose();GC.KeepAlive(engine);}
  }
 }

 void Complete(string fingerprint,long jobGeneration,string text,string detail) {
  lock(gate) {
   busy=false;pendingFingerprint=null;
   if(disposed||jobGeneration!=generation)return;
   resultFingerprint=fingerprint;resultGeneration=jobGeneration;resultText=text;resultDetail=detail;
  }
 }

 static string RemoveWhitespace(string value) {
  StringBuilder text=new StringBuilder();
  if(value!=null)foreach(char ch in value)if(!Char.IsWhiteSpace(ch))text.Append(ch);
  return text.ToString();
 }

 static byte[] CopyPixels(Bitmap bitmap) {
  byte[] pixels=new byte[bitmap.Width*bitmap.Height*4];
  BitmapData data=bitmap.LockBits(new Rectangle(0,0,bitmap.Width,bitmap.Height),ImageLockMode.ReadOnly,PixelFormat.Format32bppArgb);
  try { for(int y=0;y<bitmap.Height;y++)Marshal.Copy(IntPtr.Add(data.Scan0,y*data.Stride),pixels,y*bitmap.Width*4,bitmap.Width*4); }
  finally {bitmap.UnlockBits(data);}
  return pixels;
 }
}
