﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

sealed class HealthEscapeFlow {
 int lowCount,lastMaximum;
 double lastSample=-100,lastAttempt=-100000;
 public int LowCount { get { return lowCount; } }
 public void ResetEvidence(){lowCount=0;lastMaximum=0;lastSample=-100;}
 public void MarkAttempt(double now){lastAttempt=now;ResetEvidence();}
 public bool Observe(bool valid,int current,int maximum,double now,int threshold,double cooldown,out string why){
  if(!valid||maximum<=0||current<0||current>maximum){ResetEvidence();why="自身血量未读清，不飞随机石";return false;}
  if(now-lastSample>5||maximum!=lastMaximum)lowCount=0;
  double elapsed=now-lastSample;lastSample=now;lastMaximum=maximum;
  double percent=100.0*current/maximum;
  if(current==0){lowCount=0;why="自身生命值为0，等待复活/回图，不飞随机石";return false;}
  if(percent>threshold){lowCount=0;why="高于"+threshold+"%阈值，不飞随机石";return false;}
  if(now-lastAttempt<cooldown){lowCount=0;why="随机石冷却中，还剩"+Math.Ceiling(cooldown-(now-lastAttempt))+"秒";return false;}
  if(elapsed>=.5)lowCount++;
  why="自身血量≤"+threshold+"%，连续确认"+lowCount+"/2帧";
  return lowCount>=2;
 }
}

partial class Guardian {
 readonly HealthEscapeFlow healthEscape=new HealthEscapeFlow();
 HealthReader healthReader;
 NumericUpDown randomHpThreshold=new NumericUpDown();
 Label healthValue=new Label();
 string lastHealthLog="";
 DateTime healthLoggedAt=DateTime.MinValue;
 void InitHealthThreshold(Control top,string[] settings){
  // A conservative default avoids random-stone escapes from brief, modest
  // damage; the user can raise/lower it in the UI.
  randomHpThreshold.Minimum=10;randomHpThreshold.Maximum=95;randomHpThreshold.Value=50;randomHpThreshold.Width=58;
  int threshold;if(settings.Length>4&&int.TryParse(settings[4],out threshold))randomHpThreshold.Value=Math.Max(10,Math.Min(95,threshold));
  top.Controls.Add(new Label{Text="自身血量≤",AutoSize=true,Padding=new Padding(0,6,0,0)});
  top.Controls.Add(randomHpThreshold);
  top.Controls.Add(new Label{Text="% 连续2帧",AutoSize=true,Padding=new Padding(0,6,0,0)});
  healthValue.Text="自身血量：等待识别";healthValue.AutoSize=true;healthValue.Padding=new Padding(0,6,0,0);top.Controls.Add(healthValue);
  randomHpThreshold.ValueChanged+=(s,e)=>{ResetHealthEvidence();SaveRandom();};
 }
 void ResetHealthEvidence(){healthEscape.ResetEvidence();healthValue.Text="自身血量：等待重新确认";}
 void ReportHealth(string line,bool significant){
  if(significant||line!=lastHealthLog&&(DateTime.Now-healthLoggedAt).TotalSeconds>=5||(DateTime.Now-healthLoggedAt).TotalSeconds>=30){
   lastHealthLog=line;healthLoggedAt=DateTime.Now;Log("随机石判定："+line);
  }
 }
 bool TryRandomEscape(Bitmap b,int map,bool verifiedBoss=false){
  if(!randomEnabled.Checked||!randomPointSet||map!=4||(!verifiedBoss&&(engine.Stable!=4||engine.Count<3))||engine.Pending>=0||recycle.Stage!=0){ResetHealthEvidence();return false;}
  if(healthReader==null)healthReader=new HealthReader(Path.Combine(root,"templates"));
  int hp,max;string detail,why;
  bool valid=healthReader.TryRead(b,out hp,out max,out detail);
  string reading=valid?hp+"/"+max+"（"+(100.0*hp/max).ToString("0.0")+"%）":"未读清";
  healthValue.Text="自身血量："+reading;
  bool trigger=healthEscape.Observe(valid,hp,max,ClockSeconds(),(int)randomHpThreshold.Value,(double)randomCooldown.Value,out why);
  ReportHealth(reading+"；"+why+(valid?"":"；"+detail),trigger);
  if(!trigger)return false;
  if(!engine.Running||Native.GetAsyncKeyState(0x77)<0){ResetHealthEvidence();return false;}
  healthEscape.MarkAttempt(ClockSeconds());
  SaveDiagnostic(b,map,"low-hp-random");
  if(Click(randomPoint)){
   engine.Status="自身低血量已连续确认，已点击随机石";
   Log(engine.Status+"；"+reading+"；阈值="+randomHpThreshold.Value+"%；冷却="+randomCooldown.Value+"秒");
   engine.ResetObservation();return true;
  }
  engine.Failures++;RetryGuard("随机石点击未完成，冷却后重新确认自身血量",3);return true;
 }
}
