using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

// Local diagnostic records only. A logging failure must never interrupt the
// guard. Rotation is confined to eight files in this newly generated session.
internal sealed class DiagnosticJournal : IDisposable {
 internal const int MaxFileBytes=4*1024*1024,MaxFiles=8,MaxRecordBytes=256*1024,MaxQueuedEvents=512,WaitLimitMilliseconds=500;
 sealed class CopyRequest {internal string Destination;internal bool Done,Success,Cancelled;internal long Deadline;}
 sealed class Record {internal long Sequence;internal DateTimeOffset Time;internal string Kind;internal IDictionary<string,object> Fields;internal CopyRequest Copy;}
 readonly object gate=new object();
 readonly Queue<Record> queue=new Queue<Record>();
 readonly AutoResetEvent wake=new AutoResetEvent(false);
 readonly string release;
 readonly Stopwatch clock=Stopwatch.StartNew();
 readonly UTF8Encoding utf8=new UTF8Encoding(false);
 StreamWriter writer;Thread worker;
 int slot,bytes,pending;
 long sequence,accepted,dropped,lastFlush,retryAfter,lastAccepted,processedSequence,settledSequence,flushTarget;
 bool disposed,reopenInNextSlot,workerStopped;
 string lastError="";
 public string SessionId{get;private set;}
 public string DirectoryPath{get;private set;}
 public string LastError{get{lock(gate)return lastError;}}
 public long DroppedEvents{get{lock(gate)return dropped;}}

 public DiagnosticJournal(string dataDirectory,string release){
  this.release=release??"";int pid=0;try{using(Process p=Process.GetCurrentProcess())pid=p.Id;}catch{}
  SessionId=DateTime.Now.ToString("yyyyMMdd-HHmmss-fff",CultureInfo.InvariantCulture)+"-"+pid.ToString(CultureInfo.InvariantCulture)+"-"+Guid.NewGuid().ToString("N").Substring(0,8);
  DirectoryPath="";
  try{
   DirectoryPath=Path.Combine(Path.GetFullPath(dataDirectory),"runs",SessionId);
  }catch(Exception ex){lastError=ex.Message;}
  try{worker=new Thread(Work);worker.IsBackground=true;worker.Name="996 diagnostic writer";worker.Start();}
  catch(Exception ex){disposed=workerStopped=true;lastError="诊断写入线程："+ex.Message;}
 }
 void OpenSlot(){
  if(DirectoryPath.Length==0)throw new IOException("诊断目录不可用");
  Directory.CreateDirectory(DirectoryPath);
  string file=Path.Combine(DirectoryPath,"events-"+(slot+1).ToString("D2",CultureInfo.InvariantCulture)+".jsonl");
  var stream=new FileStream(file,FileMode.Create,FileAccess.Write,FileShare.ReadWrite,16384,FileOptions.SequentialScan);
  try{writer=new StreamWriter(stream,utf8,16384);writer.NewLine="\n";}catch{stream.Dispose();throw;}
  bytes=pending=0;lastFlush=clock.ElapsedMilliseconds;lock(gate)lastError="";
 }
 void Failure(Exception ex,long lost){
  lock(gate){dropped+=lost;lastError=ex.GetType().Name+": "+ex.Message;retryAfter=clock.ElapsedMilliseconds+10000;}pending=0;
  if(writer!=null)reopenInNextSlot=true;
  if(writer!=null){try{writer.Dispose();}catch{}writer=null;}
 }
 bool FlushWorker(){
  bool ok=true;
  if(writer!=null&&pending>0)try{writer.Flush();pending=0;lastFlush=clock.ElapsedMilliseconds;lock(gate)lastError="";}catch(Exception ex){Failure(ex,pending);ok=false;}
  lock(gate){settledSequence=processedSequence;Monitor.PulseAll(gate);}return ok;
 }
 public bool Write(string kind,IDictionary<string,object> fields){
  lock(gate){
   sequence++;
   if(disposed||workerStopped){dropped++;lastError="诊断日志已关闭";return false;}
   if(queue.Count>=MaxQueuedEvents){dropped++;lastError="诊断队列已满，已丢弃本条，守护继续";return false;}
   if(clock.ElapsedMilliseconds<retryAfter){dropped++;return false;}
   // Only a small top-level snapshot is made on the caller thread. Nested
   // diagnostic values must be immutable after submission. JSON encoding and
   // all filesystem work are exclusively performed by the background writer.
   Dictionary<string,object> snapshot=null;
   try{if(fields!=null){if(fields.Count>256)throw new InvalidDataException("诊断顶层字段超过256项");snapshot=new Dictionary<string,object>();foreach(var item in fields){if(snapshot.Count>=256)throw new InvalidDataException("诊断顶层字段超过256项");snapshot.Add(item.Key,item.Value);}}}
   catch(Exception ex){dropped++;lastError="诊断字段快照："+ex.Message;return false;}
   queue.Enqueue(new Record{Sequence=sequence,Time=DateTimeOffset.Now,Kind=kind??"",Fields=snapshot});accepted++;lastAccepted=sequence;Signal();return true;
  }
 }
 void Signal(){try{wake.Set();}catch(ObjectDisposedException){}}
 void WriteWorker(Record record){
   string line;int size;
   try{
    var json=new JsonWriter(MaxRecordBytes);json.BeginObject();
    json.Property("schema",1);json.Property("time",record.Time.ToString("yyyy-MM-dd'T'HH:mm:ss.fffzzz",CultureInfo.InvariantCulture));
    json.Property("seq",record.Sequence);json.Property("session",SessionId);json.Property("version",release);json.Property("kind",record.Kind);json.Property("fields",record.Fields);
    json.EndObject();line=json.ToString();size=utf8.GetByteCount(line)+1;
    if(size>MaxRecordBytes)throw new InvalidDataException("单条诊断记录超过256KB，已跳过");
   }catch(Exception ex){lock(gate){dropped++;lastError="诊断序列化："+ex.Message;}return;}
   if(writer==null){
    lock(gate){if(clock.ElapsedMilliseconds<retryAfter){dropped++;return;}}
    if(reopenInNextSlot){slot=(slot+1)%MaxFiles;reopenInNextSlot=false;}
    try{OpenSlot();}catch(Exception ex){Failure(ex,1);return;}
   }
   if(bytes+size>MaxFileBytes){
    if(!FlushWorker()){lock(gate)dropped++;return;}
    try{writer.Dispose();writer=null;slot=(slot+1)%MaxFiles;OpenSlot();}
    catch(Exception ex){Failure(ex,1);return;}
   }
   try{writer.WriteLine(line);bytes+=size;pending++;}
   catch(Exception ex){Failure(ex,pending+1);}
 }
 void Work(){
  try{
   while(true){
    Record record=null;bool stopping;
    lock(gate){if(queue.Count>0)record=queue.Dequeue();stopping=disposed;}
    if(record!=null){if(record.Copy!=null)CopyWorker(record.Copy);else{WriteWorker(record);processedSequence=record.Sequence;}}
    bool requested;lock(gate)requested=flushTarget>settledSequence&&processedSequence>=flushTarget;
    if(pending>=64||(pending>0&&clock.ElapsedMilliseconds-lastFlush>=2000)||requested||(stopping&&record==null))FlushWorker();
    if(record==null){if(stopping)break;int wait=pending>0?(int)Math.Max(1,2000-(clock.ElapsedMilliseconds-lastFlush)):Timeout.Infinite;wake.WaitOne(wait);}
   }
  }catch(Exception ex){Failure(ex,pending);lock(gate){foreach(Record item in queue){if(item.Copy==null)dropped++;else lock(item.Copy){item.Copy.Done=true;Monitor.PulseAll(item.Copy);}}queue.Clear();}}
  finally{
   if(writer!=null){try{writer.Dispose();}catch(Exception ex){lock(gate)lastError=ex.GetType().Name+": "+ex.Message;}writer=null;}
   lock(gate){workerStopped=true;Monitor.PulseAll(gate);}wake.Dispose();
  }
 }
 public void Flush(){
  lock(gate){
   long target=lastAccepted;if(settledSequence>=target||workerStopped)return;flushTarget=Math.Max(flushTarget,target);Signal();long until=clock.ElapsedMilliseconds+WaitLimitMilliseconds;
   while(settledSequence<target&&!workerStopped){int wait=(int)Math.Max(0,until-clock.ElapsedMilliseconds);if(wait==0){lastError="诊断刷新超过500ms，后台继续写入，守护继续";return;}Monitor.Wait(gate,wait);}
  }
 }
 // Export calls this from a background thread. The command is ordered among
 // writes, so rotation and copying cannot touch the same shard concurrently.
 public bool CopySessionTo(string destinationDirectory){
  var request=new CopyRequest{Destination=destinationDirectory,Deadline=clock.ElapsedMilliseconds+10000};
  lock(gate){if(disposed||workerStopped||queue.Count>=MaxQueuedEvents){lastError="诊断导出未排入队列：已关闭或队列已满";return false;}queue.Enqueue(new Record{Copy=request});Signal();}
  bool result;lock(request){while(!request.Done){int remaining=(int)Math.Max(0,request.Deadline-clock.ElapsedMilliseconds);if(remaining==0){request.Cancelled=true;break;}Monitor.Wait(request,remaining);}result=request.Done&&request.Success;}
  if(!result)lock(gate){if(request.Cancelled)lastError="诊断快照等待超过10秒，导出已取消";}return result;
 }
 void CheckCopy(CopyRequest request){lock(request)if(request.Cancelled||clock.ElapsedMilliseconds>=request.Deadline)throw new IOException("诊断快照已取消或超时");}
 void CopyWorker(CopyRequest request){
  bool success=false;
  try{
   CheckCopy(request);if(writer==null||!FlushWorker())throw new IOException("诊断写入尚未可用，不能生成完整快照");
   string destination=Path.GetFullPath(request.Destination);
   if(Directory.Exists(destination)&&Directory.GetFileSystemEntries(destination).Length>0)throw new IOException("诊断快照目标必须是新建或空目录");
   Directory.CreateDirectory(destination);
   foreach(string file in Directory.GetFiles(DirectoryPath,"events-*.jsonl")){
    CheckCopy(request);using(var input=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.ReadWrite)){
     // After a previous disk error a shard might end with a partial record.
     // Only LF-terminated records are exported; JSON text escapes its newlines.
     long length=input.Length,complete=0;byte[] buffer=new byte[16384];
     for(long end=length;end>0&&complete==0;){int count=(int)Math.Min(buffer.Length,end);input.Position=end-count;int n=input.Read(buffer,0,count);for(int i=n-1;i>=0;i--)if(buffer[i]==10){complete=end-count+i+1;break;}end-=count;}
     input.Position=0;using(var output=new FileStream(Path.Combine(destination,Path.GetFileName(file)),FileMode.CreateNew,FileAccess.Write,FileShare.Read)){
      long remaining=complete;while(remaining>0){CheckCopy(request);int n=input.Read(buffer,0,(int)Math.Min(buffer.Length,remaining));if(n==0)throw new EndOfStreamException("诊断分片意外缩短");output.Write(buffer,0,n);remaining-=n;}
     }
    }
   }success=true;
  }catch(Exception ex){lock(gate)lastError="诊断快照："+ex.Message;}
  finally{lock(request){request.Success=success;request.Done=true;Monitor.PulseAll(request);}}
 }
 public string Summary(){lock(gate)return "会话="+SessionId+"；已入队="+accepted.ToString(CultureInfo.InvariantCulture)+"；队列="+queue.Count.ToString(CultureInfo.InvariantCulture)+"/"+MaxQueuedEvents+"；待刷新="+pending.ToString(CultureInfo.InvariantCulture)+"；丢弃="+dropped.ToString(CultureInfo.InvariantCulture)+"；诊断目录="+DirectoryPath+(lastError.Length>0?"；最近错误="+lastError:"");}
 public void Dispose(){
  lock(gate){if(disposed)return;disposed=true;flushTarget=lastAccepted;Signal();}
  if(worker!=null&&Thread.CurrentThread!=worker&&!worker.Join(WaitLimitMilliseconds)){lock(gate)lastError="诊断关闭超过500ms，后台继续收尾";}
 }

 sealed class ReferenceEquality : IEqualityComparer<object> {
  public new bool Equals(object a,object b){return object.ReferenceEquals(a,b);}
  public int GetHashCode(object value){return RuntimeHelpers.GetHashCode(value);}
 }
 sealed class JsonWriter {
  readonly StringBuilder text=new StringBuilder(512);readonly int limit;
  readonly HashSet<object> parents=new HashSet<object>(new ReferenceEquality());
  bool first=true;int entries;
  internal JsonWriter(int maximum){limit=maximum;}
  void Bound(){if(text.Length>limit)throw new InvalidDataException("单条诊断记录过大");}
  internal void BeginObject(){text.Append('{');first=true;}
  internal void EndObject(){text.Append('}');Bound();}
  internal void Property(string name,object value){if(!first)text.Append(',');first=false;Quoted(name);text.Append(':');Value(value,0);Bound();}
  void Quoted(string value){
   if(value==null){text.Append("null");return;}text.Append('"');
   for(int i=0;i<value.Length;i++){
    char c=value[i];switch(c){case '"':text.Append("\\\"");break;case '\\':text.Append("\\\\");break;case '\b':text.Append("\\b");break;case '\f':text.Append("\\f");break;case '\n':text.Append("\\n");break;case '\r':text.Append("\\r");break;case '\t':text.Append("\\t");break;
     default:
      // Escape UTF-16 surrogate code units as valid JSON \u sequences too;
      // this preserves pairs and prevents UTF-8 replacement of lone units.
      if(c<32||char.IsSurrogate(c))text.Append("\\u").Append(((int)c).ToString("x4",CultureInfo.InvariantCulture));else text.Append(c);break;
    }Bound();
   }text.Append('"');
  }
  void Value(object value,int depth){
   if(depth>16||++entries>4096)throw new InvalidDataException("诊断字段嵌套或数量超限");
   if(value==null){text.Append("null");return;}
   if(value is string||value is char||value is Guid||value is Enum){Quoted(Convert.ToString(value,CultureInfo.InvariantCulture));return;}
   if(value is bool){text.Append((bool)value?"true":"false");return;}
   if(value is DateTimeOffset){Quoted(((DateTimeOffset)value).ToString("o",CultureInfo.InvariantCulture));return;}
   if(value is DateTime){Quoted(((DateTime)value).ToString("o",CultureInfo.InvariantCulture));return;}
   if(value is double){double n=(double)value;text.Append(double.IsNaN(n)||double.IsInfinity(n)?"null":n.ToString("R",CultureInfo.InvariantCulture));return;}
   if(value is float){float n=(float)value;text.Append(float.IsNaN(n)||float.IsInfinity(n)?"null":n.ToString("R",CultureInfo.InvariantCulture));return;}
   if(value is byte||value is sbyte||value is short||value is ushort||value is int||value is uint||value is long||value is ulong||value is decimal){text.Append(Convert.ToString(value,CultureInfo.InvariantCulture));return;}
   var dictionary=value as IDictionary;
   if(dictionary!=null){
    if(!parents.Add(value))throw new InvalidDataException("诊断字段存在循环引用");text.Append('{');bool itemFirst=true;
    foreach(DictionaryEntry item in dictionary){if(!itemFirst)text.Append(',');itemFirst=false;Quoted(Convert.ToString(item.Key,CultureInfo.InvariantCulture));text.Append(':');Value(item.Value,depth+1);Bound();}
    text.Append('}');parents.Remove(value);return;
   }
   var generic=value as IDictionary<string,object>;
   if(generic!=null){
    if(!parents.Add(value))throw new InvalidDataException("诊断字段存在循环引用");text.Append('{');bool itemFirst=true;
    foreach(var item in generic){if(!itemFirst)text.Append(',');itemFirst=false;Quoted(item.Key);text.Append(':');Value(item.Value,depth+1);Bound();}text.Append('}');parents.Remove(value);return;
   }
   var array=value as IEnumerable;
   if(array!=null){
    if(!parents.Add(value))throw new InvalidDataException("诊断字段存在循环引用");text.Append('[');bool itemFirst=true;
    foreach(object item in array){if(!itemFirst)text.Append(',');itemFirst=false;Value(item,depth+1);Bound();}text.Append(']');parents.Remove(value);return;
   }
   Quoted(Convert.ToString(value,CultureInfo.InvariantCulture));
  }
  public override string ToString(){return text.ToString();}
 }
}
