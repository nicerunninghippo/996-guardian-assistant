﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

partial class Guardian
{
    // Tests replace this delegate; normal use writes only after a copy command.
    internal Action<string> logClipboardWriter = delegate(string text) { Clipboard.SetText(text); };
    Label logCopyHint;
    ContextMenuStrip logCopyMenu;

    [DllImport("user32.dll", CharSet = CharSet.Auto, EntryPoint = "SendMessage")]
    static extern IntPtr LogUiSendMessage(IntPtr hwnd, int message, IntPtr wParam, IntPtr lParam);

    void InitLogCopy(Panel bottom)
    {
        bottom.Height = 256;
        logs.SetBounds(12, 100, 865, 146);
        logs.Name = "VisibleLog";
        logs.ReadOnly = true;
        logs.ShortcutsEnabled = true;
        logs.HideSelection = false;
        logs.WordWrap = false;
        logs.ScrollBars = ScrollBars.Both;

        var toolbar = new FlowLayoutPanel
        {
            Left = 12, Top = 63, Width = 865, Height = 33,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            WrapContents = false, Margin = Padding.Empty, Padding = Padding.Empty
        };
        var copyAll = new Button
        {
            Name = "LogCopyAll", Text = "复制全部日志", AutoSize = true, Height = 29,
            Margin = new Padding(0, 0, 6, 0)
        };
        var copySelected = new Button
        {
            Name = "LogCopySelected", Text = "复制选中", AutoSize = true, Height = 29,
            Margin = new Padding(0, 0, 6, 0)
        };
        logCopyHint = new Label
        {
            Name = "LogCopyHint", Text = "拖动选中后 Ctrl+C；Ctrl+A 全选", AutoSize = true,
            Margin = new Padding(2, 5, 0, 0)
        };
        // Copy remains available while coordinate calibration is running.
        copyAll.Click += delegate { CopyVisibleLog(true); };
        copySelected.Click += delegate { CopyVisibleLog(false); };
        toolbar.Controls.AddRange(new Control[] { copyAll, copySelected, logCopyHint });
        bottom.Controls.Add(toolbar);
        InitDiagnostics(bottom);

        logCopyMenu = new ContextMenuStrip();
        var selectedItem = new ToolStripMenuItem("复制选中 (Ctrl+C)");
        var allItem = new ToolStripMenuItem("复制全部日志");
        var selectAllItem = new ToolStripMenuItem("全选 (Ctrl+A)");
        selectedItem.Click += delegate { CopyVisibleLog(false); };
        allItem.Click += delegate { CopyVisibleLog(true); };
        selectAllItem.Click += delegate { logs.Focus(); logs.SelectAll(); };
        logCopyMenu.Items.AddRange(new ToolStripItem[] { selectedItem, allItem, selectAllItem });
        logCopyMenu.Opening += delegate
        {
            selectedItem.Enabled = logs.SelectionLength > 0;
            allItem.Enabled = selectAllItem.Enabled = logs.TextLength > 0;
        };
        logs.ContextMenuStrip = logCopyMenu;
        logs.KeyDown += delegate(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.A)
            {
                logs.SelectAll();
                e.SuppressKeyPress = true;
                e.Handled = true;
            }
            else if (e.Control && e.KeyCode == Keys.C)
            {
                CopyVisibleLog(false);
                e.SuppressKeyPress = true;
                e.Handled = true;
            }
        };
    }

    internal void CopyVisibleLog(bool all)
    {
        string text = all ? logs.Text : logs.SelectedText;
        if (string.IsNullOrEmpty(text))
        {
            if (logCopyHint != null) logCopyHint.Text = all ? "暂无日志可复制" : "请先拖动选中要复制的日志";
            return;
        }
        try
        {
            logClipboardWriter(text);
            if (logCopyHint != null) logCopyHint.Text = "已复制" + (all ? "全部日志" : "选中日志") + "，可直接粘贴发送";
        }
        catch (Exception ex)
        {
            if (logCopyHint != null) logCopyHint.Text = "复制失败，请重试：" + ex.Message;
        }
    }

    internal void AppendVisibleLog(string line)
    {
        int selectionStart = logs.SelectionStart;
        int selectionLength = logs.SelectionLength;
        bool reading = logs.Focused || selectionLength > 0 || (logCopyMenu != null && logCopyMenu.Visible);
        bool hasHandle = logs.IsHandleCreated;
        int firstLine = hasHandle ? LogUiSendMessage(logs.Handle, 0x00CE, IntPtr.Zero, IntPtr.Zero).ToInt32() : 0;
        if (reading && hasHandle) LogUiSendMessage(logs.Handle, 0x000B, IntPtr.Zero, IntPtr.Zero);
        try
        {
            logs.AppendText(line + Environment.NewLine);
            // Keep selected content intact; trim only when the reader leaves the log.
            if (!reading && logs.TextLength > 45000)
            {
                int remove = logs.Text.IndexOf('\n', logs.TextLength - 30000);
                if (remove >= 0) logs.Text = logs.Text.Substring(remove + 1);
            }
            if (reading)
            {
                logs.Select(selectionStart, selectionLength);
                if (hasHandle)
                {
                    int currentLine = LogUiSendMessage(logs.Handle, 0x00CE, IntPtr.Zero, IntPtr.Zero).ToInt32();
                    LogUiSendMessage(logs.Handle, 0x00B6, IntPtr.Zero, new IntPtr(firstLine - currentLine));
                }
            }
            else
            {
                logs.Select(logs.TextLength, 0);
                logs.ScrollToCaret();
            }
        }
        finally
        {
            if (reading && hasHandle)
            {
                LogUiSendMessage(logs.Handle, 0x000B, new IntPtr(1), IntPtr.Zero);
                logs.Invalidate();
            }
        }
    }
}
