using System;
using System.Drawing;
using System.IO;
using System.Text;

public static class MinimapRecoveryTests {
 static void Check(bool condition,string label,StringBuilder report,ref int failed) {
  report.AppendLine((condition?"PASS ":"FAIL ")+label);if(!condition)failed++;
 }
 static Bitmap Normalized(string path) {
  using(Bitmap raw=new Bitmap(path)) {
   Bitmap result=new Bitmap(1216,684);
   using(Graphics g=Graphics.FromImage(result))g.DrawImage(raw,0,0,1216,684);
   return result;
  }
 }
 public static int Run(string root) {
  StringBuilder report=new StringBuilder();int failed=0;
  MinimapDetector detector=new MinimapDetector(Path.Combine(root,"templates"));
  Check(detector.Available,"template loaded",report,ref failed);
  string test=Path.Combine(root,"tests");
  string[] closedFiles={"minimap-v49/collapsed-popup.png","minimap-v49/collapsed-evening.png"};
  MinimapReading closed=null,opened=null;
  foreach(string file in closedFiles)using(Bitmap image=Normalized(Path.Combine(test,file))) {
   MinimapReading seen=detector.Read(image);if(closed==null)closed=seen;
   Check(seen.State==MinimapState.Collapsed,file+" => "+seen.State+" closed="+seen.ClosedScore.ToString("F3")+" open="+seen.OpenScore.ToString("F3"),report,ref failed);
   Check(seen.TogglePoint.X>=1174&&seen.TogglePoint.X<1216&&seen.TogglePoint.Y>=35&&seen.TogglePoint.Y<117,"click stays within observed collapsed tab",report,ref failed);
  }
  foreach(string file in new string[]{"route0.png","route1.png","route2.png","route3.png","priority-v47/panjun-arrival.png","box-v47/popup.png","minimap-v49/expanded-current.png"})using(Bitmap image=Normalized(Path.Combine(test,file))) {
   MinimapReading seen=detector.Read(image);if(opened==null)opened=seen;
   Check(seen.State==MinimapState.Expanded,file+" => "+seen.State+" closed="+seen.ClosedScore.ToString("F3")+" open="+seen.OpenScore.ToString("F3"),report,ref failed);
  }
  using(Bitmap blank=new Bitmap(1216,684)) {
   Check(detector.Read(blank).State==MinimapState.Unknown,"black frame cannot authorize map click",report,ref failed);
   using(Graphics g=Graphics.FromImage(blank))g.Clear(Color.FromArgb(145,138,110));
   Check(detector.Read(blank).State==MinimapState.Unknown,"plain beige frame cannot imitate glyphs",report,ref failed);
  }
  using(Bitmap image=Normalized(Path.Combine(test,"route0.png"))) {
   using(Graphics g=Graphics.FromImage(image))g.FillRectangle(Brushes.Black,new Rectangle(1068,32,148,170));
   Check(detector.Read(image).State==MinimapState.Expanded,"missing map title/coordinates alone does not imply collapsed",report,ref failed);
  }
  MinimapReading unknown=new MinimapReading();MinimapRecoveryFlow flow=new MinimapRecoveryFlow();
  Check(!flow.Step(opened,1,true,false).Handled,"ordinary expanded minimap continues without toggling",report,ref failed);
  Check(!flow.Step(unknown,2,true,false).Handled,"initial unknown does not invent collapsed state",report,ref failed);
  Check(flow.Step(closed,3,true,false).Tap.HasValue,"first confidently collapsed fresh frame immediately taps",report,ref failed);
  Check(!flow.Step(closed,3,true,false).Tap.HasValue,"duplicate timestamp cannot trigger another tap",report,ref failed);
  Check(!flow.Step(closed,4,true,false).Tap.HasValue&&!flow.Step(closed,5,true,false).Tap.HasValue,"cooldown suppresses repeat taps",report,ref failed);
  MinimapRecoveryAction expanded=flow.Step(opened,7,true,false);
  Check(expanded.Handled&&!expanded.Tap.HasValue&&!expanded.Recovered,"expanded but missing OCR never toggles closed",report,ref failed);
  expanded=flow.Step(opened,40,true,false);
  Check(expanded.Handled&&!expanded.Tap.HasValue,"long OCR wait never clicks expanded tab",report,ref failed);
  Check(!flow.Step(opened,41,true,true).Recovered,"first valid coordinate frame waits",report,ref failed);
  Check(!flow.Step(opened,41,true,true).Recovered,"duplicate valid frame cannot complete recovery",report,ref failed);
  Check(flow.Step(opened,42,true,true).Recovered,"second valid fresh coordinate frame completes",report,ref failed);
  Check(!flow.Step(opened,43,true,true).Handled,"next fresh frame returns to route workflow",report,ref failed);
  flow.Reset();flow.Step(closed,0,true,false);
  Check(!flow.Step(unknown,1,true,false).Tap.HasValue,"unknown flicker never authorizes a retry click",report,ref failed);
  Check(!flow.Step(closed,2,true,false).Tap.HasValue,"unknown/closed flicker cannot bypass cooldown",report,ref failed);
  Check(flow.Step(closed,3,true,false).Tap.HasValue,"fresh confirmed collapsed tab retries after cooldown",report,ref failed);
  flow.Reset();int taps=0;
  for(int second=0;second<=12;second++)if(flow.Step(closed,second,true,false).Tap.HasValue)taps++;
  Check(taps==3,"persistent closed state limited to three attempts before longer cooldown",report,ref failed);
  Check(!flow.Step(closed,13,false,false).Handled,"stop cancels recovery",report,ref failed);
  Check(!flow.Step(opened,14,true,true).Handled,"new run starts with clean recovery state",report,ref failed);
  string result=Path.Combine(test,"minimap-v49","检查结果.txt");
  Directory.CreateDirectory(Path.GetDirectoryName(result));
  report.AppendLine("Failures: "+failed);File.WriteAllText(result,report.ToString(),Encoding.UTF8);
  return failed;
 }
#if MINIMAP_REPLAY
 public static int Main(string[] args){return Run(args.Length>0?args[0]:AppDomain.CurrentDomain.BaseDirectory);}
#endif
}
