using System;

// Only two fresh, positively verified game HUD frames may admit new work.
// Existing recovery and input owners always have priority.
public sealed class MaintenanceAdmission {
 int clearFrames;double last=-1;
 public void Reset(){clearFrames=0;last=-1;}
 public bool Observe(double now,bool recovering,bool expanded,bool hud,bool modal){
  if(recovering||!expanded||!hud||modal){Reset();return false;}
  if(now<=last)return false;
  if(last>=0&&now-last>10)clearFrames=0;
  last=now;clearFrames++;return clearFrames>=2;
 }
}
