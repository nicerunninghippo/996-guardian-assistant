using System;using System.Drawing;using System.Windows.Forms;
partial class Guardian {
 RouteCoordinateSettings navigationSettings=RouteCoordinateSettings.Defaults();
 readonly Label navigationInfo=new Label{AutoSize=true,MaximumSize=new Size(835,0),Padding=new Padding(0,6,0,0)};
 void InitNavigationSettings(Control top){LoadNavigationSettings("");Add(top,"路线坐标设置",ShowNavigationSettings);top.Controls.Add(navigationInfo);}
 void LoadNavigationSettings(string serial){string detail;navigationSettings=RouteCoordinateSettings.Load(data,serial,out detail);mengWalk=new WalkProgress();shenWalk=new WalkProgress();hellWalk=new WalkProgress();UpdateNavigationInfo();Log(detail+"；神龙="+GoalText(navigationSettings.Shenlong)+"；盟重="+GoalText(navigationSettings.Mengzhong));}
 string GoalText(RouteCoordinateGoal goal){return goal.X+":"+goal.Y;}
 void UpdateNavigationInfo(){navigationInfo.Text="路线坐标：神龙"+GoalText(navigationSettings.Shenlong)+"；盟重"+GoalText(navigationSettings.Mengzhong)+"；冥界"+GoalText(navigationSettings.Mingjie)+"（先到目标，再识别传送点）";}
 void ResetNavigationRouteProgress(){
  for(int i=0;i<mapPriority.Maps.Length;i++)if(!mapPriority.EntryIssued[i]){mapPriority.Failed[i]=false;mapPriority.ConfirmedUnavailable[i]=false;mapPriority.CooldownUntil[i]=DateTime.MinValue;}
  ResetMapPriorityCycle();mapPriority.SearchIndex=-1;mapPriority.SearchSince=mapPriority.HallSince=DateTime.MinValue;
  mengWalk=new WalkProgress();shenWalk=new WalkProgress();hellWalk=new WalkProgress();mzCoordReadyUntil=DateTime.MinValue;
 }
 NumericUpDown CoordinateField(Form form,int x,int y,int min,int max,int value){var control=new NumericUpDown{Minimum=min,Maximum=max,Value=value,Width=85,Location=new Point(x,y)};form.Controls.Add(control);return control;}
 void ShowNavigationSettings(){
  string serial=backgroundConnected?backend.Serial:"";
  using(var form=new Form{Text="路线坐标设置",ClientSize=new Size(550,313),StartPosition=FormStartPosition.CenterParent,FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false,Font=Font}){
   form.Controls.Add(new Label{AutoSize=false,Size=new Size(525,45),Location=new Point(12,10),Text=serial.Length>0?"当前实例："+serial+"。保存后暂停守护，点击开始守护应用新目标。":"未连接：保存为默认坐标；实例连接后优先使用各自保存的配置。"});
   form.Controls.Add(new Label{AutoSize=true,Location=new Point(135,62),Text="X"});form.Controls.Add(new Label{AutoSize=true,Location=new Point(240,62),Text="Y"});form.Controls.Add(new Label{AutoSize=true,Location=new Point(345,62),Text="到位后搜索半径"});
   form.Controls.Add(new Label{AutoSize=true,Location=new Point(15,98),Text="神龙帝国"});form.Controls.Add(new Label{AutoSize=true,Location=new Point(15,145),Text="盟重省"});
   var sx=CoordinateField(form,120,94,0,99,navigationSettings.Shenlong.X);var sy=CoordinateField(form,225,94,0,99,navigationSettings.Shenlong.Y);var sr=CoordinateField(form,355,94,0,2,navigationSettings.Shenlong.SearchRadius);
   var mx=CoordinateField(form,120,141,100,600,navigationSettings.Mengzhong.X);var my=CoordinateField(form,225,141,100,600,navigationSettings.Mengzhong.Y);var mr=CoordinateField(form,355,141,0,2,navigationSettings.Mengzhong.SearchRadius);
      form.Controls.Add(new Label{AutoSize=true,Location=new Point(15,193),Text="冥界"});
   var hx=CoordinateField(form,120,189,0,99,navigationSettings.Mingjie.X);var hy=CoordinateField(form,225,189,0,99,navigationSettings.Mingjie.Y);var hr=CoordinateField(form,355,189,0,2,navigationSettings.Mingjie.SearchRadius);
   form.Controls.Add(new Label{AutoSize=false,Size=new Size(525,35),Location=new Point(12,231),Text="需要先实际到达目标坐标；半径只用于到位后的微调，不提前点击。"});
   var defaults=new Button{Text="恢复默认",Location=new Point(15,273),AutoSize=true};defaults.Click+=(sender,args)=>{var settings=RouteCoordinateSettings.Defaults();sx.Value=settings.Shenlong.X;sy.Value=settings.Shenlong.Y;sr.Value=settings.Shenlong.SearchRadius;mx.Value=settings.Mengzhong.X;my.Value=settings.Mengzhong.Y;mr.Value=settings.Mengzhong.SearchRadius;hx.Value=settings.Mingjie.X;hy.Value=settings.Mingjie.Y;hr.Value=settings.Mingjie.SearchRadius;};form.Controls.Add(defaults);
   var save=new Button{Text="保存",Location=new Point(355,273),AutoSize=true,DialogResult=DialogResult.OK};var cancel=new Button{Text="取消",Location=new Point(450,273),AutoSize=true,DialogResult=DialogResult.Cancel};form.Controls.Add(save);form.Controls.Add(cancel);form.AcceptButton=save;form.CancelButton=cancel;
   if(form.ShowDialog(this)!=DialogResult.OK)return;
   var updated=new RouteCoordinateSettings{Schema=1,Mingjie=new RouteCoordinateGoal{X=(int)hx.Value,Y=(int)hy.Value,SearchRadius=(int)hr.Value},Shenlong=new RouteCoordinateGoal{X=(int)sx.Value,Y=(int)sy.Value,SearchRadius=(int)sr.Value},Mengzhong=new RouteCoordinateGoal{X=(int)mx.Value,Y=(int)my.Value,SearchRadius=(int)mr.Value}};
   updated.Save(data,serial);StopAll("路线坐标已保存，请点击开始守护");navigationSettings=updated;ResetNavigationRouteProgress();UpdateNavigationInfo();
   Log("路线坐标已保存：神龙="+GoalText(updated.Shenlong)+"；盟重="+GoalText(updated.Mengzhong)+"；配置="+RouteCoordinateSettings.FilePath(data,serial));TraceEvent("route_coordinates","serial",serial,"shenlong_x",updated.Shenlong.X,"shenlong_y",updated.Shenlong.Y,"mengzhong_x",updated.Mengzhong.X,"mengzhong_y",updated.Mengzhong.Y);
  }
 }
}

