using System;using System.Drawing;using System.IO;using System.Security.Cryptography;using System.Text;using System.Web.Script.Serialization;

public sealed class RouteCoordinateGoal {
 public int X {get;set;} public int Y {get;set;} public int SearchRadius {get;set;}
 [ScriptIgnore]public Point Point {get{return new Point(X,Y);}}
 public bool IsReady(Point current,WalkProgress walk){
  if(current==Point)walk.GoalSeen=true;
  return current==Point||walk.GoalSeen&&Math.Abs(current.X-X)+Math.Abs(current.Y-Y)<=SearchRadius;
 }
}
public sealed class RouteCoordinateSettings {
 public int Schema {get;set;} public int MingjieRevision {get;set;}
 public RouteCoordinateGoal Mengzhong {get;set;} public RouteCoordinateGoal Shenlong {get;set;} public RouteCoordinateGoal Mingjie {get;set;}
 public static RouteCoordinateSettings Defaults(){return new RouteCoordinateSettings{Schema=1,MingjieRevision=2,Mengzhong=new RouteCoordinateGoal{X=312,Y=333,SearchRadius=2},Shenlong=new RouteCoordinateGoal{X=17,Y=37,SearchRadius=1},Mingjie=new RouteCoordinateGoal{X=28,Y=52,SearchRadius=1}};}
 public void Validate(){
  if(Schema!=1||Mengzhong==null||Shenlong==null)throw new FormatException("路线坐标配置结构不完整或版本不支持");
  if(Mingjie==null)Mingjie=Defaults().Mingjie;Check(Mengzhong,100,600,"盟重");Check(Shenlong,0,99,"神龙");Check(Mingjie,0,99,"冥界");
 }
 static void Check(RouteCoordinateGoal goal,int min,int max,string name){if(goal.X<min||goal.X>max||goal.Y<min||goal.Y>max||goal.SearchRadius<0||goal.SearchRadius>2)throw new FormatException(name+"坐标必须介于"+min+"和"+max+"，到位后搜索半径为0至2");}
 public static string FilePath(string directory,string serial){
  if(string.IsNullOrWhiteSpace(serial))return Path.Combine(directory,"route-coordinates.json");
  string id;using(var hash=SHA256.Create())id=BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(serial))).Replace("-","").Substring(0,16);
  return Path.Combine(directory,"route-coordinates-"+id+".json");
 }
 public static RouteCoordinateSettings Load(string directory,string serial,out string detail){
  string path=FilePath(directory,serial);if(!File.Exists(path))path=FilePath(directory,"");
  if(!File.Exists(path)){detail="路线坐标使用默认：神龙17:37；盟重312:333";return Defaults();}
  try{var settings=new JavaScriptSerializer().Deserialize<RouteCoordinateSettings>(File.ReadAllText(path,Encoding.UTF8));if(settings==null)throw new FormatException("空配置");settings.Validate();if(settings.MingjieRevision<2){if(settings.Mingjie.Point==new Point(29,57))settings.Mingjie=Defaults().Mingjie;settings.MingjieRevision=2;}detail="路线坐标已加载："+path;return settings;}
  catch(Exception error){detail="路线坐标配置无效，使用默认17:37/312:333；保留原文件："+path+"；"+error.Message;return Defaults();}
 }
 public void Save(string directory,string serial){
  Validate();Directory.CreateDirectory(directory);string path=FilePath(directory,serial),temp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
  try{File.WriteAllText(temp,new JavaScriptSerializer().Serialize(this),Encoding.UTF8);if(File.Exists(path))File.Replace(temp,path,null);else File.Move(temp,path);}
  finally{if(File.Exists(temp))File.Delete(temp);}
 }
}

